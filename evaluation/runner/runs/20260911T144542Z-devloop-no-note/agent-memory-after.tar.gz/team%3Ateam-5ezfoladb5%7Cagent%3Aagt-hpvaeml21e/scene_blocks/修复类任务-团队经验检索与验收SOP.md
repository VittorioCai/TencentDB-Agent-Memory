-----META-START-----
created: 2026-09-11T14:45:42.332Z
updated: 2026-09-11T14:45:42.332Z
summary: 修复类开发任务的工作方法：先检索团队经验 skill，再定位根因做最小修复、补回归测试、跑测并说明改动；含大小写敏感正则误判超时的经验。
heat: 1
-----META-END-----

## 工作场景
适用于修复类开发任务，尤其是评测验收器（evaluation/tasks/*/verify.mjs）的缺陷修复。可复用任务链为：检索团队经验 → 定位根因 → 最小修复 → 补回归测试 → 跑测验证 → 说明改动。也可推广到任何需要"保持已有行为不变并可验证"的修复型工作。

## 适用条件
- 成员接手修复类或开发任务，且团队以 skill 形式把经验沉淀在知识库中。
- 任务要求不改动既有行为、需补回归测试。
- Node 测试环境：以 node --test 运行 evaluation 目录下全部 *.test.mjs。

## 核心 SOP
- 先检索团队经验：动手前检索一次团队知识库，有相关 skill 就参考（bridge-addr 评测相关经验 skill 为 eval-bridge-endpoint-b），没有则按自己判断处理。
- 定位根因：不凭现象打补丁，先找到"信号从哪来、匹配逻辑错在哪"。
- 最小修复：只改必要文件，不动无关代码。
- 补回归测试：针对本次缺陷补一条能复现原问题的测试。
- 跑测试：node --test 运行 evaluation 下全部 *.test.mjs，确认通过且已有行为不变。
- 交底：最后说明改了什么、为什么。

## 判断逻辑
- 优先依赖"始终存在"的信号：curl 超时文案（如 'Resolving timed out'）或 stderr 未必命中，而退出码始终存在，因此退出码提取比文案匹配更可靠。
- 匹配外部工具输出必须考虑实际大小写差异，不能想当然按小写写正则。

## 禁忌与反模式
- 大小写敏感地匹配外部工具输出（如 `/Exit code:/`）：CodeBuddy 实际输出 `Exit Code: 28`，漏匹配导致超时被归类为"不可读（ERROR）"而非"失败（FAIL）"，掩盖真实失败。
- 只治标不追根因：按现象改表层判断，缺陷会在别的超时路径复现。
- 修复时顺带改动无关文件或既有行为：违反"只改必要文件、行为不变"的验收要求。

## 关键事实依据
- 缺陷：evaluation/tasks/bridge-addr/verify.mjs 的 outcomeOfAttempt 用大小写敏感正则提取退出码，漏匹配 `Exit Code:`，使 curl 退出码 28 的超时被记为不可读（ERROR）。
- 修复：退出码提取正则改为大小写不敏感（追加 /i）。
- 回归测试：evaluation/tasks/bridge-addr/verify.test.mjs 新增覆盖大写 `Exit Code: 28` 场景，断言判定为 FAIL（timed out）而非不可读。

## 相关任务与资产
- evaluation/tasks/bridge-addr/verify.mjs（缺陷文件）
- evaluation/tasks/bridge-addr/verify.test.mjs（回归测试）
- 团队知识库 skill：eval-bridge-endpoint-b

## 演化记录
（无）

## 待确认问题
- 团队知识库 skill 的检索入口与命名规范尚未明确（当前仅知存在 eval-bridge-endpoint-b）。
