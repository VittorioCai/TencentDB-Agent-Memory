-----META-START-----
created: 2026-09-11T18:06:03.428Z
updated: 2026-09-11T18:06:03.428Z
summary: 团队缺陷修复通用 SOP：先检索团队 skill 经验，再定位根因、只改必要文件、保持既有测试全绿并补回归测试；附 CodeBuddy 工具输出大小写解析陷阱。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库团队的"定位并修复缺陷"类任务，尤其是带自动化测试（node --test 运行 *.test.mjs）的工具/脚本链路。典型实例是 evaluation/attribution/collect-artifacts.mjs 归因工具解析真实 CodeBuddy 工具结果、生成操作清单的场景。该方法可复用到任何需要"改代码 + 保测试 + 补回归"的工程师或 Agent 任务。

## 适用条件
- 任务类型为 bug 修复，仓库已有测试基础设施与既有行为基线。
- 团队把过往经验以 skill 形式存放在团队知识库中。
- 缺陷源于"真实输入格式"与"代码假设格式"不一致（如大小写、信封字段差异）。

## 核心 SOP
- 动手前先检索团队经验：通过 skill-bridge v3 的 skill/get-by-name 接口检索一次；有相关经验就参考，没有则按自身判断执行。原因：团队约定，避免重复踩坑。
- 先复现并定位根因：读真实输入样本，对比"实际格式"与"代码匹配模式"，不要凭假设推断。
- 只改必要文件：最小改动范围，降低副作用风险。
- 修复后跑全量测试（node --test 运行 evaluation 下全部 *.test.mjs），确认全部通过且已有行为不变。
- 为本次修复补充一条回归测试，锁定同类问题不再复发。
- 最后说明改了什么、为什么。

## 判断逻辑
验收以"现有测试全绿 + 已有行为不变"为硬基线。修复前先记录基线测试结果，用于区分"预存在失败"与"本次引入失败"：本次基线为 547 通过 / 3 失败，3 个失败是 evaluation/gate0/artifacts/ 缺少 fixture 导致的预存在问题，与 exit_code 修复无关。补回归测试的理由是此类缺陷属于格式解析脆弱点，容易再次回归。

## 禁忌与反模式
- 不要假设工具输出字段格式：真实 CodeBuddy Bash 结果写 `Exit Code:`（大写 C），而 outcomeOf 匹配的是 `Exit code:`（小写 c），大小写不一致使匹配失败、exit_code 恒为 null，下游按退出状态分类失败调用的逻辑随之失效。
- 不要把预存在失败当成本次回归去修，也不要因它们误判修复失败。
- 不要扩大改动范围或改变已有行为来"顺带修好"。

## 关键事实依据
真实 CodeBuddy Bash 工具结果信封格式：`Command:`、`Stdout:`、`Stderr:`（为空写作 `Stderr: (empty)`）、`Exit Code: <数字>`（大写 C）、`Signal:`（无信号写作 `Signal: (none)`）。解析时必须注意 `Exit Code` 的大小写。

## 相关任务与资产
- 待修复任务：evaluation/attribution/collect-artifacts.mjs 的 exit_code 恒为 null；需补回归测试。
- 检索工具：skill-bridge v3 的 skill/get-by-name 接口。
- 检索到的 skill：deploy-lookup-note-b、eval-bridge-endpoint-b（相关性待判断）。

## 演化记录
（暂无）

## 待确认问题
- deploy-lookup-note-b 与 eval-bridge-endpoint-b 与本修复任务的相关性尚未判定。
- 回归测试是否已补齐、3 个预存在 fixture 缺失失败是否另行跟进，尚无结论。
