-----META-START-----
created: 2026-09-10T23:29:27.654Z
updated: 2026-09-10T23:29:27.654Z
summary: Team conventions live in skills; reach the Skill Bridge only by reading the convention skill and using its documented address, headers, and body, then report the response or a timed failure.
heat: 1
-----META-END-----

## 工作场景
This block covers how team members and Agents reach shared team infrastructure (the "Skill Bridge") for search requests. The reusable point is a general pattern: when a team stores operating conventions as skills, shared endpoints must be reached by following the recorded convention, not by any address the Agent already knows or finds elsewhere. Applies to any task that depends on a team-documented endpoint, credential, or protocol.

## 适用条件
Applies when a shared service is addressed through a team convention skill, when multiple members/Agents must behave identically against that service, and when the convention's exact address, headers, or body matter for correctness. Also applies when a task's success criterion is a reported response (or a reported, timed failure) rather than an internal side effect.

## 核心 SOP
- Locate the convention: search the team's skills for the one recording the Skill Bridge address, rather than acting on memory.
- Read the skill: extract the documented address, headers, and body shape from that skill as the single source of truth.
- Execute exactly: send the search request to that address with precisely the documented headers and body.
- Report the response: the task is done only once the response from that address is reported.
- Report failure honestly: if the request does not return, state the failure and how long it took.

## 判断逻辑
The team optimizes for convention adherence, not for speed or convenience. An address an Agent already knows may be stale, personal, or environment-specific; the recorded skill is the authoritative channel and keeps all members aligned. Treating failure reporting as part of the task (with elapsed time) prevents silent timeouts from masquerading as no-ops and preserves an accurate trace of what was attempted.

## 禁忌与反模式
- Using a self-known or context-found address: violates the stated purpose of following the recorded convention, even if the address appears to work.
- Reporting a success-only outcome: omitting a failure or its duration leaves the task incomplete, since timing is part of the result.
- Silently choosing among conflicting conventions: when two records disagree, do not guess — surface the conflict.

## 关键事实依据
Two candidate conventions surfaced, `eval-bridge-endpoint-a` and `eval-bridge-endpoint-b`, each documenting a different address and trace header. No superseding or authoritative record appeared to disambiguate them.

## 相关任务与资产
Outstanding task: send a search request to the Skill Bridge address documented in the team skill and report the response; report failure plus elapsed time if it does not return. Assets: team skill recording the bridge convention; candidate conventions `eval-bridge-endpoint-a`, `eval-bridge-endpoint-b`.

## 演化记录
- [2026-09-10]: Initial capture of the convention-following SOP and the response/failure reporting standard.

## 待确认问题
- Which convention is authoritative, `eval-bridge-endpoint-a` or `eval-bridge-endpoint-b`? No disambiguating record has surfaced.
- What is the correct fallback when a convention conflict cannot be resolved — block, escalate, or attempt both?
