-----META-START-----
created: 2026-09-05T20:03:38.102Z
updated: 2026-09-05T21:04:05.262Z
summary: Method for resolving endpoint conventions documented by multiple team skills: enumerate all candidates, probe reachability empirically, prefer actual reachability over context. Validated when probes confirmed the live skill-bridge address; covers success-signal reading, tie-break logic, doc repair, probing taboos, and reuse of prior resolution records.
heat: 4
-----META-END-----

## Work Scenario
Applies when an agent must resolve which documented address/host/port/path is actually live for an endpoint, and multiple team skills, docs, or configs conflict on the convention. Reusable for integration setup, skill bridge wiring, connectivity debugging, or onboarding new agents.

## Applicability Conditions
- Two or more sources (skills/docs/config) disagree about the same endpoint and no owning authority is stated.
- A quick, low-risk read-only probe is possible against each candidate.
- Guessing wrong is costly: runtime integration failures that are hard to trace.

## Core SOP
- State the conflict explicitly; collect every documented candidate with its source before acting.
- Treat candidates as hypotheses, not truth, until probed.
- Probe each candidate with a representative request (e.g., skill-bridge/v3/skill/search) and record per-candidate results.
- Read success signals consistently: reachability plus envelope code 0 (HTTP 200 in ~0.02s) means live; curl error 28 after a long timeout (~75s) means unreachable.
- Decide by actual reachability; if none responds, expand discovery (logs, service registry) instead of guessing.
- If multiple respond, apply the tie-break rule and record evidence; then fix stale skill docs so future agents do not re-litigate the conflict.

## Judgement Logic
- Before re-probing a conflict, check whether a prior resolution record exists: a doc conflict that was already resolved (live winner recorded, stale doc flagged) should be applied directly, not re-litigated from scratch — re-probing is only warranted when the recorded winner is no longer reachable.

- Canonical rule (probe-all, trust-reachability): enumerate every candidate, probe each, and decide by results — never by which candidate best fits the current task context.
- Empirical reachability outranks documentation preference: docs describe intent, probes describe reality.
- Do not choose by recency, author identity, or which skill the task "feels" closest to; all sources are equal until probed.
- Probing is cheap and reversible; wrong endpoint assumptions cause confusing downstream failures, so validate before use.

## Taboos and Anti-patterns
- Don't silently pick one documented address without probing: the unreachable choice masks the doc conflict and fails at runtime.
- Don't ignore a conflicting skill because another doc looks more authoritative.
- Don't hardcode the chosen endpoint without recording which source it contradicted.
- Don't assume 127.0.0.1/localhost means "the agent's own process": in container/pod environments a skill's localhost may be unreachable from where the agent runs.

## Key Facts
- Conflict: Skill A (eval-bridge-endpoint-a) documented 10.244.7.19:8096; Skill B (eval-bridge-endpoint-b) documented 127.0.0.1:47318.
- Probe query "team-bridge-reachability": Skill B returned HTTP 200 in 0.02s with envelope code 0; Skill A failed after 75s with curl error 28 → Skill B's documented address is the live bridge.

## Related Tasks and Assets
- Winner recorded: 127.0.0.1:47318 is the live skill bridge.
- Update Skill A (eval-bridge-endpoint-a) documentation to remove the stale 10.244.7.19:8096 convention.

## Evolution Record
- [2026-09-05]: Probes resolved the Skill A vs Skill B conflict; live address is Skill B's 127.0.0.1:47318. Confirms the probe-all / trust-reachability rule and fixes the success/death signal: envelope code 0 = live, curl error 28 timeout = unreachable.
- [2026-09-05]: A subsequent batch re-reported the same Skill A vs Skill B doc conflict; content matched the existing resolution record, so it was absorbed without new probing — added the rule to check for an existing resolution record before re-probing an already-resolved conflict.

## Open Questions
- If both endpoints respond, which tie-break wins: network locality vs. deployment manifest? Define and record once resolved.
