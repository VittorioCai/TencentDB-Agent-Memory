# Team Operating Doctrine

> **Operating Thesis**: When documented sources conflict, trust empirical reality over documentation preference — enumerate every candidate, probe each directly, and let actual reachability decide.

## Core Principles
- **Empirical reachability outranks documentation**: docs describe intent, probes describe reality. When multiple team skills/docs/configs conflict on the same endpoint or service fact, treat every claim as a hypothesis until verified.
- **No source is privileged until probed**: never prefer a candidate by recency, author identity, or how well it matches the current task context.
- **Validate before use**: cheap, reversible checks always beat costly downstream runtime failures caused by a wrong assumption.

## Reusable SOPs
- **Probe-all, trust-reachability**: when ≥2 sources conflict on the same endpoint/service and no clear owning authority exists, first enumerate every documented candidate together with its source; then probe each with a representative read-only request and record per-candidate results; finally select the responding candidate. If none responds, expand discovery (logs, registry, manifests) instead of guessing.
- **Doc repair follow-up**: after the winning candidate is confirmed, fix the stale/conflicting source documentation and record which source the choice contradicted, so future agents do not re-litigate the same conflict.

## Decision Logic
- When multiple candidates respond, apply a defined tie-break rule and document the decision with evidence; if no tie-break is yet defined, record the open question explicitly instead of picking by context.
- When candidates cannot be probed safely or cheaply, prefer not choosing over choosing wrong.

## Boundaries & Anti-patterns
- Don't silently pick one documented address without probing: the unreachable choice masks the doc conflict and only fails later at runtime.
- Don't dismiss a conflicting source because another source looks more authoritative.
- Don't assume `127.0.0.1`/`localhost` in a skill/doc means the agent's own process: in pod/container environments a source's localhost may be unreachable from where the agent actually runs.
- Don't hardcode a chosen endpoint without recording which source it contradicted.

## Agent Rules
- Agent 应把跨多批记忆稳定形成、且适用范围超出单一场景的规则，主动升级为团队级通用约定，而不是让它停留在单点场景内。
- Agent 面对证据冲突且无法实测时，应显式记录 open questions 和取舍依据，避免用任务上下文偏好掩盖不确定性。

---

> **最后更新**：2026-09-05T20:04:31.090Z · **来源场景**：1 个 · **记忆总数**：0 条

---
## 🗺️ Scene Navigation (Scene Index)
*以下是当前场景记忆的索引，可根据需要 read 读取详细内容。*

### Path: scene_blocks/SkillBridge-Endpoint-Conflict-Probing.md
**热度**: 4 | **更新**: 2026-09-05T21:04:05.262Z
Summary: Method for resolving endpoint conventions documented by multiple team skills: enumerate all candidates, probe reachability empirically, prefer actual reachability over context. Validated when probes confirmed the live skill-bridge address; covers success-signal reading, tie-break logic, doc repair, probing taboos, and reuse of prior resolution records.

📌 使用说明：
- Path 是 scene block 的绝对路径，可直接使用 **read** 工具读取完整内容（参数: filePath）
- 热度：该场景被记忆命中的累计次数，越高越重要
- Summary：场景的核心要点摘要
