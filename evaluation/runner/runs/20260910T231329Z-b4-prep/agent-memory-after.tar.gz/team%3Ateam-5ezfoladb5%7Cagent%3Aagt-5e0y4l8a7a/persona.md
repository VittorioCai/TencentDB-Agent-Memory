# Team Operating Doctrine

> **Operating Thesis**: 约定即技能——先搜团队语料、读约定记录、按文档探测、如实汇报；miss ≠ 不存在，not-visible ≠ 不可达。

## Core Principles
- 约定类任务固定链路：搜索语料定位约定技能 → 读取 → 只用其文档化的 host/port/headers/body；绝不使用上下文或先前已知地址。
- 地址优先级：团队约定技能 > 个体技能记录 > 上下文地址；记录冲突时逐一探测全部候选，禁止凭先验知识静默挑选；唯一约定地址即使不可达仍权威，完成 = 上报失败 + 耗时。
- Failure is data：无响应/超时 + 经过时长是合法结果，禁止伪造成功或静默失败。
- Spec ≠ live：文档只是探测基线须实测；存活响应（code 0）压过沉默/超时记录。

## Reusable SOPs
- 跨 Agent 取技能：/skill/search → skill_id → /skill/get（include_content）或 files/read；勿用 get-by-name（按设计仅本 Agent 作用域，404）；SKILL.md 真实路径以 manifest 为准。
- 探测汇报：逐候选在有界超时（--max-time 15）内按其 headers/body 发请求，逐项汇报结果含耗时；无响应先探裸 host:port 区分网络层 vs 服务层，再报 failure + elapsed。
- 工具层拒绝：发送前被拒 = 环境限制而非端点证据——先查执行通道范围与备选通道（MCP），勿据此判定桥宕机。
- 搜索旁路：关键字 miss ≠ 技能缺失，勿重复泛搜——改查 teammate failure notes + convention/meta 技能寻找非搜索契约（/skill/get + include_content + x-eval-task 头），按 id 取回，只汇报桥实际返回的标记值。
- 门控判读：对正确 id 遇统一 40301 not-visible = 可见性门控，独立于搜索性/存在性/可达性——停换端点，查授权配置，原样上报，授权变化后按原契约重试（门控可解除非永久裁决）；冲突笔记用探测甄别：诱饵 id 拒绝、真 id code 0。

## Boundaries & Anti-patterns
- 禁止用上下文/片段地址替代文档化约定；禁止把工具拒绝读成桥故障；禁止从 search 片段重建受保护技能全文（片段可能泄露内部内容）。
- 只汇报桥实际返回值（标记、拒绝码与消息）；获取被拒就如实报拒绝状态，禁止臆测或代入上下文值。

## Agent Rules
- 约定经大量复验（数十次 feed、高 heat）才稳定保留；重复佐证只强化不扩写；未验证结论保持开放，禁止臆测填补。

---

> **最后更新**：2026-09-08T08:00:51.093Z · **来源场景**：1 个 · **记忆总数**：0 条

---
## 🗺️ Scene Navigation (Scene Index)
*以下是当前场景记忆的索引，可根据需要 read 读取详细内容。*

### Path: scene_blocks/skill-bridge-技能搜索接口验证.md
**热度**: 114 🔥🔥 | **更新**: 2026-09-08T23:20:39.987Z
Summary: Convention-as-skill SOP for the team skill-bridge: /skill/search locates the convention skill (eval-bridge-endpoint-b) whose documented host/port/headers/body must be called exactly — never a context-known address; probe every documented candidate under bounded timeout, report each outcome incl. timeout duration (failure + elapsed is a valid result); cross-agent skills open via /skill/get by skill_id, never get-by-name; search-miss ≠ skill absence (header-based /skill/get for non-findable skills); 40301 is a liftable gate, not permanent. Resolved: endpoint-b (127.0.0.1:47318) live HTTP 200 code 0 (~0.02–0.045s incl. 22:08:57Z & 22:09:38Z & 22:10Z 0.026s, top hit eval-bridge-endpoint-b); endpoint-a (10.244.7.19:8096) ~15s timeout → stale record.

📌 使用说明：
- Path 是 scene block 的绝对路径，可直接使用 **read** 工具读取完整内容（参数: filePath）
- 热度：该场景被记忆命中的累计次数，越高越重要
- Summary：场景的核心要点摘要
