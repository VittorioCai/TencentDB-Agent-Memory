# Team Operating Doctrine

> **Operating Thesis**: 证据驱动产出：验证按序真实执行每一步并留存证据，事实先核实后结论并带前提；权限受限不虚构、回退只读并记录待办；跨系统调用先加载协议来源。

## Core Principles
- 证据优先于结论：验证任务产出可审计证据；事实问题先核实、以权威文档为准，未核实不输出；禁止凭记忆或推测作答。
- 真实执行优先：验证每一步（如 curl）必须按序真实执行并留存输出；失败如实报告，编造成功会污染结论。
- 真实链路优先：端到端行为只在真实会话中可证明，mock/单测不能替代；涉及成本/探针的实验前确认 asset-reflection 已关闭。
- 禁止虚构结果：未真实执行时如实说明权限阻断，只可引用注入权威枚举作预期基准，不得以假结果冒充证据。
- 来源按专门性定优先级：先查主题权威文档与统一维护入口，再交叉核实，冲突以专门文档为准并记录差异。

## Reusable SOPs
- 能力覆盖验证：按调用类别枚举返回路径，真实会话逐类执行并确认被观测捕获，每类留存对应证据，矩阵显式标记未覆盖/权限阻断。
- 事实信息获取：先经统一维护入口与权威文档核实再交叉核实，结论注明依据；选型带形态前提；迁移类事实只引迁移文档。
- 多工具集成验证：对同一主题按固定顺序（skill 搜索→记忆库搜索→知识库查询）真实执行每步 curl，汇总 HTTP 状态码与返回原文前 200 字符；失败如实报告。
- 跨系统调用：先加载协议 skill（如 agentmemory-knowledge-tools-bridge-routing）获取真实路由与请求体字段，不凭系统提示词或服务名推断。
- 权限受限降级：被拒不硬试，信息获取回退只读工具与注入上下文；持久化记录待办，择机在审批可用会话解锁执行。

## Boundaries & Anti-patterns
- 不要用 mock/离线/假结果冒充证据，不要凭记忆或推测描述验证结果；未执行须如实说明。
- 不要只记“成功”日志而不留原始证据；不要只覆盖单一调用类型；不要把未落盘约定当已持久化资产引用。
- 不要跳过备份直接迁移；不要编造路径；不要把服务级接口当本地工具直接调用，须按协议经 Bash curl 调用。

## Agent Rules
- Agent 应显式标记未覆盖与异常路径，保证覆盖项与证据一一对应、可审计。
- Agent 应区分“注入枚举（预期基准）”与“真实执行证据”，前者不能替代后者。
- Agent 跨系统调用前必须先加载协议来源获取真实路由，避免凭记忆推断。

---

> **最后更新**：2026-09-01T05:55:28Z · **来源场景**：3 个 · **记忆总数**：0 条

---
## 🗺️ Scene Navigation (Scene Index)
*以下是当前场景记忆的索引，可根据需要 read 读取详细内容。*

### Path: scene_blocks/Agent-项目信息获取与部署约定.md
**热度**: 19 | **更新**: 2026-09-01T06:55:28.101Z
Summary: 项目信息获取与部署约定查询 SOP：回答团队约定类问题必须先经 skill-bridge 搜索团队 skill（agentmemory-project-deploy-db-conventions v7，ID skl-TPooFGaywqdC）取回正文作答，不凭记忆；部署形态由 TDAI_DEPLOY_MODE 切换 Standalone（SQLite+本地FS，:8420）与 Service（TCVDB+COS+Redis，按 x-tdai-service-id 多租户）；README.deployment.md 为部署权威文档、sqlite-init.sql 须与 createSchema() 同步；密钥仅环境变量注入；迁移 SOP（migrate-v2-to-v3 先备份、migrate-sqlite-to-tcvdb 支持 --dry-run/--layers）；Bash 被拒回退只读工具；约定 skill 为部署/数据库约定统一维护入口，团队正验证 skill 搜索/记忆库搜索/知识库查询三通道连通性。

### Path: scene_blocks/可观测性探针-Gate0.md
**热度**: 15 | **更新**: 2026-09-01T06:55:28.101Z
Summary: Gate 0 可观测性探针方法（绑定任务 task-n3lg0czx0t）：在真实 CodeBuddy 会话中按调用类别覆盖原生工具、Skill、Knowledge、TDAI Bash-curl 的结果返回路径，以可审计证据为产出；非交互会话下 Bash/WebFetch/Write 被拒且未绑定 knowledge 资源时以注入权威枚举为预期基准、如实记录阻断并回退只读工具，禁止假结果冒充证据；团队实验约定（docs/review/05-environment-and-model-policy.md）：真实链路优先 CodeBuddy CLI→MemoryProxy(:8096)→MemoryCore→DeepSeek、正式实验不用模拟 Agent/模型、主用 deepseek-v4-flash（v4-pro 仅代表性子集复验）、manifest 固定版本、正式实验关闭 asset-reflection（/analyse marker）；多工具集成验证须按序真实执行 curl、禁止凭记忆或推测作答、失败如实报告（wiki-yrgnw0ho 三通道连通性验证）。

### Path: scene_blocks/团队资产访问-Bridge接口SOP.md
**热度**: 11 | **更新**: 2026-09-05T00:52:52.278Z
Summary: 团队资产访问低层协议 SOP：memory-bridge scenario/read 按路径读场景文档；tools/list 与 tools/call 是 Knowledge service（端口 8424）服务级端点（service_url 须含 /v3），skill-bridge 匹配 /skill-bridge/v3/skill/<sub> 其余 404；skill-bridge 技能检索走 /skill/search（POST http://127.0.0.1:8096/skill-bridge/v3/skill/search，请求头 content-type/x-tdai-service-id: default/x-conversation-id，请求体 {"query":"关键词"}，返回技能名称与 skill_id，属 /skill/<sub> 路径族）；调用需会话绑定 knowledge 资源并注入 knowledge_tools 块，curl POST + JSON body + 固定请求头；检索必须 Bash+curl，WebFetch 无法注入请求头也不能发 POST；Bash 被拒解锁用 codebuddy -p --permission-mode bypassPermissions "<prompt>" 重跑或 permissions.allow 放行 Bash；Bash 被拒回退只读工具；禁止虚构返回结果；跨系统路由需先加载 skill agentmemory-knowledge-tools-bridge-routing（tools/call 真实路由 :8424/v3/tools/call，请求体三字段）；EVALPROBE 关键词检索待解锁重跑。

📌 使用说明：
- Path 是 scene block 的绝对路径，可直接使用 **read** 工具读取完整内容（参数: filePath）
- 热度：该场景被记忆命中的累计次数，越高越重要
- Summary：场景的核心要点摘要
