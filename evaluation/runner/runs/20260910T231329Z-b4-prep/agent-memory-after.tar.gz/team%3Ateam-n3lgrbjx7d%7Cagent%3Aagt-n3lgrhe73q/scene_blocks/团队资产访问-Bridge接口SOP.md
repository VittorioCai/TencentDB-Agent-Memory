-----META-START-----
created: 2026-08-29T21:51:06.245Z
updated: 2026-09-05T00:52:52.278Z
summary: 团队资产访问低层协议 SOP：memory-bridge scenario/read 按路径读场景文档；tools/list 与 tools/call 是 Knowledge service（端口 8424）服务级端点（service_url 须含 /v3），skill-bridge 匹配 /skill-bridge/v3/skill/<sub> 其余 404；skill-bridge 技能检索走 /skill/search（POST http://127.0.0.1:8096/skill-bridge/v3/skill/search，请求头 content-type/x-tdai-service-id: default/x-conversation-id，请求体 {"query":"关键词"}，返回技能名称与 skill_id，属 /skill/<sub> 路径族）；调用需会话绑定 knowledge 资源并注入 knowledge_tools 块，curl POST + JSON body + 固定请求头；检索必须 Bash+curl，WebFetch 无法注入请求头也不能发 POST；Bash 被拒解锁用 codebuddy -p --permission-mode bypassPermissions "<prompt>" 重跑或 permissions.allow 放行 Bash；Bash 被拒回退只读工具；禁止虚构返回结果；跨系统路由需先加载 skill agentmemory-knowledge-tools-bridge-routing（tools/call 真实路由 :8424/v3/tools/call，请求体三字段）；EVALPROBE 关键词检索待解锁重跑。
heat: 11
-----META-END-----

## 工作场景
适用于任何需要访问团队资产的 Agent 任务：读取场景文档（memory-bridge 的 scenario/read 按路径读取）、枚举团队 skill/资产工具（tools/list）、调用工具取回内容（tools/call）。这是独立于具体项目事实的跨任务低层访问协议，与"项目信息/部署约定查询"（场景文档内容口径）和"Gate0 探针方法论"（覆盖矩阵与证据留存）互补。

## 适用条件
- 任务需要读取团队场景文档、枚举资产工具或调用工具取回内容。
- 会话具备 Bash 执行权限：tools/list 与 tools/call 不是本地工具，必须经 Bash curl 访问端点。
- 会话已绑定 knowledge 资源且 system prompt 注入 <knowledge_tools> 块（提供 knowledge_id 与 service_url）：未绑定时无法构造 tools/list 与 tools/call 请求，属前置缺失而非端点故障。
- 非交互会话无审批通道时，执行类调用（尤其 ping 等交互命令）会被拒，需按降级规则处理。
- 需要核对工具枚举是否完整时，以会话注入的权威枚举（knowledge_tools 块）为预期基准。

## 核心 SOP
- 读取 memory-bridge 场景文档：curl POST + JSON body 调用 scenario/read 接口，按路径读取场景文档（如"可观测性探针-Gate0.md"）。
- 枚举/调用资产工具：curl POST + JSON body 调用 tools/list 与 tools/call，URL 为 {service_url}/tools/list 与 {service_url}/tools/call，service_url 必须包含 /v3 前缀（如 http://<KS_HOST>:8424/v3/tools/list）；请求头统一携带 content-type: application/json、x-tdai-service-id 与 x-conversation-id；tools/list 请求体携带 knowledge_id，tools/call 在同一地址上追加 tool_name 与 params 字段。端点 URL 从会话注入的 knowledge_tools 块获取，调用链路由 knowledge-tools-injector 注入。
- 端点归属：tools/list 与 tools/call 是 Knowledge service（端口 8424）的服务级端点，URL 为 {service_url}/tools/list（service_url 必须含 /v3）；skill-bridge 服务本身不提供这两个端点，只匹配 /skill-bridge/v3/skill/<sub>，其余请求一律 404；不要凭服务名推断端口与路由。
- skill-bridge 技能检索（/skill/search）：按关键词检索团队技能，返回技能名称与 skill_id。推荐调用形如 POST http://127.0.0.1:8096/skill-bridge/v3/skill/search，请求头固定携带 content-type: application/json、x-tdai-service-id: default、x-conversation-id（当前会话 ID），请求体为 JSON {"query": "关键词"}（关键词可用引号包裹字符串，如 "EVALPROBE"）；GET 亦可但以 POST 为准。该接口属于 skill-bridge 匹配的 /skill-bridge/v3/skill/<sub> 路径族（<sub> 含 search 等），与 tools/list、tools/call 的 Knowledge service（8424）边界一致，不要误归端口。该检索只能经 Bash + curl 执行：WebFetch 无法注入 x-tdai-service-id/x-conversation-id 请求头，也不能发送 POST，请求无法成形；因此在无 Bash 权限的会话中不要尝试 WebFetch 替代，直接按降级规则处理。
- 前置条件：调用前先确认会话已绑定 knowledge 资源且 system prompt 注入 <knowledge_tools> 块；若未绑定，则缺少 knowledge_id 与 service_url，请求无法构造，只能如实记录并规划绑定/解锁重跑。
- 跨系统工具调用的协议来源：knowledge 工具的真实路由不在系统提示词中，需要先从 skill 库加载 skill `agentmemory-knowledge-tools-bridge-routing` 获取调用协议；据此 knowledge 工具真实调用路由为 :8424/v3/tools/call，请求体需包含 knowledge_id、tool_name、params 三个字段（与 tools/list 同属 Knowledge service 8424 服务级端点）。
- proxy 地址映射：宿主机侧用 proxy 映射地址 127.0.0.1:8096；172.21.0.4 是容器内 IP，宿主机不可达，不要直连。
- 不要把 tools/list / tools/call 当本地工具直接调用：必须经 Bash curl 访问端点，这是与本地工具的判定性差异。
- 以会话注入的权威枚举为预期基准：skill-bridge 4 个（skill_search、skill_view、skill_files_read、skill_extract）；TDAI memory-bridge 6 个（tdai_memory_search、tdai_atomic_query、tdai_conversation_search、tdai_conversation_query、tdai_scenario_ls、tdai_read_scene）。允许状态下 tools/list 应返回此集合，可用它核对返回完整性。
- 非交互 Bash 规避审批触发：ping 等需交互确认的命令会被权限拒绝；改用纯 curl 并加超时参数快速重试。
- Bash 被拒的降级顺序：先用只读工具（Grep/Glob/Read）核实 proxy 正确地址、端口与路由路径，再确定真实调用方式；不要反复硬试被拒命令。
- 调用样例可从代理捕获产物提取：evaluation/gate0/artifacts/gate0-proxy-capture.jsonl 记录 service_url、knowledge_id 与实际 curl 调用样例，可作构造请求的依据。
- 权限阻断且无法执行时：如实记录阻断、回退只读工具与注入上下文继续，规划解锁重跑——在 settings 的 permissions.allow 中加入 Bash 权限后让 Agent 重新执行，或直接以 `codebuddy -p --permission-mode bypassPermissions "<完整 prompt>"` 重跑（把要执行的检索/调用指令作为带引号字符串传入该会话），或授权 dangerouslyDisableSandbox；解锁会话中再真实执行并贴出返回原文。

## 判断逻辑
- bridge 资产访问协议统一为 curl POST + JSON body + 固定请求头，便于审计与复现。
- 端点归属以注入块与代理捕获为准，不凭服务名推断：路径带 "skill-bridge" 不等于独立 skill-bridge 服务。
- 地址选择以可达性为准：宿主机侧必须用 proxy 映射地址；不可达时先核实映射而非反复重试。
- 注入枚举是权威预期，但 ≠ 真实执行结果：未真实执行时只能如实说明权限阻断并引用注入枚举，不能当作链路证据。
- 端点归属边界以注入块与代理捕获为准：tools/list 与 tools/call 只属于 Knowledge service（含 /v3 前缀），skill-bridge 仅匹配 /skill-bridge/v3/skill/<sub>（其中 search 为按关键词检索技能的子接口）。
- skill 检索结果的口径：/skill/search 返回技能名称与 skill_id（标识符），后续按名加载/取正文（get-by-name、skill_view/extract）或引用 skill_id 时应以该返回为准，不要臆造 skill 名与 ID；调用格式遵循固定形态（POST /skill-bridge/v3/skill/search + content-type/x-tdai-service-id: default/x-conversation-id 请求头 + {"query": 关键词} 请求体），不要省略请求头或改变路径。
- 工具可调用性取决于会话是否绑定 knowledge 资源：未注入 <knowledge_tools> 块时缺少 knowledge_id/service_url，属前置缺失而非端点故障，应区分记录。
- 权限受限时信息获取不中断：只读工具 + 注入上下文足以完成地址/端口/路由核实，执行类路径留待解锁重跑。

## 禁忌与反模式
- 不要把团队资产工具（tools/list / tools/call）当本地工具直接调用：它们是服务级端点，只能经 Bash curl 访问。
- 不要直连容器内 IP（172.21.0.4:8096）：宿主机不可达；应使用 proxy 映射地址 127.0.0.1:8096，先核实映射再调用。
- 不要把 /skill-bridge/... 路径误判为 tools/list 入口：skill-bridge 只匹配 /skill-bridge/v3/skill/<sub>，其余请求一律 404；tools/list 与 tools/call 在 {service_url}/tools/list（service_url 含 /v3），是 Knowledge service（端口 8424）服务级端点。
- 不要在会话未绑定 knowledge 资源（无 <knowledge_tools> 块、缺 knowledge_id/service_url）时硬试 tools/list / tools/call：请求无法构造，应先确认绑定状态再规划解锁。
- 不要在非交互会话中反复硬试被拒命令（如 ping）：无审批通道，重复调用持续失败；用纯 curl + 超时参数规避审批，或回退只读工具先核实地址/端口/路由。
- 不要虚构 tools/list 或 tools/call 的返回结果冒充真实链路证据：未真实执行时须如实说明，这是团队 doctrine，造假会污染评审与后续决策。
- 不要用 WebFetch 替代 Bash curl 调用 /skill/search 等 bridge 检索：WebFetch 无法注入 x-tdai-service-id/x-conversation-id 请求头，也不能发送 POST，请求无法成形；bridge 类 POST 检索必须经 Bash + curl，WebFetch 被拒或不具备能力时按降级规则处理。
- 不要编造不存在的场景文档路径或端点 URL：以注入块、代理捕获与已知文档为准。

## 关键事实依据
- 2026-08-29 探测确认：tools/list 为 POST {service_url}/tools/list，service_url 必须包含 /v3 前缀（如 http://<KS_HOST>:8424/v3/tools/list）；请求头需 content-type: application/json、x-tdai-service-id、x-conversation-id；请求体携带 knowledge_id，tools/call 在同一地址追加 tool_name 与 params 字段。
- 2026-08-29 架构修正：proxy 映射地址 127.0.0.1:8096；172.21.0.4 为容器内 IP，宿主机不可达；tools/list 与 tools/call 实际是 Knowledge service（端口 8424）服务级端点，URL 来自注入 knowledge_tools 块，经 knowledge-tools-injector 注入。
- 2026-08-29 端点边界确认：skill-bridge 服务本身不提供 tools/list 与 tools/call，仅匹配 /skill-bridge/v3/skill/<sub>，其余请求一律 404。
- 2026-08-29 前置条件确认：当前 agent 会话未绑定 knowledge 资源，system prompt 未注入 <knowledge_tools> 块，缺少 knowledge_id 与 service_url；真实执行 tools/list 与 tools/call 验证仍被 Bash 权限阻塞，需用户授权（codebuddy -p --permission-mode bypassPermissions 重跑 / permissions.allow 放行 Bash / dangerouslyDisableSandbox）后才能继续。
- 2026-08-29 非交互实测：Bash 下 ping 等命令因无法弹出权限审批被拒；纯 curl + 超时参数可快速重试规避审批触发。
- 2026-08-29 证据来源：evaluation/gate0/artifacts/gate0-proxy-capture.jsonl 为 gate0 proxy 捕获产物，可提取 knowledge service 相关 service_url、knowledge_id 与实际 curl 调用样例。
- 2026-09-01 确认：knowledge 工具真实路由不在系统提示词中，需从 skill 库加载 agentmemory-knowledge-tools-bridge-routing 获取协议；knowledge 工具真实调用路由为 :8424/v3/tools/call，请求体三字段 knowledge_id/tool_name/params，与既有 tools/call SOP 一致。
- 2026-09-04 确认：skill-bridge 提供 /skill/search 子接口，推荐 POST http://127.0.0.1:8096/skill-bridge/v3/skill/search，请求头 content-type: application/json、x-tdai-service-id: default、x-conversation-id（当前会话 ID），请求体 {"query": "关键词"}；用于检索团队技能，返回技能名称与 skill_id；GET 亦可但以 POST 为准。该接口属 skill-bridge /skill/<sub> 路径族而非 Knowledge service。
- 2026-09-04 23:40 执行通道补充：/skill/search 必须经 Bash + curl 执行，WebFetch 无法注入 x-tdai-service-id/x-conversation-id 请求头也不能发送 POST；按关键词 EVALPROBE 的 skill 列表检索任务因非交互会话 Bash 权限被拒未取得真实返回，需在 Bash 权限可用环境重跑（codebuddy -p --permission-mode bypassPermissions "<prompt>" 或 permissions.allow 放行 Bash）。

## 相关任务与资产
- 资产：evaluation/gate0/artifacts/gate0-proxy-capture.jsonl（service_url/knowledge_id/curl 样例来源）；会话注入 knowledge_tools 块（端点 URL 权威来源）。
- 待办：在已绑定 knowledge 资源且审批可用的会话中，以 POST {service_url}/tools/list（含 /v3 前缀）+ knowledge_id 获取团队资产工具列表，再以 tools/call 追加 tool_name/params 真实取回内容，贴出 curl 命令与返回原文（owner：Agent）；重跑验证 tools/list 返回与注入枚举（4+6）一致（owner：Agent）。
- 待办：在 Bash 权限可用会话中（codebuddy -p --permission-mode bypassPermissions "<prompt>" 重跑，或 permissions.allow 放行 Bash 后执行）按关键词 EVALPROBE 重新检索 skill 列表，贴出真实返回的技能名称与 skill_id（owner：Agent）。

## 演化记录
- [2026-08-29] 场景创建：沉淀团队资产低层访问协议（curl POST + JSON + 固定请求头、非本地工具判定、4+6 权威枚举、非交互降级与解锁、禁止虚构 doctrine）。
- [2026-08-29] 架构理解修正：由"tools/list 与 tools/call 是 skill-bridge 的接口路径"修正为"是 Knowledge service（端口 8424）服务级端点，URL 来自注入 knowledge_tools 块、经 knowledge-tools-injector 路由；路径前缀 skill-bridge 为服务路由名"；同时确认 proxy 映射地址 127.0.0.1:8096（172.21.0.4 为容器内 IP，宿主机不可达）。原因：真实探测与代理捕获证据表明端点归属与地址映射与此前理解不同。
- [2026-08-29] 端点归属边界再确认：由"疑似 POST /skill-bridge/v3/tools/list"确认为"tools/list 与 tools/call 是 Knowledge service（端口 8424）服务级端点，URL 为 {service_url}/tools/list 且 service_url 必须含 /v3（如 /v3/tools/list）；skill-bridge 仅匹配 /skill-bridge/v3/skill/<sub>，其余请求 404"。原因：新记忆澄清 skill-bridge 与 KS 的边界。
- [2026-08-29] 新增前置条件：调用 tools/list / tools/call 需会话绑定 knowledge 资源并注入 <knowledge_tools> 块（提供 knowledge_id 与 service_url）；未绑定时属前置缺失而非端点故障。解锁路径补充 dangerouslyDisableSandbox。
- [2026-09-01]：补充协议来源——knowledge 工具真实路由不在系统提示词中，跨系统调用前需先从 skill 库加载 agentmemory-knowledge-tools-bridge-routing；确认 knowledge 工具真实调用路由 :8424/v3/tools/call、请求体 knowledge_id/tool_name/params 三字段（与既有 SOP 一致，来源为已加载 skill）。
- [2026-09-01 05:54]：新一批记忆再次确认协议来源——执行跨系统工具调用时，knowledge 工具真实路由不在系统提示词中，需先从 skill 库加载 agentmemory-knowledge-tools-bridge-routing 获取协议；knowledge 工具真实调用路由 :8424/v3/tools/call、请求体三字段 knowledge_id/tool_name/params；无规则变更。
- [2026-09-01 06:55]：新一批记忆再次确认协议来源——执行跨系统工具调用时，knowledge 工具真实路由不在系统提示词中，需先从 skill 库加载 agentmemory-knowledge-tools-bridge-routing 获取协议；knowledge 工具真实调用路由为 :8424/v3/tools/call（来自已加载 skill），请求体需包含 knowledge_id、tool_name、params 三个字段；与既有 SOP 一致，无规则变更。
- [2026-09-04]：新增 skill-bridge /skill/search 子接口 SOP——GET/POST 向 proxy 127.0.0.1:8096，携带关键词与 x-tdai-service-id（default）/x-conversation-id 请求参数，检索团队技能并返回技能名称与 skill_id；属 skill-bridge /skill/<sub> 路径族，与 Knowledge service 端点边界一致，无规则冲突。
- [2026-09-04 23:27]：细化 /skill/search 调用格式——推荐 POST http://127.0.0.1:8096/skill-bridge/v3/skill/search，请求头 content-type: application/json、x-tdai-service-id: default、x-conversation-id（当前会话 ID），请求体 {"query": "关键词"}；与既有"GET/POST + proxy + 关键词 + 固定请求参数"SOP 一致，仅补全请求头与请求体具体形态，无规则冲突。
- [2026-09-04 23:37]：新一批记忆再次确认 /skill/search 检索团队技能库的调用格式——POST http://127.0.0.1:8096/skill-bridge/v3/skill/search + content-type: application/json / x-tdai-service-id: default / x-conversation-id（当前会话 ID）请求头 + 请求体 {"query": "关键词"}；与既有 SOP 完全一致，无规则变更。
- [2026-09-04 23:40]：补充 /skill/search 执行通道约束——检索必须 Bash+curl，WebFetch 无法注入 x-tdai-service-id/x-conversation-id 请求头也不能发 POST，不能作替代通道；Bash 被拒解锁路径明确为 permissions.allow 放行 Bash 或 `codebuddy -p --permission-mode bypassPermissions "<prompt>"`（携带完整 prompt 重跑）；新增待办——按关键词 EVALPROBE 检索 skill 列表需解锁后重跑；无规则冲突。
- [2026-09-05 00:52]：新一批记忆再次确认 /skill/search 检索团队技能库的调用格式——POST http://127.0.0.1:8096/skill-bridge/v3/skill/search，请求头固定携带 content-type: application/json、x-tdai-service-id: default、x-conversation-id（当前会话 ID），请求体 JSON {"query": "关键词"}；与既有 SOP 完全一致，无规则变更。

## 待确认问题
- tools/list 实际返回与注入枚举（4+6 工具集合）的一致性待解锁后验证；若存在差异，需确认是权限/环境问题还是枚举本身变更。
