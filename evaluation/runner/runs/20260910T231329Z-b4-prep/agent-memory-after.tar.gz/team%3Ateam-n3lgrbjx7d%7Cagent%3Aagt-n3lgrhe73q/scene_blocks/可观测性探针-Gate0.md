-----META-START-----
created: 2026-08-26T21:33:25.983Z
updated: 2026-09-01T06:55:28.101Z
summary: Gate 0 可观测性探针方法（绑定任务 task-n3lg0czx0t）：在真实 CodeBuddy 会话中按调用类别覆盖原生工具、Skill、Knowledge、TDAI Bash-curl 的结果返回路径，以可审计证据为产出；非交互会话下 Bash/WebFetch/Write 被拒且未绑定 knowledge 资源时以注入权威枚举为预期基准、如实记录阻断并回退只读工具，禁止假结果冒充证据；团队实验约定（docs/review/05-environment-and-model-policy.md）：真实链路优先 CodeBuddy CLI→MemoryProxy(:8096)→MemoryCore→DeepSeek、正式实验不用模拟 Agent/模型、主用 deepseek-v4-flash（v4-pro 仅代表性子集复验）、manifest 固定版本、正式实验关闭 asset-reflection（/analyse marker）；多工具集成验证须按序真实执行 curl、禁止凭记忆或推测作答、失败如实报告（wiki-yrgnw0ho 三通道连通性验证）。
heat: 15
-----META-END-----

## 工作场景
适用于 Agent 能力覆盖验证 / observability probe 类任务，以及团队级实验约定管理。核心场景：确认不同工具调用类别（原生工具、Skill、Knowledge、TDAI Bash-curl）在真实会话中的结果能否正确返回并进入观测链路，且产出可供评审审计的证据；同时承载团队实验约定管理：真实链路优先与环境/模型策略（权威文档 docs/review/05-environment-and-model-policy.md）、涉及 token 成本 / KV cache 或探针验证的实验必须关闭 asset-reflection，以及"权限受限会话中如何区分预期枚举与真实执行证据"的执行口径。

## 适用条件
- Gate 0 阶段，需建立能力基线而非优化能力本身。
- 验证必须在真实 CodeBuddy 会话中进行，mock 或单测结果不能替代。
- 有明确的证据留存要求（评审、审计或回归比对）。
- 涉及 token 成本、KV cache 或探针验证时，前置条件是 asset-reflection 已关闭。
- 会话可能是非交互模式：Bash/WebFetch/Write 因无法弹出权限审批会被系统拒绝，MCP 可能无可用工具；探针须区分"会话注入的预期枚举"与"真实可执行链路"。

## 核心 SOP
- 实验前前置检查：确认 asset-reflection 已关闭（依据 feedback_asset_reflection.md；正式实验统一关闭，`/analyse` marker 生效）。Why：它会改变 KV cache 前缀并污染 token 成本指标；How：每次实验前先确认关闭状态。
- 遵循团队实验环境与模型策略（依据 docs/review/05-environment-and-model-policy.md）：真实链路优先（CodeBuddy CLI → MemoryProxy(:8096) → MemoryCore → DeepSeek），最终实验不使用模拟 Agent/模型；主用 `deepseek-v4-flash`，`v4-pro` 仅代表性子集复验；实验 manifest 固定版本（base commit、镜像 digest、模型 ID、Node 版本等），保证结果可复现。
- 执行前先确认会话交互模式：非交互会话下 Bash/WebFetch/Write 无审批通道会被拒，tools/list 与 tools/call（Bash-curl 路径）无法真实执行；先判断可执行路径，避免在注定失败的调用上反复硬试。
- 探测前先核实 proxy 地址/端口/路由：Bash 被拒时按降级规则先用只读工具（Grep/Glob/Read）核实 proxy 正确地址（如映射 127.0.0.1:8096）、端口与路由路径，再确定真实调用方式；非交互 Bash 中 ping 等命令会触发审批被拒，改用纯 curl + 超时参数快速重试规避审批触发。
- 以会话注入的权威枚举为预期基准：skill-bridge 团队资产工具 4 个（skill_search、skill_view、skill_files_read、skill_extract），TDAI memory-bridge 工具 6 个（tdai_memory_search、tdai_atomic_query、tdai_conversation_search、tdai_conversation_query、tdai_scenario_ls、tdai_read_scene）；tools/list 在允许状态下应返回此集合，探针用它比对实际返回而非凭空猜测。
- 在真实会话中逐类执行调用，确认每类路径结果正确返回且被观测链路捕获；权限阻断时如实标记"未覆盖/权限阻断"，回退原生只读工具（Read/Glob/Grep）与已注入上下文继续。
- 要真正执行被阻断路径需先解锁：codebuddy -p -y 或 --permission-mode bypassPermissions 重跑，或将 Bash 加入 settings 的 permissions.allow 放行，或授权 dangerouslyDisableSandbox；且会话需已绑定 knowledge 资源（注入 <knowledge_tools> 块提供 knowledge_id 与 service_url），未绑定时 tools/list 请求无法构造。
- 每类路径留存证据（会话记录、原始输出、时间戳），与覆盖项一一对应；汇总矩阵并显式标记已覆盖 / 未覆盖 / 权限阻断路径。
- 多工具集成验证按固定顺序真实执行：对同一主题（如关键词"部署 约定"）依次调用 skill_search（skill 库）、记忆库 atomic/search、knowledge get_info（知识库查询）三种通道，汇总每个调用的 HTTP 状态码与返回原文前 200 字符作为验证结果；必须严格按顺序真实执行每一步 curl 命令，禁止凭记忆或推测作答，某一步失败时如实报告失败原因，不得编造成功结果。Why：跨通道连通性验证的目的就是暴露"哪条通道真实可达"，任何推测都会掩盖链路问题。

## 判断逻辑
- 选真实会话而非模拟环境：返回路径问题只在真实链路暴露。
- 按调用类别划分覆盖而非按用例堆叠：每类路径有独立证据，缺失类别一眼可见。
- 预期枚举（注入上下文）≠ 真实执行证据：团队资产工具的 tools/list 与 tools/call 不是本地工具，必须经 Bash curl 访问 Knowledge service 端点 {service_url}/tools/list（service_url 含 /v3）；未真实执行时只能引用注入枚举作为预期基准，不能当作链路证据。
- 证据留存优先于执行通过率：observability probe 的产出是可审计证据，而非"跑过了"的结论；如实记录的权限阻断是有效证据，虚构的返回不是。
- 度量可信优先于实验便利：先保证观测环境纯净再谈结果；被污染指标不能作为可审计证据，宁可重跑也不引用脏数据。
- 工具可调用性受前置绑定影响：未绑定 knowledge 资源（无 <knowledge_tools> 块）时，tools/list 与 tools/call 因缺少 knowledge_id/service_url 无法构造请求，属前置缺失而非端点故障，探针须区分记录。
- 验证结果以"真实执行证据"而非"预期推理"为准：多工具集成验证的每一步 curl 都必须真实执行并留存输出；失败是有效结果，编造成功会污染连通性结论。

## 禁忌与反模式
- 不要在未关闭 asset-reflection 时执行涉及 token 成本或 KV cache 的实验：会污染 KV cache 前缀与 token 成本指标；正确做法是实验前先确认已关闭。
- 不要把尚未落盘的约定当作已持久化资产引用：feedback_asset_reflection.md 因非交互会话审批不可用尚未写盘，引用前需确认其真实存在。
- 不要在审批不可用的会话中反复硬试 Bash/WebFetch/Write：非交互会话无审批通道，重复调用只会持续失败；正确做法是记录阻断、回退只读工具并规划解锁重跑。
- 不要用离线或假结果冒充真实链路证据：tools/call 未真实执行时须如实说明权限阻断并给出会话注入的权威枚举，这是团队 doctrine，造假会污染评审结论。
- 不要只记录"调用成功"日志而不留存原始证据；不要只覆盖单一工具类型；不要用 mock 或离线结果冒充真实链路证据。
- 不要凭记忆或推测描述多工具调用结果：多工具集成验证必须按序真实执行每一步 curl 并留存输出；某一步失败应如实报告原因，编造成功结果会直接污染三通道连通性结论。

## 关键事实依据
- 当前绑定任务 task-n3lg0czx0t（Gate 0 observability probe）：2026-08-27 至 08-29 多次输入确认绑定，目标与调用类别划分（原生工具、Skill、Knowledge、TDAI Bash-curl）及证据留存要求未变；任务绑定长期稳定，可作为后续探针类任务的复用前提。
- 团队实验环境与模型策略（2026-08-30 确认，权威文档 docs/review/05-environment-and-model-policy.md）：真实链路优先（CodeBuddy CLI → MemoryProxy(:8096) → MemoryCore → DeepSeek）；最终实验不使用模拟 Agent/模型；主用 deepseek-v4-flash，v4-pro 仅代表性子集复验；实验 manifest 固定版本（base commit、镜像 digest、模型 ID、Node 版本等）；正式实验统一关闭 asset-reflection（/analyse marker）。
- 团队约定：所有实验必须关闭 asset-reflection；拟持久化为 memory/feedback_asset_reflection.md（Why + How to apply），因非交互会话 Write/Bash 审批不可用，尚未成功落盘。
- 2026-08-29 探针实测：非交互会话下 Bash 与 WebFetch 均因无法弹出权限审批被拒，tools/list 与 tools/call（Knowledge service 的 Bash-curl 路径）无法真实执行；MCP 无待连接服务器、无 mcp__ 工具可用，Write 落盘也被拒；会话注入权威枚举为 skill-bridge 4 工具 + TDAI memory-bridge 6 工具（见核心 SOP）。
- 2026-08-29 探测发现：proxy 映射地址为 127.0.0.1:8096（172.21.0.4 为容器内 IP，宿主机不可达）；tools/list 与 tools/call 实际是 Knowledge service（端口 8424）服务级端点，经 knowledge-tools-injector 注入；evaluation/gate0/artifacts/gate0-proxy-capture.jsonl 为 gate0 proxy 捕获产物，可提取 service_url、knowledge_id 与实际 curl 调用样例。
- 2026-08-29 探针前置确认：当前会话未绑定 knowledge 资源，system prompt 未注入 <knowledge_tools> 块，缺少 knowledge_id 与 service_url；tools/list 与 tools/call 真实执行验证仍被 Bash 权限阻塞，解锁需用户授权（codebuddy -p --permission-mode bypassPermissions 重跑 / permissions.allow 放行 Bash / dangerouslyDisableSandbox）。
- 2026-09-01 多工具集成验证任务：团队正对知识库 wiki-yrgnw0ho 验证跨通道连通性，验证序列为 skill_search（关键词"部署 约定"）→ 记忆库 atomic/search（关键词"部署 约定"）→ knowledge get_info，结果口径为 HTTP 状态码 + 返回原文前 200 字符。

## 相关任务与资产
- task-n3lg0czx0t：执行覆盖并留存证据，后续补充缺失路径。
- 资产：evaluation/gate0/artifacts/gate0-proxy-capture.jsonl（gate0 proxy 捕获产物，提取 service_url/knowledge_id/curl 样例的权威来源）。
- 待办：在已绑定 knowledge 资源且审批可用的会话（codebuddy -p -y / --permission-mode bypassPermissions 重跑，或 permissions.allow 放行 Bash/WebFetch，或授权 dangerouslyDisableSandbox）中重跑 tools/list 与 tools/call，补齐真实执行证据（owner：Agent）。
- 待办：在审批可用的会话中落盘 memory/feedback_asset_reflection.md（owner：Agent）。
- 待办：对知识库 wiki-yrgnw0ho 执行三通道（skill_search / atomic/search / knowledge get_info）集成验证，按序真实执行 curl 并汇总 HTTP 状态码与返回原文前 200 字符（owner：Agent）。

## 演化记录
- [2026-08-27] 状态修正：feedback_asset_reflection.md 由"已写入"修正为"尚未成功落盘"，原因：非交互会话 Write/Bash 需审批且审批提示不可用；约定内容与 Why/How 结构不变。
- [2026-08-29] 新增探针运行结论：非交互会话权限阻断导致 Bash-curl 路径无法真实执行；确立"注入权威枚举为预期基准 + 如实记录阻断 + 回退原生只读工具 + 解锁重跑"的执行口径；"禁止虚构工具返回结果、未真实执行须如实说明并给出注入枚举"明确为团队 doctrine。
- [2026-08-29] 新增证据来源与降级细化：确认 gate0-proxy-capture.jsonl 为提取 service_url/knowledge_id/curl 样例的代理捕获依据；降级规则细化为"先用只读工具核实 proxy 地址/端口/路由，再确定真实调用方式"；非交互 Bash 用纯 curl + 超时规避审批触发。
- [2026-08-29] 新增前置条件与解锁路径：确认会话未绑定 knowledge 资源时无 <knowledge_tools> 块、缺 knowledge_id/service_url，tools/list 无法构造请求（属前置缺失而非端点故障）；解锁路径补充 dangerouslyDisableSandbox。
- [2026-08-30 12:48]：补充团队实验环境与模型策略——真实链路优先（CodeBuddy CLI → MemoryProxy(:8096) → MemoryCore → DeepSeek）、正式实验不用模拟 Agent/模型、主用 deepseek-v4-flash（v4-pro 仅代表性子集复验）、manifest 固定版本（base commit/镜像 digest/模型 ID/Node 版本）、正式实验关闭 asset-reflection（/analyse marker）；权威文档 docs/review/05-environment-and-model-policy.md。
- [2026-08-30 18:14]：新一批记忆再次确认团队实验约定——真实链路优先（CodeBuddy CLI→MemoryProxy(:8096)→MemoryCore→DeepSeek）、主用 deepseek-v4-flash、正式实验统一关闭 asset-reflection、实验 manifest 固定版本；与权威文档 docs/review/05-environment-and-model-policy.md 一致，无规则变更。
- [2026-09-01]：新增多工具集成验证 SOP——对同一主题按序调用 skill_search→atomic/search→knowledge get_info 三通道，汇总 HTTP 状态码与返回原文前 200 字符；确立"必须严格按顺序真实执行每一步 curl、禁止凭记忆或推测作答、失败如实报告、禁止编造成功结果"的执行口径（与既有"禁止假结果冒充证据" doctrine 一脉相承，细化为按序真实执行要求）。
- [2026-09-01 05:54]：新一批记忆再次确认多工具集成验证 SOP——对 wiki-yrgnw0ho 按序调用 skill_search→atomic/search→knowledge get_info（关键词"部署 约定"）、汇总 HTTP 状态码与返回原文前 200 字符；必须严格按顺序真实执行每一步 curl、禁止凭记忆或推测作答、失败如实报告、禁止编造成功；无规则变更。
- [2026-09-01 06:55]：新一批记忆再次确认多工具集成验证 SOP——对知识库 wiki-yrgnw0ho 按序真实执行 skill_search（关键词"部署 约定"）→ 记忆库 atomic/search（关键词"部署 约定"）→ knowledge get_info，汇总 HTTP 状态码与返回原文前 200 字符；每一步 curl 必须严格按顺序真实执行、禁止凭记忆或推测作答、失败如实报告、不得编造成功结果；无规则变更。

## 待确认问题
- 各调用类别"结果返回路径"的判定标准（成功返回、观测捕获、证据格式）待任务执行中明确。
- 待解锁重跑后确认 tools/list 实际返回是否与会话注入权威枚举（4+6 工具集合）完全一致。
