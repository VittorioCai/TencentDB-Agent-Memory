-----META-START-----
created: 2026-08-27T07:53:07.162Z
updated: 2026-09-01T06:55:28.101Z
summary: 项目信息获取与部署约定查询 SOP：回答团队约定类问题必须先经 skill-bridge 搜索团队 skill（agentmemory-project-deploy-db-conventions v7，ID skl-TPooFGaywqdC）取回正文作答，不凭记忆；部署形态由 TDAI_DEPLOY_MODE 切换 Standalone（SQLite+本地FS，:8420）与 Service（TCVDB+COS+Redis，按 x-tdai-service-id 多租户）；README.deployment.md 为部署权威文档、sqlite-init.sql 须与 createSchema() 同步；密钥仅环境变量注入；迁移 SOP（migrate-v2-to-v3 先备份、migrate-sqlite-to-tcvdb 支持 --dry-run/--layers）；Bash 被拒回退只读工具；约定 skill 为部署/数据库约定统一维护入口，团队正验证 skill 搜索/记忆库搜索/知识库查询三通道连通性。
heat: 19
-----META-END-----

## 工作场景
适用于 Agent 回答项目事实性问题（部署约定、数据库选型、使用注意事项、数据库迁移等）的信息获取流程，以及工具权限受限时的探索策略。可复用于任何"需要从仓库文档或可加载 skill 中核实事实后再给出结论"的任务，尤其是按部署形态给出条件化结论的场景。

## 适用条件
- 任务要求说明项目的部署约定、数据库类型、迁移方案或使用注意事项等事实性信息。
- 项目存在多部署形态（如 Standalone/Service），数据库选型随形态变化，结论需要带前提。
- 执行类工具（Bash/Grep 等）可能被拒绝，但信息获取仍需继续。
- 仓库中存在专门的约定说明文档（如 README.deployment.md），或存在可按名加载的约定类 skill，需按来源权威性确定查阅顺序。

## 核心 SOP
- 回答团队既有约定类问题（部署形态、数据库选型等）前先经 skill-bridge 搜索团队 skill，取回命中条目的正文，再基于正文回答，不得凭记忆作答：团队约定统一维护在 skill `agentmemory-project-deploy-db-conventions`（v7，skill ID `skl-TPooFGaywqdC`）中；再读取 memory-bridge 场景文档（本文件）并结合仓库实际内容核实，避免凭印象作答。
- 回答部署/数据库类问题前先确认部署形态：memory-tencentdb 的 Standalone 与 Service 复用同一 Gateway 二进制与 v1/v2/v3 HTTP API，仅以 TDAI_DEPLOY_MODE 切换；数据库选型随形态不同，结论必须按形态给出。
- 按 TDAI_DEPLOY_MODE 区分形态细节：Standalone（默认）面向本地开发与单 Agent sidecar/Docker 一体化，启动命令 `cd MemoryCore && npx tsx src/gateway/server.ts`，默认监听 `127.0.0.1:8420`，数据目录 `~/.memory-tencentdb/memory-tdai/`，用进程内 Map/Timer、单空间；Service 面向 K8s 多副本与 SaaS，用 TCVDB+COS、Redis 分布式锁与任务队列，按 `x-tdai-service-id` 做多租户隔离；切换形态只需改 `TDAI_DEPLOY_MODE`。
- 数据库选型细节按形态输出：Standalone 用 `vectors.db` 存 L0+L1 向量/记录、L2/L3 存本地文件，`metadata.db` 存用户/团队/Agent/Task/Asset 元数据（含 `meta_user_keys` 密钥表）；Service 用 TCVDB 向量库（默认库名 `agent_memory_prod`）+ COS 对象存储 + Redis 状态后端；配置项 `memory.storeBackend` 对应 `sqlite`（standalone）或 `tcvdb`（service）。
- 查询部署约定时优先查阅 README.deployment.md（存放于 .claude/worktrees/topic4-gate0）：它是团队约定的部署说明文档（含部署形态与 Hermes 集成），权威性高于泛化文档，团队查询部署约定时以此为准；环境与模型策略以 docs/review/05-environment-and-model-policy.md 为准；元数据 schema 以 MemoryCore/scripts/db/sqlite-init.sql 为准，且必须与 sqlite-adapter.ts 的 createSchema() 保持同步。
- 遵守密钥安全约束：密钥只经环境变量注入，不入库、不进 Git、不进日志/截图/报告；`deploy/global-images/.env` 必须 Git 忽略且仅当前用户可读。
- 再与根 README.md、MemoryCore/README.md 交叉核实：三份文档描述一致时结论可信；结论需两处以上信息吻合，出现冲突以 README.deployment.md 为准并记录差异。
- 可通过 skill-bridge 的 get-by-name 接口按名称加载 skill `agentmemory-project-deploy-db-conventions` 并取回正文与 manifest：该 skill 承载部署约定与数据库选型约定，是与权威文档同源的约定获取入口；Bash 等执行工具可用时优先按名加载，被拒时退回只读文档核实。
- 查询数据库迁移相关事实时查阅 MemoryCore/scripts/migrate-sqlite-to-tcvdb/README.md：记录迁移说明，是数据库类问题的补充事实来源，避免仅凭主文档推断迁移细节。
- 数据库迁移按 SOP 执行：Standalone 升级必须先执行 `migrate-v2-to-v3` 且迁移前必须备份整个数据目录；SQLite→TCVDB 使用 `migrate-sqlite-to-tcvdb` 脚本，支持 `--dry-run` 预检和分层迁移（`--layers l0,l1`），`--tcvdb-api-key` 与 `--tcvdb-api-key-env` 二选一必填。
- 非交互模式下 Bash 因无审批通道被系统拒绝时，立即切换 Read/Grep/Glob 等只读工具完成信息核实：Bash 被拒只影响命令执行，不等于任务中止，也不应中断信息收集流程；核实部署信息按「先 README.deployment.md、再与主 README/MemoryCore/README.md 交叉核实」的顺序执行。
- 回答数据库选型类问题时同时输出「类型 + 使用注意事项」两个口径，并注明所属部署形态。

## 判断逻辑
- 部署形态决定数据库选型：同一套代码的两种形态差异由运行环境约束驱动（单机/离线 vs 云服务/多租户），因此选型结论必须带形态前提，不能混答。
- 来源优先级按"专门性/权威性"而非"文件名顺序"：README.deployment.md 与 skill 都专门描述部署与数据库选型约定，这类问题先查它们；迁移文档只在涉及迁移细节时补充查阅。
- 可加载 skill 与权威文档互为印证：skill 提供按名加载的结构化约定，文档提供可审计的原文依据，二者一致时结论可信度最高；回答团队既有约定类问题时以 skill-bridge 命中正文为作答依据，不凭记忆，避免记忆漂移。
- 事实性问题的产出质量取决于核实而非记忆：先核实后结论，避免凭印象作答。
- 只读工具已覆盖"读文件、找文件"两大信息获取能力：执行工具被拒只影响写操作和命令执行，不影响信息获取路径。

## 禁忌与反模式
- 不要在未核实的情况下凭猜测回答数据库选型或部署约定：事实性问题以文档为准，未核实不输出结论；回答团队约定类问题不得凭记忆作答，必须先经 skill-bridge 搜索并取回命中 skill 正文。
- 不要将密钥写入数据库、Git、日志、截图或报告：密钥只经环境变量注入；`deploy/global-images/.env` 必须 Git 忽略且仅当前用户可读，防止凭据泄露。
- 不要脱离部署形态回答数据库选型：Standalone（SQLite+本地FS）与 Service（TCVDB+COS+Redis）存储方案不同，混答会误导使用者。
- 不要把 VDB_* / COS 密钥等云服务配置当作 Standalone 必配项：这些只在直连 TCVDB/COS 的 Service 场景需要；生产推荐 Shark 配置服务动态下发凭证，STATE_BACKEND 生产用 redis、单机测试才用 local。
- 不要跳过备份直接执行迁移：旧版 SQLite 升级必须先执行 migrate-v2-to-v3，且迁移前必须备份整个数据目录。
- 不要因 Bash/Grep 被拒绝就放弃探索或直接报"无法获取"：改用 Glob/Read/Grep 只读工具是标准回退路径；skill-bridge 不可用时同样退回只读文档核实，不要硬试或臆造 skill 内容。
- 不要把数据库迁移说明当作部署约定引用：迁移文档只回答迁移类事实，部署约定口径仍以 README.deployment.md 为准。
- 不要以为只读回退能覆盖写操作被拒的场景：非交互会话中 Write/Bash 需审批且审批提示可能不可用，持久化类操作会失败；应记录待办并在审批可用时执行。
- 不要读取或编造清单之外的文档路径：只能读取已知存在的文件，避免虚构路径。

## 关键事实依据
- 统一维护入口：agentmemory-project4 的部署约定与数据库选型由 skill-bridge skill `agentmemory-project-deploy-db-conventions`（v7，skill ID `skl-TPooFGaywqdC`）与 memory-bridge 场景文档（本文件）共同承载，是后续核实的首选来源；README.deployment.md 位于 topic4-gate0 worktree，经场景索引可快速定位部署相关说明。
- 部署形态细节：Standalone 启动命令 `cd MemoryCore && npx tsx src/gateway/server.ts`，默认监听 `127.0.0.1:8420`，数据目录 `~/.memory-tencentdb/memory-tdai/`；Service 按 `x-tdai-service-id` 多租户隔离。
- 数据库选型细节：Standalone 的 `metadata.db` 存用户/团队/Agent/Task/Asset 元数据（含 `meta_user_keys` 密钥表）；Service 的 TCVDB 默认库名 `agent_memory_prod`；`memory.storeBackend` = sqlite/tcvdb。
- 安全约束：密钥仅环境变量注入；`deploy/global-images/.env` Git 忽略且仅当前用户可读。
- 迁移脚本参数：migrate-sqlite-to-tcvdb 支持 `--dry-run` 预检、`--layers l0,l1` 分层迁移，`--tcvdb-api-key` 与 `--tcvdb-api-key-env` 二选一必填。
- 权威文档：README.deployment.md（部署形态 + Hermes 集成）、docs/review/05-environment-and-model-policy.md（环境与模型策略）、MemoryCore/scripts/db/sqlite-init.sql（元数据 schema，须与 sqlite-adapter.ts 的 createSchema() 同步）。
- 部署形态：Standalone 面向本地开发/单 Agent sidecar/Docker 一体化/离线场景；Service 面向 K8s 多副本/多租户 SaaS/多 Agent 共享记忆；同一二进制与 v1/v2/v3 API，TDAI_DEPLOY_MODE 切换。
- 数据库选型：Standalone=SQLite（vectors.db 存 L0+L1 向量与记录）+ 本地文件系统（~/.memory-tencentdb/memory-tdai/ 存 L2/L3 文档）；Service=TCVDB（服务端自带 bge-large-zh embedding）+ COS（按 serviceId 路径隔离）+ Redis（分布式锁与任务队列）。
- Service 生产配置：直连 TCVDB/COS 需 VDB_ENDPOINT、VDB_USER、VDB_API_KEY、VDB_DATABASE 与 COS 密钥；生产推荐 Shark 配置服务动态下发凭证，STATE_BACKEND=redis。
- 迁移脚本：migrate-v2-to-v3（旧版 SQLite 升级，迁移前必须备份整个数据目录）、migrate-sqlite-to-tcvdb（SQLite→TCVDB）。
- 权威文档：README.deployment.md；根 README.md 与 MemoryCore/README.md 描述一致，可交叉核实部署约定与数据库配置。
- 项目存在 skill `agentmemory-project-deploy-db-conventions`，承载部署约定与数据库选型约定，可经 skill-bridge 按名称加载。
- Bash 工具被拒时回退 Read/Grep 等只读工具继续核实信息，已被多次确认，属稳定 SOP。

## 相关任务与资产
- 资产：README.deployment.md（部署权威文档，含 Hermes 集成）、根 README.md、MemoryCore/README.md（交叉核实来源）、skill `agentmemory-project-deploy-db-conventions`（v7，ID skl-TPooFGaywqdC，经 skill-bridge 搜索取回正文）、MemoryCore/scripts/migrate-sqlite-to-tcvdb/README.md（迁移说明）、docs/review/05-environment-and-model-policy.md（环境与模型策略）、MemoryCore/scripts/db/sqlite-init.sql（元数据 schema，须与 sqlite-adapter.ts createSchema() 同步）。
- 待办：按部署形态输出"数据库类型 + 使用注意事项"并注明形态（owner：Agent）；验证 skill `agentmemory-project-deploy-db-conventions` 正文与 README.deployment.md 内容一致性（owner：Agent）；验证跨 skill 搜索、记忆库搜索与知识库查询三种通道的连通性（对知识库 wiki-yrgnw0ho 执行多工具集成验证，owner：Agent）。

## 演化记录
- [2026-08-27]：新增约定获取来源——确认存在 skill `agentmemory-project-deploy-db-conventions`，可经 skill-bridge 按名加载；SOP 增加"按名加载 skill"步骤。
- [2026-08-27]：补充数据库迁移事实来源——新增 MemoryCore/scripts/migrate-sqlite-to-tcvdb/README.md，界定其只用于迁移类事实核实。
- [2026-08-27]：再次确认「Bash 非交互被拒→回退 Read/Grep 只读工具」与 README.deployment.md 权威地位，无规则变更。
- [2026-08-27]：补充边界——只读回退仅适用于信息获取类任务；非交互会话中持久化类操作会失败，需记录待办择机落盘。
- [2026-08-27 08:40]：补充部署形态与存储选型细节——确认 Standalone/Service 双形态（TDAI_DEPLOY_MODE 切换）、各形态存储方案（SQLite+本地FS vs TCVDB+COS+Redis）、Service 生产配置（VDB_*/COS 凭证、Shark 动态下发、STATE_BACKEND=redis）、迁移脚本（migrate-v2-to-v3 需先备份整个数据目录）；交叉核实文档列表新增 MemoryCore/README.md；判断逻辑新增"选型结论必须带部署形态前提"。
- [2026-08-27 08:51]：确认统一维护入口——部署约定与数据库选型由 skill `agentmemory-project-deploy-db-conventions` 与 memory-bridge 场景文档（本文件）共同承载，SOP 增加"先加载 skill/读取场景文档、再结合仓库核实"步骤；README.deployment.md 权威地位（topic4-gate0 worktree）再次确认；Bash 被拒回退 Glob/Read/Grep 只读工具再次确认，无规则变更；数据库选型命名（TCVDB/TCVectorDB）尚待核实，列入待确认问题。
- [2026-08-27 08:53]：再次确认两条 SOP——README.deployment.md 为部署约定优先查阅文档、Bash/Grep 被拒回退 Glob/Read 只读工具继续核实，无规则变更；数据库选型结论任务进展——Agent 已只读核实 README.deployment.md 与根 README.md，结论尚未给出，仍按"类型+使用注意事项+部署形态"口径待输出。
- [2026-08-27 09:01]：再次确认统一维护入口（skill agentmemory-project-deploy-db-conventions + memory-bridge 场景文档本文件）、Bash 非交互因无审批通道被拒→回退 Glob/Read/Grep 只读工具、README.deployment.md（topic4-gate0 worktree）权威地位，均无规则变更；数据库选型命名（SQLite 与 TCVDB/TCVectorDB）仍待交叉核实 MemoryCore README 与 docs/review/05-environment-and-model-policy.md，结论待定。
- [2026-08-27 09:25]：新一批记忆再次确认既有 SOP——Bash 非交互被拒→回退 Read/Glob 只读工具核实、核实部署信息先读 README.deployment.md 再与根 README/MemoryCore README 交叉核实、README.deployment.md 位于 topic4-gate0 为权威文档、Standalone/Service 双形态（TDAI_DEPLOY_MODE 切换）与各形态存储选型、Service 生产 VDB_*/COS 凭证与 Shark 动态下发（STATE_BACKEND=redis）、迁移脚本（migrate-v2-to-v3 需先备份整个数据目录、migrate-sqlite-to-tcvdb），均无规则变更；数据库选型命名本批记忆一致使用 TCVDB，命名不确定性降低。
- [2026-08-27 09:36]：新一批记忆再次确认三条既有事实——项目存在 skill agentmemory-project-deploy-db-conventions 且可经 skill-bridge 按名称加载、README.deployment.md 为部署权威文档且 MemoryCore/scripts/migrate-sqlite-to-tcvdb/README.md 记录 SQLite→TCVDB 迁移说明、Bash 工具被拒时按既有 SOP 回退 Read/Grep 等只读工具继续核实；均无规则变更，来源链条保持稳定。
- [2026-08-27 10:01]：新一批记忆再次确认四条既有 SOP/事实——① 统一维护入口（agentmemory-project4 部署约定与数据库选型由 skill agentmemory-project-deploy-db-conventions 与 memory-bridge 场景文档本文件承载，需确认时先加载 skill/读取场景文档，再结合仓库实际内容核实）；② Bash 工具非交互因无审批通道被拒时按降级规则回退 Glob/Read/Grep 只读工具继续核实仓库文档，不中断信息收集；③ README.deployment.md（topic4-gate0 worktree）为部署约定权威文档，按场景索引可快速定位部署相关说明；④ 数据库选型（SQLite 与 TCVDB/TCVectorDB）尚未确认，正通过交叉核实 MemoryCore README 及 docs/review/05-environment-and-model-policy.md 验证，结论待定；均无规则变更。
- [2026-08-30 12:48]：规则升级——回答团队既有约定类问题必须先经 skill-bridge 搜索团队 skill 并取回命中正文作答，不得凭记忆；确认约定 skill 为 agentmemory-project-deploy-db-conventions v7（ID skl-TPooFGaywqdC）；补充部署形态细节（Standalone 启动命令/端口 8420/数据目录、Service 按 x-tdai-service-id 多租户）、数据库选型细节（metadata.db 含 meta_user_keys、TCVDB 默认库 agent_memory_prod、memory.storeBackend）、密钥安全约束（仅环境变量注入、deploy/global-images/.env Git 忽略且仅当前用户可读）、迁移 SOP 参数（--dry-run/--layers/API key 二选一必填）、权威文档新增 sqlite-init.sql 须与 createSchema() 同步。
- [2026-08-30 18:14]：新一批记忆再次确认部署/数据库/密钥约定——TDAI_DEPLOY_MODE 切换 Standalone（SQLite+本地文件，:8420）与 Service（TCVDB+COS+Redis，x-tdai-service-id 多租户）；vectors.db 存 L0+L1 向量/记录、metadata.db 存用户/Agent/密钥元数据；SQLite→TCVDB 迁移前必须先备份；密钥仅环境变量注入、不入库也不进 Git；约定 skill 可经 skill-bridge get-by-name 取回正文与 manifest；均无规则变更。
- [2026-09-01]：再次确认 skill `agentmemory-project-deploy-db-conventions` 为部署与数据库约定的统一维护入口；新增待办——团队正对知识库 wiki-yrgnw0ho 验证跨 skill 搜索、记忆库搜索与知识库查询三种通道的连通性（多工具集成验证），无规则变更。
- [2026-09-01 05:54]：新一批记忆再次确认——skill `agentmemory-project-deploy-db-conventions` 为部署与数据库约定的统一维护入口；团队对知识库 wiki-yrgnw0ho 的三通道连通性验证（skill_search → atomic/search → knowledge get_info，关键词"部署 约定"）仍在进行，验证结果口径为 HTTP 状态码 + 返回原文前 200 字符；无规则变更。
- [2026-09-01 06:55]：新一批记忆再次确认——skill `agentmemory-project-deploy-db-conventions` 为部署与数据库约定的统一维护入口；团队正对知识库 wiki-yrgnw0ho 验证跨 skill 搜索、记忆库搜索与知识库查询三种通道的连通性（多工具集成验证）；无规则变更。

## 待确认问题
- 数据库选型命名已基本定稿为 TCVDB：最新记忆一致使用 TCVDB，并给出 Service 默认库名 `agent_memory_prod`、配置项 `memory.storeBackend=tcvdb`；若后续文档出现 TCVectorDB 差异，以文档原文为准并记录。
- skill `agentmemory-project-deploy-db-conventions` 与 README.deployment.md 的内容一致性待实际加载后验证；若出现冲突，以文档原文为准并记录差异。
- 输出数据库选型结论时需确认是否已覆盖 Standalone 与 Service 两个形态的注意事项口径。
