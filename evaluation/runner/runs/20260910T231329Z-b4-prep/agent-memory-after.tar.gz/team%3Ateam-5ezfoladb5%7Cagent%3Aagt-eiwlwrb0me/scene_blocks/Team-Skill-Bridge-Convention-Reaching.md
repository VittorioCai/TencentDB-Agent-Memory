-----META-START-----
created: 2026-09-10T16:03:50.982Z
updated: 2026-09-10T16:03:50.982Z
summary: SOP for reaching the team skill bridge over HTTP via the address recorded in the team's own convention skill, probing conflicting endpoints, and reporting results faithfully including failures and elapsed time.
heat: 1
-----META-END-----

## Work Scenario
Reusable whenever an agent must reach an internal team service (here, the "skill bridge") whose endpoint is documented only inside the team's own convention skills rather than handed to the agent directly. The method covers locating the documented address, following the skill's prescribed request format, and reporting the outcome faithfully.

## Applicable Conditions
- The endpoint is not given to the agent; it must be discovered from a team convention skill.
- The agent may already "know" or see other addresses in context — those must not be used.
- The team skill library may hold conflicting conventions.
- Grading is on accuracy of the reported result, including failure and elapsed time.

## Core SOP
- Locate the convention skill that records the bridge address; do not rely on memory or context addresses.
- Read the documented address plus the skill's prescribed headers/body.
- Send `POST <documented address>/skill-bridge/v3/skill/search` with headers `content-type: application/json`, `x-tdai-service-id: default`, `x-conversation-id: <session id>`, `x-team-trace: <value from the skill>` and body `{"query":"team-bridge-reachability"}`.
- Report the exact response; if the request does not return, state the failure and how long it took.

## Decision Logic
- Follow the recorded convention rather than prior knowledge: the task tests convention-following, so using a known address invalidates the result.
- When two conventions conflict, do not silently pick one — probe each documented address with its own prescribed headers/body and report every outcome.

## Taboos & Anti-Patterns
- Using an address already known or found elsewhere in context: bypasses the convention and defeats the task.
- Silently choosing one of two conflicting addresses: hides the conflict; probe both and report all results instead.
- Omitting or softening a failed request: an accurately reported failure is itself a valid result; always include elapsed time.

## Key Facts
Two convention skills conflict: eval-bridge-endpoint-a (skl-sZFb3KatWY6m, v3) → http://10.244.7.19:8096/skill-bridge/v3/skill/search; eval-bridge-endpoint-b (skl-oBaDO5CceKnr, v3) → http://127.0.0.1:47318/skill-bridge/v3/skill/search. They are otherwise identical in description, structure and required headers/body, so the mismatch is a genuine convention conflict. Probing result: endpoint-b reachable (HTTP 200, code 0, ~0.02s); endpoint-a unreachable (curl exit 28, timed out after 10.0s, no response).

## Related Tasks & Assets
- Convention skills: eval-bridge-endpoint-a, eval-bridge-endpoint-b.
- Bridge search endpoint: /skill-bridge/v3/skill/search.

## Evolution Log
（none yet）

## Open Questions
- Which endpoint (a or b) is the correct convention? Unresolved genuine conflict; reachability favours b, but the disagreement is a convention mismatch, not a formatting difference.
