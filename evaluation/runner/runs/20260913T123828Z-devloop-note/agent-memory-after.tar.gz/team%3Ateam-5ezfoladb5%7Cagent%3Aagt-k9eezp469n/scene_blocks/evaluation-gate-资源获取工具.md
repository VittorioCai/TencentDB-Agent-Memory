-----META-START-----
created: 2026-09-13T12:40:20.607Z
updated: 2026-09-13T12:40:20.607Z
summary: 新增 evaluation/gate 工具类模块的复用方法：先检索团队经验 skill，按行为契约实现 fetchResource，只改必要文件并跑测试验证
heat: 1
-----META-END-----

## 工作场景
适用于本仓库在 evaluation/gate 下新增或修改工具类模块（如 fetchResource 资源获取工具）的完整链路。核心方法为"先查团队经验、按契约实现、最小改动验证"，可复用于任何新增小工具或接口模块的任务。

## 适用条件
- 任务类型：新增工具函数、补一条测试、保持既有行为不变。
- 团队约束：过往经验以 skill 形式存于团队知识库，动手前须先检索一次。
- 交付要求：只改必要文件，改完跑相关测试，结束时说明改了什么、为什么。

## 核心 SOP
- 先检索团队经验 skill：有相关经验（如 eval-skill-resource-download）就参考，没有则按自身判断执行——避免重复踩坑。
- 先明确行为契约再动手：返回值类型、空值语义、错误处理、依赖注入点都预先定义。
- 只改必要文件：新增工具 + 补一条测试，不顺手重构无关代码。
- 用 `node --test` 跑 evaluation 下所有 `*.test.mjs`，确认新增与既有测试全部通过。
- 收尾说明改动内容与原因，形成可追溯交付。

## 判断逻辑
- 资源原始字节应走 files/download 而非 files/read：download 返回原始字节，可直接落盘。
- 空内容是合法文件（返回零字节 Buffer），不应误判为错误。
- 上游错误信封（code !== 0）必须原样透传 message，吞错会掩盖真实故障。
- 注入 fetcher（缺省 globalThis.fetch）以便测试传桩，保证可测性。

## 禁忌与反模式
- 不检索团队经验直接实现：可能重复已知问题。
- 用 files/read 取资源字节：接口语义不符。
- 把空资源当错误抛出：破坏"空文件合法"契约。
- 吞掉上游错误信封或改写 message：丧失排障信息。
- 顺手改动无关文件：扩大回归风险。

## 关键事实依据
团队经验 skill eval-skill-resource-download（skill_id: skl-XAzqAgejM7O4）明确：skill 资源字节走 files/download，空内容合法，错误信封须原样透传。

## 相关任务与资产
- 任务：新增 evaluation/gate/fetch-resource.mjs，导出 `fetchResource({ skillId, path, bridgeBase, fetcher })`，并补一条测试。
- 资产：团队经验 skill eval-skill-resource-download (skl-XAzqAgejM7O4)。

## 待确认问题
- fetchResource 测试是否需覆盖成功、空资源、错误信封三条路径全部补齐。
