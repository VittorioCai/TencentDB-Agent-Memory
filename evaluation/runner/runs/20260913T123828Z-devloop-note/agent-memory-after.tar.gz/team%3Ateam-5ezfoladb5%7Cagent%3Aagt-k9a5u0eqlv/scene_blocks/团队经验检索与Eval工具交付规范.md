-----META-START-----
created: 2026-09-13T12:38:24.650Z
updated: 2026-09-13T12:38:24.650Z
summary: 团队在 evaluation/gate 下新增工具的方法体系：动手前先检索团队经验 skill，按 fetchResource 接口契约实现，交付前跑通 node --test 且只改必要文件。
heat: 1
-----META-END-----

## 工作场景
适用于在 evaluation/gate/ 目录下新增或修改小工具（如 fetch-resource.mjs）的交付任务，也适用于团队任何"先检索经验、再按契约实现、以最小改动交付"的工程场景。可复用的是三件事：团队经验检索习惯、工具接口契约、测试与最小改动约束。

## 适用条件
- 团队把过往经验以 skill 形式存于团队知识库，成员可检索。
- 任务属于 evaluation 下的工具开发，运行环境为 node --test。
- 需要对外暴露稳定接口，供调用方与其他模块/测试使用。

## 核心 SOP
- 检索经验：动手前先检索一次团队经验 skill；有相关经验就参考，没有则按自身判断执行。
- 确认契约：先定导出签名与行为约定，再写实现，避免调用方与实现不一致。
- 实现 fetchResource：成功返回资源原始字节 Buffer（调用方可直接写入文件）；空内容返回零字节 Buffer（空文件视为合法）；上游错误信封 code !== 0 时抛 Error 且 message 携带信封 message，不得吞掉；fetcher 注入 HTTP 实现，缺省用 globalThis.fetch。
- 补测试：为新增功能补一条测试，HTTP 桩通过 fetcher 注入。
- 验证：运行 evaluation 下全部 *.test.mjs（node --test），确保现有测试全通过、已有行为不变。
- 交付说明：完成后说清改了什么、为什么。

## 判断逻辑
- 先检索后开发：复用已沉淀经验可降低重复试错成本；无匹配经验时不强行套用。
- 契约先行：以导出签名 + 明确的返回/异常语义固化接口，便于调用方与测试对齐。
- 最小改动 + 全量回归：只改必要文件，但必须保证全目录测试通过，兼顾局部改动与整体稳定。
- 错误不静默：错误信封必须向上抛出并保留原始 message，由调用方处理。

## 禁忌与反模式
- 跳过经验检索直接开发：可能重复已有经验或违背团队既有约定。
- 吞掉上游错误或改写为无信息异常：调用方无法定位问题；应抛 Error 并保留信封 message。
- 把空文件当错误：零字节 Buffer 是合法返回。
- 改动无关文件或破坏已有行为：违反最小改动与回归通过约束。
- 硬编码 HTTP 实现：应经 fetcher 注入，便于测试传桩。

## 关键事实依据
- 相关团队 skill：eval-skill-resource-download（skill_id: skl-XAzqAgejM7O4），已检索出作为实现参考。
- 目标产物：evaluation/gate/fetch-resource.mjs，导出 fetchResource({ skillId, path, bridgeBase, fetcher })。

## 相关任务与资产
- 任务：新增 evaluation/gate/fetch-resource.mjs 并补一条测试；验证 evaluation 下 *.test.mjs 全部通过。
- 资产：团队 skill eval-skill-resource-download；接口签名 fetchResource({ skillId, path, bridgeBase, fetcher })。

## 演化记录
（暂无）

## 待确认问题
- bridgeBase 的取值与语义未明确，需与上游约定确认。
- path 与 skillId 的取值规则、错误信封的具体结构待补充。
