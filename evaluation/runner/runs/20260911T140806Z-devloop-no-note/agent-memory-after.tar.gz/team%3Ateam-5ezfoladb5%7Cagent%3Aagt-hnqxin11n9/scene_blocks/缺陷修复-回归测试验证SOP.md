-----META-START-----
created: 2026-09-11T14:01:28.228Z
updated: 2026-09-11T14:11:52.532Z
summary: 缺陷修复与回归测试验证的可复用方法：定位根因后最小改动，用 git stash 反证回归测试有效性并甄别既有失败，外部工具输出解析要鲁棒。
heat: 2
-----META-END-----

## 工作场景
适用于代码缺陷修复（尤其是测试/验收器逻辑缺陷）及回归测试编写、验证的场景，例如 evaluation/tasks/bridge-addr/verify.mjs 修复。可复用于任何需要"改一处、证明没改坏别处、并证明回归测试真能拦住缺陷"的工程任务，也适用于解析外部工具输出（CodeBuddy/Bash 结果）的解析器类缺陷。

## 适用条件
- 存在明确缺陷，需定位根因而非绕过。
- 代码库已有测试套件（如 *.test.mjs，用 node --test 执行），且可能存在历史/环境导致的既有失败。
- 交付要求通常包含"行为不变""只改必要文件""补充回归测试"。
- 单人、多人或 Agent 执行同样适用。

## 核心 SOP
- 先定位根因再动手：追到具体判定分支与匹配规则，而非加兜底。bridge-addr 缺陷根因是 outcomeOfAttempt 用大小写敏感正则读退出码，而 CodeBuddy 实际输出大写 "Exit Code:"，导致 exitCode 保持 null。
- 修复即修正信号源：把读取正则改为大小写不敏感、允许负值（/(?:^|\n)Exit code:\s*(-?\d+)/i），而不是补特判分支。
- 只改必要文件：避免顺带重构扩大回归面。
- 补一条针对性回归测试：必须覆盖原缺陷路径与其边界条件（如 Stdout/Stderr 均空、带大写 "Exit Code: 28" 的静默超时）。
- git stash 反证回归测试有效性：提交前暂存修复，运行回归测试确认其确实失败；恢复修复后再确认通过。
- git stash 甄别既有失败：暂存本次改动，在干净代码树上重跑同一测试集；干净树仍失败者即为既有失败。
- 交付前跑全量测试：`node --test evaluation/tasks/bridge-addr/*.test.mjs` 全绿，并说明改了什么、为什么。

## 判断逻辑
- "测试通过"不等于"修复有效"：回归测试若从未失败过，可能根本没覆盖缺陷路径，故需先证伪再证实。
- 干净树对比是区分"我引入的失败"与"环境/历史问题"的最低成本手段，避免误判并误改无关代码。
- 为何只漏判部分超时：命令静默（asset 文档让模型用 `curl -sSk`，`-s` 不带 `--show-error`）时 curl 不输出 stderr 文字，也匹配不到 "timed out" 文案；此时 Exit Code 是区分"超时失败"与"结果不可读"的唯一信号，必须可靠读取。只有恰好用 `-sS` 的超时因带 stderr 文案才被识别。
- 解析外部工具输出时要对大小写、正负号、字段缺失保持鲁棒；不可依赖人类可读文案作为唯一判据。

## 禁忌与反模式
- 只跑修复后的测试就宣布完成：未反证回归测试有效性，无法排除"假绿"。
- 一见测试失败就归因于本次改动：需先在干净树复现。
- 为让测试变绿而改动无关文件或删改已有断言：违反行为不变要求。
- 修复只加兜底、不定位根因：问题会以其他形式复发。
- 依赖大小写敏感正则 / 人类可读错误文案解析机器输出：会静默丢信号。

## 关键事实依据
- bridge-addr verify.mjs 缺陷：读 CodeBuddy 工具结果时部分超时被误记成"不可读"，落在 { ok: null, why: "outcome not readable" }。
- 根因：正则大小写不匹配 + 静默 curl 无 stderr 文案，双重叠加。
- 回归测试 "a timeout whose result carries no stderr prose is still a failure" 位于 evaluation/tasks/bridge-addr/verify.test.mjs，断言 ok=false、why 含 "timed out"，且该超时作末次尝试时整体判 FAIL 而非 ERROR。
- evaluation 原有 3 个失败在干净树同样复现，由缺少 evaluation/gate0/artifacts/*.jsonl 导致，与本次修复无关。

## 相关任务与资产
- 修复 verify.mjs 并补回归测试；验收标准：evaluation 下所有 *.test.mjs 经 node --test 全部通过，行为不变，只改必要文件。
- 资产：evaluation/tasks/bridge-addr/verify.mjs、verify.test.mjs、assets/consumer-skill-v2.md、v3.md。
- 缺失的 evaluation/gate0/artifacts/*.jsonl 为既有失败根因，待跟进。

## 演化记录
- [2026-09-11]: 补齐根因与修复口径——从"超时误判不可读"细化为"大小写敏感正则未读到大写 Exit Code + 静默 curl 无 stderr 文案"，修复正则改为大小写不敏感且允许负数。

## 待确认问题
- 既有失败（缺少 gate0/artifacts/*.jsonl）应由谁、何时补齐，是否需纳入测试前置校验以避免重复误判？
