-----META-START-----
created: 2026-09-13T18:42:19.596Z
updated: 2026-09-13T18:42:19.596Z
summary: 本仓库团队开发方法：动手前先检索团队知识库中的 skill 经验，只改必要文件，改后跑全量测试并说明变更动机，附 fetch-resource 工具接口约定。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库中新增小工具或做补丁式改动的日常开发任务。本仓库所属团队把过往经验以 skill 形式沉淀在团队知识库中，因此该场景的核心是"先检索团队经验、再最小改动实现、最后用测试与说明闭环"，尤其涉及把团队 skill 资源拉取到本地的 evaluation/gate 链路。

## 适用条件
- 仓库形态：含 evaluation/ 目录与 *.test.mjs（用 node --test 运行）的 Node 工程。
- 任务类型：增量小工具开发、局部改造，而非大规模重构。
- 前置条件：团队知识库可用，经验按 skill_id 组织并可检索。
- 约束：必须保持已有行为不变。

## 核心 SOP
1. 先检索团队知识库中的 skill 经验：动手前检索一次，命中则参考既有做法，未命中再按自身判断实现（降低试错成本）。
2. 只改必要的文件：不顺手重构、不格式化无关文件，控制改动面。
3. 按既定接口约定实现（见"关键事实依据"的 fetchResource 约定）。
4. 为新增能力补测试：每个新工具至少一条测试。
5. 全量回归：node --test 跑 evaluation 下所有 *.test.mjs，确认全部通过。
6. 收尾说明：讲清改了什么、为什么。

## 判断逻辑
- 检索优先：团队经验以 skill 为唯一沉淀载体，参考成本低于重复试错。
- 最小改动优先：可验证性重于代码整洁，改动面与回归风险正相关。
- 测试即验收口径：以 node --test 全绿作为"已有行为不变"的证据，而非口头保证。
- 显式说明动机：让 reviewer 能低成本判断变更意图与影响范围。

## 禁忌与反模式
- 不检索直接开写：忽略团队既有 skill 经验，易重复踩坑。
- 顺手重构/扩大改动面：回归风险不可控，违反"只改必要文件"。
- 吞掉上游错误：错误信封 code !== 0 时不抛错，调用方无法感知失败。
- 把空资源当失败：空文件是合法文件，应返回零字节 Buffer。
- 只跑新增测试、不做全量：无法证明已有行为未变。
- 硬编码 HTTP 实现：应经 fetcher 注入，否则测试无法传桩。

## 关键事实依据
fetchResource 接口约定（evaluation/gate/fetch-resource.mjs）：
- 签名：export async function fetchResource({ skillId, path, bridgeBase, fetcher })
- 成功：返回资源原始字节 Buffer，调用方可直接写入文件。
- 空资源：返回零字节 Buffer（空文件合法，不算错误）。
- 上游错误信封 code !== 0：抛 Error 且 message 携带信封的 message，不得吞掉。
- fetcher：用于注入 HTTP 实现（测试传桩），缺省 globalThis.fetch。
- 相关团队 skill：skl-XAzqAgejM7O4（skill 资源下载经验）、skl-oBaDO5CceKnr（skill-bridge endpoint）。

## 相关任务与资产
- 待办：新增 evaluation/gate/fetch-resource.mjs 并补一条测试；确保 evaluation 下 *.test.mjs 全绿。
- 资产：团队知识库中的 skill 条目（上述两个 skill_id）。

## 演化记录
（暂无）

## 待确认问题
- 团队知识库的检索入口/命令未明确，需补充检索方式。
- bridgeBase 取值与 skill-bridge endpoint 的对应关系未明确。
