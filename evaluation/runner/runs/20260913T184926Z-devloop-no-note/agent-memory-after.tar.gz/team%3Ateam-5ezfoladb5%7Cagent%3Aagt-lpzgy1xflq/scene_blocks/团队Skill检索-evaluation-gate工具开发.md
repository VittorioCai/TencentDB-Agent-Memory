-----META-START-----
created: 2026-09-13T18:50:03.896Z
updated: 2026-09-13T18:50:03.896Z
summary: 团队经验以 skill 存于知识库，动手前经 skill-bridge 检索；evaluation gate 工具开发遵循契约优先、依赖注入、最小改动加测试的交付 SOP。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库 evaluation gate 下的工具开发，以及任何需要先复用团队过往经验的实现任务。两条方法体系互补：先用 skill-bridge 检索团队经验，再以契约优先的方式落地工具（如 fetch-resource.mjs），保证既有行为不被破坏。

## 适用条件
任务涉及调用或新增 evaluation/gate 工具、需要从团队知识库取用 skill 经验或资源文件时。典型为 Agent 独立执行、且要求现有测试不破的仓库。

## 核心 SOP
- 动手前先检索团队经验：POST /skill-bridge/v3/skill/get，体 {skill_id, include_content, include_manifest}，带 x-tdai-service-id、x-conversation-id 头；有相关经验则参考，无则按自身判断执行。
- 取 skill 资源文件：POST {bridgeBase}/skill-bridge/v3/skill/files/read，体 {skill_id, path}；需兼容 bridgeBase 已含 /skill-bridge/v3/skill 前缀的情况。
- 工具签名约定：fetchResource({ skillId, path, bridgeBase, fetcher })，按 encoding（base64 或 utf-8）把 content 解码为 Buffer，成功返回原始字节 Buffer 供调用方直接写文件。
- 交付闭环：node --test 跑通 evaluation 下全部 *.test.mjs，为新增工具补一条测试，只改必要文件，改后跑测试并说明改了什么、为什么。

## 判断逻辑
bridge 接口统一走标准 JSON 信封 {code, message, request_id, data}，故以信封判定成功/失败；data 含 {path, content, encoding, size_bytes, mime_type, version}，故 content 需按 encoding 解码。fetcher 可注入是为了隔离测试与真实网络请求；缺省回退 globalThis.fetch 保证生产可用。

## 禁忌与反模式
- 收到 code !== 0 的信封却吞掉错误：必须抛出 Error 并透传信封 message，否则丢失上游诊断信息。
- 把空 content 当错误：空文件是合法文件，应返回零字节 Buffer 而非报错。
- 硬编码 globalThis.fetch 且不留注入口：会导致测试无法打桩。
- 借机做超出必要的重构：不得改变已有行为。

## 关键事实依据
deploy-lookup-note-a/b 经验已确认"通过 id 从 bridge 获取资源"的方式可行；files/read 的 data 结构为 {path, content, encoding, size_bytes, mime_type, version}。

## 相关任务与资产
evaluation/gate/fetch-resource.mjs（已实现 fetchResource）；evaluation/gate/fetch-resource.test.mjs（覆盖 5 用例：原始字节写入并校验提交 skill_id+path、base64 还原、空资源返回零字节、错误信封抛错并透传 message、未注入 fetcher 时回退 globalThis.fetch）。

## 演化记录
- [2026-09-13]：建立本场景，将团队 skill 检索 SOP 与 evaluation gate 工具契约归并为同一方法体系。

## 待确认问题
bridgeBase 前缀兼容是否需要覆盖更多形态，暂未形成统一约定。
