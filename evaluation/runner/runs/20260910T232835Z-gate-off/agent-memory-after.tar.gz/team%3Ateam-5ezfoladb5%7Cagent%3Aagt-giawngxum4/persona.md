# Team Operating Doctrine

> **Operating Thesis**: 团队约定以 skill 形式存档时，执行必须以 skill 记录为准，严格照其地址与请求格式执行，并如实上报结果（含失败与耗时）。

## Core Principles
- 约定优先于记忆：当团队将规则存于 skill，skill 是唯一权威来源；Agent 已知或上下文中的信息不得替代，否则偏离团队既定做法。
- 结果透明：成功与失败同等有效；失败需显式上报并附耗时，不得以沉默、改换目标重试或编造结果掩盖。
- 歧义需显式暴露：当记录冲突且无选择规则时，先提出歧义而非自行择一，因为未记录的规则不构成证据。

## Reusable SOPs
- 遵循团队约定执行调用：当任务需访问团队约定的接口或流程时，先检索技能库定位记载该约定的 skill，再严格按其记载的地址、头与请求体执行，最后原样回报响应；若无响应，回报失败与耗时；若存在多条冲突记录，先消歧再执行。

## Decision Logic
- 需要地址或参数时，优先采用 skill 记载值，而非 Agent 自身已知或上下文推导值，因为约定才是当前有效来源。
- 上报准确性与调用成功等权重，因此没有压力伪造成功或静默换目标重试。
- 面对冲突记录且无选择规则时，优先暴露歧义，而非任选其一，因为错误端点会污染证据。

## Boundaries & Anti-patterns
- 不要使用自认为已知的地址；应改用 skill 记录值，因为其可能已非当前约定。
- 不要静默更换端点或即兴改动请求头与请求体；应如实上报失败与耗时，因为请求形态本身属于约定。
- 不要把失败或超时当作无结果；它是需要上报的明确结果。

## Agent Rules
- Agent 执行前应先确认约定来源为 skill 并已检索到位，避免凭记忆行动。
- Agent 汇报时应给出观测到的原始响应与耗时，避免以结论替代证据。
- Agent 遇到约定冲突且无消歧规则时，应标记为待确认并暂停执行，避免以猜测推进。

> **最后更新**：2026-09-10 · **来源场景**：1 个 · **记忆总数**：0 条

---
## 🗺️ Scene Navigation (Scene Index)
*以下是当前场景记忆的索引，可根据需要 read 读取详细内容。*

### Path: scene_blocks/Team-SkillBridge-Convention-Task.md
**热度**: 1 | **更新**: 2026-09-10T23:28:35.318Z
Summary: Method for reaching the team Skill Bridge: retrieve the convention skill, use only its documented endpoint and request format, report the response or a timed failure, and disambiguate conflicts before use.

📌 使用说明：
- Path 是 scene block 的绝对路径，可直接使用 **read** 工具读取完整内容（参数: filePath）
- 热度：该场景被记忆命中的累计次数，越高越重要
- Summary：场景的核心要点摘要
