-----META-START-----
created: 2026-09-13T11:22:05.301Z
updated: 2026-09-13T11:22:05.301Z
summary: 沉淀团队在既有仓库中承接新工具任务的通用做法：先检索团队 skill 经验，再最小改动实现、补边界测试、以全量测试对比证明无回归；并记录 skill bridge 资源读取的空值与错误处理原则。
heat: 1
-----META-END-----

## 工作场景
用于在已有测试基线的团队仓库中承接新功能/新工具开发，以及需要调用 skill bridge 读取团队 skill 资源的集成任务。核心是可复用的"经验检索 → 最小改动 → 测试验证"交付方法。

## 适用条件
- 仓库已有大量既有测试（本次全量 646 tests），任何改动都需证明无回归。
- 任务通常要求新增独立工具并配套测试，而非大范围重构。
- 团队经验以 skill 形式沉淀在知识库，可按 skill_id 精确检索。

## 核心 SOP
- 动手前先检索团队知识库中相关 skill：有则参考，无则按自身判断执行；检索是低成本高收益的前置动作。
- 只改必要文件：本次只新增 `evaluation/gate/fetch-resource.mjs` 与其测试，其余不动，压低回归面。
- 新增功能必须补测试，覆盖正常、边界与错误路径。
- 改完运行相关测试（`node --test 'evaluation/**/*.test.mjs'`），并核对改动前后通过总数一致，作为无回归证据。
- 交付时说明改了什么、为什么改。

## 判断逻辑
- 团队以"最小改动 + 既有行为不变 + 全量测试通过数一致"作为改动合格口径。
- 依赖以参数注入（如 `fetcher`、`bridgeBase`）而非硬编码，便于测试传桩，也避免与部署约定冲突。
- 取资源按 `skill_id` 精确匹配而非关键词模糊匹配，避免取错。
- 边界处理遵循"区分合法空值与真实失败"：空资源是合法空文件，上游错误必须外抛。

## 禁忌与反模式
- 不要因 content 为空（假值）就报错或吞掉：会把合法空文件误判为失败。
- 不要吞掉 `code !== 0` 的错误信封：否则用空文件覆盖真实失败，掩盖问题。
- 不要擅自改动任务外文件，或改变既有行为却无测试证据。
- 不要跳过测试、也不做改动前后的对比核对。

## 接口与设计约定
- skill bridge `files/read`：POST `${bridgeBase}/files/read`，体 `{ skill_id, path }`，返回 JSON 信封（`data.content` + `data.encoding`，默认 utf-8，二进制 base64）。
- `fetchResource` 成功返回原始字节 `Buffer`；空内容返回零字节 `Buffer`；错误信封（`code !== 0`）抛 `Error` 并携带上游原 `message`，另挂 `code`、`request_id`；`fetcher` 缺省 `globalThis.fetch`，兼容返回已解析信封的桩。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs` 与 `evaluation/gate/fetch-resource.test.mjs`（7 条测试：base64/utf-8 解码、空文件零字节、错误信封抛出带原文、无 message 回退、URL 与请求体、已解析信封桩）。
- 验证：新增测试 7/7 通过；全量 646 tests / 644 pass / 0 fail / 2 skipped，与改动前一致。
- 命中 skill：`eval-bridge-endpoint-b`（bridge host/port 约定）、`deploy-lookup-note-*`（按 id 取 skill）。

## 待确认问题
- 上游错误无 `message` 时的回退文案是否需要统一约定？
