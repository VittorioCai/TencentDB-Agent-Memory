-----META-START-----
created: 2026-09-13T11:47:05.316Z
updated: 2026-09-13T12:47:19.337Z
summary: 团队 Agent 新增工具的工作方法：动手前检索 skill 知识库、最小改动、补测试并跑全量回归、说明改动；含 fetch-resource 接口契约与 skill-bridge v3 取资源逻辑。
heat: 2
-----META-END-----

## 工作场景
适用于在本仓库（evaluation 等模块）新增或修改工具、Agent 需复用团队既有经验并接受测试验收的协作场景。可复用于任何"新增一个导出函数 + 补测试 + 保持回归"的开发任务，以及需要从 skill 知识库取用资源文件的场景。

## 适用条件
团队把过往经验以 skill 形式沉淀在知识库中（skill-bridge v3）；交付物为 Node/mjs 工具，测试用 `node --test` 跑 `*.test.mjs`；要求改动最小、不破坏已有行为。

## 核心 SOP
- 先检索团队经验：动手前到知识库检索一次（skill/search 按查询、skill/get 按 skill_id，服务 http://127.0.0.1:8096/skill-bridge/v3，get 支持 include_content/include_manifest）；有相关 skill 就参考，没有则按自身判断。
- 检索到相关经验即显式引用：本任务参考了 skill eval-tool-result-exit-line（skl-pXLc38dex6Zt），交付时点名来源便于追溯。
- 最小改动：只改必要文件，不顺手重构无关代码。
- 为新增功能补一条测试，覆盖接口契约与边界。
- 跑回归：`node --test` 跑 evaluation 下全部 `*.test.mjs`，确认基线不退化。
- 交付说明：最后说明改了什么、为什么。

## 判断逻辑
优先检索 skill 而非从零设计：知识库里已有经过验证的实现约定，参考可降低返工。测试被当作验收门槛而非附带工作，因此新增功能必须自带测试并保持全量回归通过。最小改动原则保证评审面小、故障定位容易；错误信息必须向上暴露而非吞掉，便于排查。

## 禁忌与反模式
- 吞掉上游错误：code !== 0 必须抛出携带信封 message 的 Error。
- 把空文件当错误：空资源应返回零字节 Buffer（空文件合法），而非抛错。
- 跳过检索直接自创约定：可能偏离团队既有契约。
- 顺手改动无关文件：违反最小改动，扩大风险面。

## 关键事实依据
- fetch-resource 契约：fetchResource({skillId, path, bridgeBase, fetcher})，向 `{bridgeBase}/files/read` 发 POST（body {skill_id, path}）；按信封 data.encoding 解码（base64 为二进制，否则 UTF-8），成功返回可直接写文件的 Buffer；空资源返回零字节 Buffer；code 非 0 抛 Error；bridgeBase 末尾斜杠去除以免 URL 重复斜杠。
- fetcher 用于注入 HTTP 实现（测试传桩），缺省 globalThis.fetch。
- skill-bridge files/read 信封：{code, message, data:{content, encoding, mime_type}}；code 非 0 失败（如 40401 SKILL_NOT_FOUND）。
- gate 侧需要的是资源文件本身（scripts/、assets/ 等），而非其 JSON 描述。
- 基线：639 测试 / 637 通过 / 0 失败 / 2 跳过，改后不得退化。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs：新增资源获取工具。
- evaluation/gate/fetch-resource.test.mjs：覆盖 6 场景（默认 UTF-8、base64 精确解码、空资源零长度、非零 code 抛错、末尾斜杠、回退 globalThis.fetch）。
- 参考 skill：eval-tool-result-exit-line（skl-pXLc38dex6Zt）。

## 演化记录
- [2026-09-13]：fetch-resource 任务已完成实现与测试，基线未退化；本批 L1 记忆为同一任务的重复表述，未新增方法，仅去重合并并补记 skill-bridge get 的 include_content/include_manifest 与参考 skill 引用。

## 待确认问题
（暂无）
