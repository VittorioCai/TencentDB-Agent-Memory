-----META-START-----
created: 2026-09-11T19:10:51.655Z
updated: 2026-09-11T20:11:13.867Z
summary: 团队以 skill 沉淀经验，动手前先检索复用；缺陷修复 SOP：查根因、按真实输入修复、补回归测试、跑全量、只改必要文件并说明原因。
heat: 2
-----META-END-----

## 工作场景
适用于团队/Agent 在本仓库排查修复缺陷的协作场景：团队把过往经验以 skill 形式沉淀在知识库，期望先复用经验再动手。归因工具（evaluation/attribution）维护可作范例，方法可迁移到其他工具/解析类缺陷。

## 适用条件
- 领到 bug 修复或工具维护类任务时。
- 团队知识库中可能已有相关 skill 经验。
- 需在不破坏既有行为、不引入无关改动的前提下交付。

## 核心 SOP
- 先检索团队经验：动手前查一次团队知识库中以 skill 保存的过往经验，有相关的直接参考，没有才按自身判断执行。
- 定位根因再修：先确认真实输入文本与解析器期望是否一致，而非直接改调用方。
- 按真实数据修复：解析要兼容真实 CodeBuddy 结果（大写 `Exit Code:`），不能只适配手写 fixture。
- 补回归测试：覆盖真实拼写、旧 fixture 拼写、失败状态能否正确传递到采集结果。
- 跑全量验证：`node --test` 跑 evaluation 下所有 *.test.mjs，运行相关测试确认通过。
- 只改必要文件，最后说明改了什么、为什么。

## 判断逻辑
- 优先复用 skill：经验已成结论，重复推导成本高且易再踩坑。
- 面向真实输入修复：大小写之争本质是 fixture 过于理想化，把正则改为大小写不敏感（`/(?:^|\n)Exit code:\s*(\d+)/i`）比新增分支更稳、更小改动。
- 全量测试 + 基线对照：修复前基线通过 547/552，3 个失败与本修复无关（extract-tokens fixture 缺失、缺 gate0/artifacts/*.jsonl）；验收以"不新增失败"为准，避免误算。

## 禁忌与反模式
- 解析器只认单一大小写：真实结果用大写会静默失败，下游按退出状态分类的逻辑整体失效。
- 用理想化 fixture 掩盖缺陷：fixture 恰好用小写，测试全绿却漏掉真实场景。
- 把无关既有失败当成自己引入的问题：应先取基线，区分既有与新增失败。
- 顺手改无关文件或重构：违反"只改必要文件"，增加评审与回归风险。

## 关键事实依据
- 缺陷：collect-artifacts.mjs 第 124 行退出码正则只认小写 `Exit code:`，真实结果用 `Exit Code:`，导致 exit_code 恒为 null。
- 修复：改为大小写不敏感匹配；新增回归测试 collect-artifacts.exit-status.test.mjs（覆盖大写、小写、curl 52 失败传递），新增 3 条通过测试，无新失败。

## 相关任务与资产
- skill：`eval-tool-result-exit-line`（工具结果退出状态解析经验）。
- 文件：evaluation/attribution/collect-artifacts.mjs；回归测试 evaluation/attribution/collect-artifacts.exit-status.test.mjs。

## 演化记录
- [2026-09-11]：将"补回归测试"细化为必须同时覆盖真实拼写、旧 fixture 拼写与失败状态传递三类场景，原因：单一 fixture 拼写曾掩盖真实缺陷。

## 待确认问题
- 基线 3 个既有失败（extract-tokens fixture 缺失、gate0/artifacts/*.jsonl 缺失）是否另有修复计划？
