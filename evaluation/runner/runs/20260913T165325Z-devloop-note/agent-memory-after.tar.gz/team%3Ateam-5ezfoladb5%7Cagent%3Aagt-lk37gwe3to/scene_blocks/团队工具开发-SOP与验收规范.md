-----META-START-----
created: 2026-09-13T16:53:23.973Z
updated: 2026-09-13T16:53:23.973Z
summary: 团队在 evaluation/gate 下开发 Node 工具的可复用 SOP：先检索团队 skill 经验，只改必要文件，遵守接口契约与测试验收规范，改后跑测试并说明改动原因。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库新增/修改工具类模块（典型如 `evaluation/gate/*.mjs`）的开发任务，以及团队围绕"经验沉淀—复用—验收"的协作方式。核心可复用对象不是某一个文件，而是一套"先查经验、再定契约、最小改动、测试兜底、事后说明"的工具开发流程。

## 适用条件
- 任务类型：新增工具、导出可复用函数、改动共享模块行为。
- 团队约束：经验以 skill 存于团队知识库；验收以 `node --test evaluation/**/*.test.mjs` 为准。
- 上下文：存在上游接口缺陷需在调用侧规避时（如 bridge 空内容误判）。

## 核心 SOP
- 动手前先检索一次团队 skill 经验：有相关经验就参考，没有就按自己判断实现；避免重复踩坑。
- 先固定接口契约再写实现：明确入参、返回值类型、错误语义，再落代码。
- 只改必要文件：不顺手重构、不扩大改动面，降低回归风险。
- 为新增工具补一条测试：覆盖成功路径与关键边界。
- 改完运行相关测试：`node --test` 跑 evaluation 下 `*.test.mjs`，确认全部通过且已有行为不变。
- 最后说明改了什么、为什么：交付时显式给出改动清单与理由，便于评审。

## 判断逻辑
- **契约优先**：`fetchResource({ skillId, path, bridgeBase, fetcher })` 成功返回原始字节 `Buffer`（调用方可直接写文件）；空内容返回零字节 Buffer——空文件是合法文件；上游错误信封（`code !== 0`）必须抛 `Error` 且 message 带上信封 message，不得吞掉。
- **可测性设计**：`fetcher` 参数用于注入 HTTP 实现（测试传桩），缺省用 `globalThis.fetch`；把外部依赖作为参数注入，是为了让测试无需真实网络。
- **规避上游缺陷而非改上游**：bridge 的 `files/read` 返回信封 `{ code, message, data: { content, encoding, ... } }`，但 `skill-bridge.ts:820` 把空内容误判为错误；本工具需在调用侧归一化，容忍空文件正常返回。选择"适配"而非"改 bridge"，因为改动面更小、边界更可控。

## 禁忌与反模式
- 不要吞掉上游错误：`code !== 0` 必须抛错并保留原 message，否则调用方无法定位失败。
- 不要把空内容当错误：空文件合法，须返回零字节 Buffer，不能被 bridge 缺陷带着走。
- 不要扩大改动面：只改必要文件，禁止顺手重构无关代码。
- 不要跳过测试或只跑新增测试：须确认既有 `*.test.mjs` 全绿、已有行为不变。
- 不要在不查团队经验的情况下直接实现：先检索 skill 库。

## 关键事实依据
- bridge `files/read` 信封结构：`{ code, message, data: { content, encoding, ... } }`。
- 已知缺陷：`skill-bridge.ts:820` 将空内容误判为错误。
- 资源解码需覆盖 base64 与 utf-8 两种 encoding。

## 相关任务与资产
- 新增资产：`evaluation/gate/fetch-resource.mjs`（导出 `fetchResource`）。
- 配套测试：`evaluation/gate/fetch-resource.test.mjs`，覆盖 base64/utf-8 解码、空内容零字节 Buffer、错误信封抛带 message 的 Error、fetcher 注入。
- 验证方式：`node --test` 运行 `evaluation` 下 `*.test.mjs`。

## 演化记录
（暂无）

## 待确认问题
- `skill-bridge.ts:820` 的缺陷是长期保留并靠调用侧适配，还是后续修复上游？影响 fetchResource 的适配逻辑是否可简化。
