-----META-START-----
created: 2026-09-13T12:09:45.745Z
updated: 2026-09-13T12:09:45.745Z
summary: 团队知识库 skill 资源获取工具（fetchResource）的开发方法：先检索团队经验，再按行为契约实现/测试，保持既有行为不变并说明改动。
heat: 1
-----META-END-----

## 工作场景
适用于在 `evaluation/gate/` 下为团队知识库（team skill bridge）开发工具类模块的场景，典型是"把远端 skill 资源取到本地"的取数工具。方法论核心：**先复用团队经验，再按明确行为契约实现并配套测试**，可直接迁移到其他 bridge/CLI 工具开发。

## 适用条件
- 团队把过往经验以 skill 形式存入团队知识库，成员实现前应先检索一次：有相关经验就参考，没有就按自身判断推进。
- 任务边界明确、已有测试基线的仓库（`evaluation/` 下存在 `*.test.mjs`）。
- 需要与既有接口信封/编码约定对齐的对接类工具。

## 核心 SOP
- 动手前先检索团队 skill：命中即参考，未命中再自行判断，避免重复踩坑。
- 定义清晰的导出契约：`fetchResource({ skillId, path, bridgeBase, fetcher })`，把 HTTP 实现通过 `fetcher` 注入，缺省用 `globalThis.fetch`，便于测试传桩。
- 实现调用约定：以 `${bridgeBase}/files/read` 发起 POST，body 为 `{ skill_id, path }`。
- 解码还原：读取信封 `data.content`，按 `encoding`（utf-8 或 base64）解码后返回 Buffer，供调用方直接写文件。
- 补一条对应测试，覆盖正常、边界、异常三类路径。
- 收尾三件事：`node --test` 跑通 `evaluation/` 下全部 `*.test.mjs`；确认已有行为不变；只改必要文件并说明改了什么、为什么。

## 判断逻辑
- 用 `fetcher` 注入而非直接调用 fetch：让测试可传桩，隔离网络不确定性。
- 错误信封不做兜底、原样抛出：避免吞错导致上游失败被静默掩盖，保证调用方能拿到真实原因。
- "空资源是合法文件"：把空内容与错误区分开，边界语义靠返回零字节 Buffer 而非抛错表达。

## 禁忌与反模式
- 不要吞掉上游错误：信封 `code !== 0` 时必须抛 Error 且 message 携带信封 message，否则排障链断裂。
- 不要把 base64 文本当结果返回：必须解码还原为原始字节，否则下游写出的文件损坏。
- 不要对空资源抛错：空文件合法，应返回零字节 Buffer。
- 不要顺手重构或改动无关文件：只改必要文件，保持既有行为不变是硬约束。
- 不要跳过 `node --test` 全量验证就交付。

## 关键事实依据
- 接口契约：`/files/read` POST `{ skill_id, path }` → 信封 `{ code, message, data: { path, content, encoding, size_bytes } }`；`content` 为文本，编码 utf-8，非文本内容用 base64，由调用方解码还原。
- 交付物：`evaluation/gate/fetch-resource.mjs` 与 `evaluation/gate/fetch-resource.test.mjs`。
- 测试覆盖四类场景：utf-8 原始字节、base64 解码为原始字节、空资源返回零字节 Buffer、错误信封抛出携 message 的 Error。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`（实现）、`evaluation/gate/fetch-resource.test.mjs`（测试）。

## 演化记录
（空）

## 待确认问题
（空）
