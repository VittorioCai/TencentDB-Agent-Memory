-----META-START-----
created: 2026-09-13T11:16:28.474Z
updated: 2026-09-13T11:16:28.474Z
summary: 本仓库团队的增量开发复用方法：动手前先检索 skill 知识库经验，最小改动实现工具，配套测试并保证既有测试全过、行为不变，最后说明改动与原因；含 fetchResource 契约与 skill-bridge v3 信封要点。
heat: 1
-----META-END-----

## 工作场景
适用于在本仓库（尤其 evaluation/gate/ 等模块）做增量开发、新增小工具/脚本的任务，特别是需要调用团队 skill-bridge 读取 skill 资源文件的工具。核心不是功能本身，而是一套可复用交付流程：先检索团队经验 → 最小改动实现 → 测试保证行为不变 → 说明改动与原因。

## 适用条件
- 团队把过往经验以 skill 形式存放在团队知识库，可通过 skill-bridge 检索接口按查询词搜索。
- 任务属已有仓库范围内的增量开发，且仓库已有测试套件作为回归基线。
- 由 Agent 或工程师执行，需自行判断是否有可参考经验。

## 核心 SOP
1. 动手实现前先检索一次团队知识库的 skill 经验：有相关的就参考，没有则按自身判断执行。
2. 只修改必要的文件，避免无关改动。
3. 新增工具必须配套至少一条测试。
4. 改完运行相关测试（`node --test` 跑 evaluation 下 `*.test.mjs`），确认全部通过且已有行为不变。
5. 交付时说明改了什么、为什么。

## 判断逻辑
- 工具契约设计以「可测试、失败可见、语义明确」为取舍标准：成功返回原始字节 Buffer（调用方可直接写文件）；空资源返回零字节 Buffer（空文件合法，非错误）；上游错误信封 code !== 0 必须抛 Error 并保留信封 message，不得吞掉；fetcher 参数注入 HTTP 实现（测试传桩），缺省 globalThis.fetch。
- skill-bridge v3 信封：bridge base 形如 `<proxy>/skill-bridge/v3/skill`；向 `{bridgeBase}/files/read` POST `{ skill_id, path }`，返回 `{ code, message, data: { content, encoding, ... } }`；按 encoding 解码（base64 → `Buffer.from(content,"base64")`，否则 utf-8），解码后 Buffer 即写盘内容；非 JSON 响应需显式报错。

## 禁忌与反模式
- 不检索团队经验就动手：易重复造轮子或违背既有约定。
- 吞掉上游错误信封（code !== 0 静默忽略）：掩盖失败，应抛 Error 并带 message。
- 把空资源当错误：空文件合法，应返回零字节 Buffer。
- 顺手改无关文件：违反「已有行为不变」约束。
- 改完不跑测试/不说明原因：无法证明无回归。

## 关键事实依据
- 产出：新增 `evaluation/gate/fetch-resource.mjs`（导出 fetchResource）与 `evaluation/gate/fetch-resource.test.mjs`（覆盖成功返回字节+POST 契约、空资源零字节、base64 解码、错误信封抛错）。
- 验证：evaluation 套件 643 项全过、0 失败，无回归；git status 核对仅目标文件被改。
- 参考的团队 skill 资产：skl-KPVMV2uB5rXM（deploy-lookup-note-a）、skl-oBaDO5CceKnr（eval-bridge-endpoint-b），同类任务可优先查看。

## 相关任务与资产
- fetch-resource.mjs / fetch-resource.test.mjs（已交付）
- 团队知识库 skill 检索接口（skill-bridge）

## 演化记录
（暂无）

## 待确认问题
- skill-bridge 检索接口的查询词约定与返回结构未在本批记忆中明确。
