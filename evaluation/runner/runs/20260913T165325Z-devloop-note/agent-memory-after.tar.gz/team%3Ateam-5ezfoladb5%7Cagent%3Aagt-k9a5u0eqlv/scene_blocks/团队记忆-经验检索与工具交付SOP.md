-----META-START-----
created: 2026-09-13T12:38:24.650Z
updated: 2026-09-13T13:50:07.998Z
summary: 团队在既有仓库新增/修改小工具的交付工作法：动手前先检索经验 skill，按显式接口契约实现，以既有绿色测试基线验收，只改必要文件并说明改动与原因。
heat: 3
-----META-END-----

## 工作场景
适用于在既有仓库中新增或修改小工具、接口、脚本的交付任务（典型案例：evaluation/gate/fetch-resource.mjs）。这套方法体系由三条支柱构成：先检索团队经验 skill、按不可含糊的接口契约实现、按既有测试套件验收交付。可复用于任何"小增量 + 强兼容"的工程改动。

## 适用条件
- 团队把过往经验以 skill 形式沉淀在知识库，成员需主动检索而非被通知。
- 仓库已有绿色测试基线可作回归参照（本仓库：node --test 下 637 通过 / 2 跳过 / 0 失败）。
- 任务约束为最小改动、行为兼容、需要交付说明。

## 核心 SOP
- 检索优先：动手实现前先检索一次团队经验 skill，有相关经验就参考，没有则按自身判断执行；本任务命中 `eval-skill-resource-download`（skill_id: skl-XAzqAgejM7O4，token bt-pvxahxcppk3）。
- 契约先行：先固化接口签名与语义再写实现，`export async function fetchResource({ skillId, path, bridgeBase, fetcher })`。
- 契约语义：成功返回资源原始字节 Buffer（调用方可直接落盘）；内容为空返回零字节 Buffer（空文件是合法文件）；上游错误信封 code !== 0 时抛出 Error 且 message 携带信封 message，不得吞掉；fetcher 用于注入 HTTP 实现（测试传桩），缺省 globalThis.fetch。
- 补测试：为新增功能补一条测试，HTTP 桩通过 fetcher 注入。
- 验收：运行 evaluation 下全部 *.test.mjs（node --test），确认现有测试全通过、已有行为不变。
- 交付说明：完成后明确说清改了什么、为什么。

## 判断逻辑
- 经验优先：经验 skill 记录的是已踩过的坑（如两条读取路径不可互换），复用成本远低于重新试错。
- 契约先行：先把错误处理与空内容语义定义清楚，可规避"吞错误"和"空文件误判"两类典型隐患。
- 兼容优先：以既有绿色基线为验收口径，只做增量改动，把回归风险压到最低。
- 错误不静默：错误信封必须向上抛出并保留原始 message，由调用方处理。

## 禁忌与反模式
- 用 files/read 取二进制资源：它返回 JSON 信封，落盘后得到一个一执行就失败的 JSON 文件；取资源文件必须走 files/download。
- 用 `!parsed.data?.content` 判空：空串是 falsy，合法空资源会被整包错判为信封；应把字符串 content（含空串）视为有效内容，只有 content 缺失或类型非字符串时才判为异常信封。
- 吞掉 code !== 0 的错误信封：必须抛出 Error 并带出信封 message。
- 用 curl -o 试图改变路由：它是客户端标志，服务端看不到，不影响路由选择。
- 硬编码 HTTP 实现（应经 fetcher 注入）；超范围改动或破坏既有行为。

## 关键事实依据
- skill-bridge 两条不可互换的读取路径：files/read 返回 JSON 信封 { code, data: { content, encoding } }；files/download 直接返回原始字节。download 分支以 !parsed.data?.content 判空，导致合法空资源被整包返回。
- 交付物：evaluation/gate/fetch-resource.mjs，走 files/download 取原始字节，兼容以信封形式返回的成功结果（含空内容），code !== 0 时抛出携带信封 message 的 Error。
- 实现前基线：evaluation 测试 637 通过 / 2 跳过 / 0 失败。

## 相关任务与资产
- 经验 skill：eval-skill-resource-download（skill_id: skl-XAzqAgejM7O4）。
- 待跟进：为 fetch-resource.mjs 补一条测试，并复跑 evaluation 下全量 *.test.mjs 验证 green。

## 演化记录
- [2026-09-13]：合并原 "团队经验检索与Eval工具交付规范" 与 "团队记忆-经验检索与工具交付SOP" 两份同体系文档，并补充 skill-bridge 读取路径选择与空内容处理经验。

## 待确认问题
- bridgeBase 的取值与语义未明确，需与上游约定确认。
- path 与 skillId 的取值规则、错误信封的具体结构待补充。
- `evaluation/*.test.mjs` 与 `evaluation/**/*.test.mjs` 的匹配范围是否等价，需在交付验证时确认，避免漏跑子目录测试。
