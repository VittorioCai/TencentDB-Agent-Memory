-----META-START-----
created: 2026-09-13T12:31:56.091Z
updated: 2026-09-13T12:31:56.091Z
summary: evaluation 目录下新增工具的交付 SOP 与团队 skill 经验检索约定，涵盖 bridge 资源读取协议、信封失败判定与空文件合法等判断逻辑。
heat: 1
-----META-END-----

## 工作场景
适用于在 evaluation/ 目录（尤其 evaluation/gate/）开发新工具、并按团队约定先检索团队 skill 经验再动工的完整链路：检索经验 → 参考同类资产 → 按交付规范实现 → 用测试验收。可复用于任何 evaluation 工具类任务。

## 适用条件
- 仓库团队把过往经验以 skill 形式保存在团队知识库中
- 任务类型：新增/修改 evaluation 下小工具（如把 skill 资源取到本地的 fetch-resource.mjs）
- Agent 无先验经验时，检索无结果则按自身判断执行

## 核心 SOP
- 动手前先检索一次团队 skill 经验：有相关就参考，无则自行判断
- 参考既有同类资产：evaluation/gate/plan-visibility.mjs 及其测试、evaluation/attribution/collect-artifacts.mjs，沿用既有实现风格与测试组织方式
- 实现时只改必要文件
- 新增工具必须补一条对应测试
- 验收：node --test 跑 evaluation 下所有 *.test.mjs 必须全部通过、已有行为不变
- 交付说明写清改了什么、为什么

## 判断逻辑
- skill 检索接口：POST /skill-bridge/v3/skill/search（检索）或 POST /skill-bridge/v3/skill/get（请求体带 skill_id、include_content、include_manifest）；两者请求头均需 x-tdai-service-id 与 x-conversation-id
- 资源读取协议：POST <bridgeBase>/files/read，bridgeBase 形如 http://127.0.0.1:47318/skill-bridge/v3/skill（末尾斜杠需剔除），请求体 JSON { skill_id, path }，响应信封 { code, message, data:{ content, encoding } }
- 编码：encoding=base64 表示二进制内容，utf-8 表示文本内容；按 encoding 解码 content 得到原始字节 Buffer 返回给调用方直接写文件
- 失败判定只看信封 code（非 0 即失败），message 需完整透传

## 禁忌与反模式
- 用 content 是否为空判断失败：空文件是合法结果（content:""），该做法会把每个空文件误判为失败；proxy 的 files/download 分支即此反模式，应改用 code 判断
- 吞掉上游错误：code !== 0 必须抛 Error 且 message 携带信封 message
- 硬编码网络实现：fetcher 缺省用 globalThis.fetch，须可注入桩供测试
- 只加功能不补测试、破坏既有行为、改动无关文件

## 关键事实依据
- 接口契约：export async function fetchResource({ skillId, path, bridgeBase, fetcher })；成功返回资源原始字节 Buffer，空资源返回零字节 Buffer
- 产出资产：evaluation/gate/fetch-resource.mjs 与 fetch-resource.test.mjs，测试覆盖 base64 二进制解码、空/缺失 content 返回零字节 Buffer、code 非 0 抛出带信封 message 的错误、POST skill_id 与 path 到 <bridgeBase>/files/read；新增测试已通过
- 该失败判定经验参考自团队 skill eval-tool-result-exit-line（解析器误读真实信封的同类陷阱）

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs（已交付）、evaluation/gate/fetch-resource.test.mjs（已通过）
- 参考资产：evaluation/gate/plan-visibility.mjs、plan-visibility.test.mjs、evaluation/attribution/collect-artifacts.mjs

## 演化记录
- [2026-09-13]：将"用 content 真值判断 bridge 读取失败"确认为反模式，统一改为"只依信封 code 判定"。

## 待确认问题
- search 与 get 两个检索接口的取舍边界尚未明确（何时用检索、何时用按 id 获取）。
