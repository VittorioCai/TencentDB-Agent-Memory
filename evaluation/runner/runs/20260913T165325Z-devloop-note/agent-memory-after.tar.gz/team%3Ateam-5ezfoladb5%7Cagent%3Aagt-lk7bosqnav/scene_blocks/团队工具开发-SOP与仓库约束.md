-----META-START-----
created: 2026-09-13T16:55:17.446Z
updated: 2026-09-13T16:55:17.446Z
summary: 团队仓库内新增工具模块的通用做法：先检索团队知识库 skill 经验，再按可注入依赖的接口契约实现、补测试、跑全量测试并说明改动，保持既有行为不变。
heat: 1
-----META-END-----

## 工作场景
适用于在团队仓库中新增或修改工具模块的任务：需要先检索团队知识库的 skill 经验，再实现一个具备明确接口契约、可被单测覆盖的纯函数/工具，并在不破坏既有行为的前提下交付。典型实例是在 `evaluation/gate/` 下新增 `fetch-resource.mjs`。Agent 接到同类任务时按本文件执行。

## 适用条件
- 仓库已有测试套件与既有行为，改动必须向后兼容。
- 团队把过往经验以 skill 形式存放在团队知识库，可被检索引用。
- 交付物是需要可测试性的工具，外部依赖（网络等）可通过参数注入。

## 核心 SOP
1. 先检索团队经验：动手前查一次团队知识库 skill；有相关经验则参考执行，没有则按自身判断做，不因无经验而阻塞。
2. 先定契约再实现：明确入参 `{ skillId, path, bridgeBase, fetcher }` 与各返回路径的语义。
3. 依赖注入优先：HTTP 实现通过 `fetcher` 注入，缺省 `globalThis.fetch`，使测试可传桩、无需真实网络。
4. 补测试：为新增工具至少补一条测试，覆盖正常、空内容、错误信封三类路径。
5. 跑全量测试：`node --test` 跑 `evaluation` 下所有 `*.test.mjs`，确认既有行为不变。
6. 收尾说明：只改必要文件，并说明改了什么、为什么。

## 判断逻辑
- 先检索再动手：复用既有 skill 结论可避免重复踩坑；检索是动作前置项而非可选项。
- 以“全量测试通过 + 既有行为不变”为唯一验收口径，因此宁少改不多改，只动必要文件。
- 把网络依赖外置（`fetcher` 可注入）是实现可测性的关键取舍：契约稳定、测试无需真实上游。

## 禁忌与反模式
- 吞掉上游错误：上游错误信封（`code !== 0`）必须抛 `Error` 且 `message` 携带信封 `message`；静默返回空值会让调用方误判成功。
- 把空资源当异常：资源为空是合法的空文件，应返回零字节 `Buffer` 供直接写盘，而非 `null` 或抛错。
- 擅自改契约（返回形态、函数名、入参）：会连带破坏调用方与既有测试。
- 未跑测试即交付：必须先运行相关测试确认通过，再说明改动内容与原因。

## 关键事实依据
- 任务：`evaluation/gate/` 新增 `fetch-resource.mjs`，导出 `fetchResource({ skillId, path, bridgeBase, fetcher })`，把团队知识库中 skill 的资源文件取到本地。
- 行为约定：成功返回资源原始字节 `Buffer`；内容为空返回零字节 `Buffer`；错误信封抛 `Error` 并携带其 `message`；`fetcher` 缺省 `globalThis.fetch`。
- 可参考 skill：`eval-skill-resource-download`（skl-XAzqAgejM7O4）、`eval-bridge-endpoint-b`（skl-oBaDO5CceKnr）。
- 仓库约束：`evaluation` 下 `*.test.mjs` 全部通过，仅改必要文件，收尾说明改动与原因。

## 相关任务与资产
- 待交付：`evaluation/gate/fetch-resource.mjs` 及其配套测试。
- 相关资产：上述两个 skill、`evaluation` 下 `*.test.mjs` 测试套件。

## 演化记录
（空）

## 待确认问题
- `fetcher` 桩的返回形态（原始字节还是错误信封）与 `bridgeBase` 的路径拼接规则未在本批记忆中明确，实现前需确认。

[PERSONA_UPDATE_REQUEST]
reason: 团队级约定“动手实现前先检索团队知识库 skill 经验，有则参考、无则自主判断”是跨任务复用的稳定规则，应从项目层升级为 L3 Team Operating Memory 中的 Agent 执行前置规则。
[/PERSONA_UPDATE_REQUEST]
