-----META-START-----
created: 2026-09-13T12:52:15.979Z
updated: 2026-09-13T13:52:33.632Z
summary: 沉淀仓库内"新增工具类任务"的实现流程（先检索团队 skill、只改必要文件、补测试、跑全量套件、说明改动），以及 skill 资源下载走 files/download、空文件合法、错误信封透传的契约与信封识别规则。
heat: 3
-----META-END-----

## 工作场景
适用于遵循"把过往经验以 skill 形式存入团队知识库"这一约定的仓库：当需要新增一个工具/工具类模块（如 evaluation/gate 下的 *.mjs）、并为其配套测试时，按本场景的流程与契约执行。其中"资源获取与信封处理"部分可复用于任何通过 skill-bridge 取 skill 资源原始字节的下载类工具。

## 适用条件
- 仓库约定：动手实现新功能前先检索一次团队知识库中的相关 skill。
- 任务类型：新增小工具模块 + 补测试，且不得破坏既有行为。
- 调用链：工具经 skill-bridge 访问 skill 资源，需可注入 HTTP 实现以便测试。

## 核心 SOP
- 先检索团队经验：有相关 skill 就以其为实现依据，没有则按自身判断执行 → 避免重复造轮子并保持团队一致。
- 只改必要文件，控制改动面 → 降低破坏既有行为的风险。
- 为新工具补至少一条测试，覆盖关键分支 → 用测试固化行为契约。
- 运行 evaluation 下全部 `*.test.mjs`（`node --test`）确认通过 → 验证未回归。
- 交付时说明改了什么、为什么 → 便于 review 与追溯。
- 取资源原始字节走 `files/download`，不用 `files/read` → 后者面向解析，始终返回 JSON 信封。
- 用 `fetcher` 参数注入 HTTP 实现，缺省 `globalThis.fetch` → 测试可传桩。

## 判断逻辑
- 桥按 subpath 路由：`files/read` 始终返回 JSON 信封，`curl -o` 也无法改变；要拿原始字节必须用 `files/download`。
- 空文件是合法文件：空 content 应解码为零字节 `Buffer`，而非报错或把信封写盘；只有 content 缺失或非字符串才算异常。
- 上游错误信封（`code !== 0`）必须抛 `Error` 并透传信封 `message` → 调用方能感知上游失败。
- 信封识别从"数字 code + 字符串 message"放宽为"数字 code +（字符串 message 或对象 data）" → 确保缺 message 的错误信封仍能被识别并抛错；不匹配该结构的 JSON 仍按原始字节处理。
- 返回 `Buffer` 而非解析结果，是让调用方可直接写文件，保持工具职责单一。
- 以 `fetcher` 参数注入 HTTP 实现而非硬编码 `globalThis.fetch`：让测试可传桩、可断言请求且不依赖网络。
- 空资源与错误信封必须分开处理：空 content 属成功（零字节），`code !== 0` 才是失败，不可用同一分支判定。

## 禁忌与反模式
- 用 `files/read` 或 `curl -o` 保存资源：会得到 JSON 文件而非目标内容。
- 把空资源当缺失或报错：空文件合法；仅 content 缺失/非字符串才算异常。
- 吞掉上游错误信封的 message：应原样透传，不得静默。
- 把 bridge 对空资源返回的完整信封当作失败或直接写盘：该信封应视为成功并解码为零字节。
- 在新增工具时顺手改动无关文件：违反"只改必要文件"。

## 关键事实依据
- 对外接口：`export async function fetchResource({ skillId, path, bridgeBase, fetcher })`，用途是把团队 skill 的资源文件取到本地。
- `evaluation/gate/fetch-resource.mjs` 已实现：含 `DOWNLOAD_SUBPATH` 常量、`readBytes`/`parseEnvelope` 辅助函数及 `fetchResource` 主逻辑（校验 skillId/path/bridgeBase、POST files/download、解析信封、空内容返回零字节 Buffer、错误信封抛错、非信封且 `res.ok===false` 抛 HTTP 错误）。
- 测试 `fetch-resource.test.mjs` 覆盖 5 用例：成功返回原始字节并 POST files/download、空资源零字节 Buffer（信封与原始字节两种形式均接受）、base64 信封解码、错误信封抛带 message 的 Error、缺省 fetcher 使用 `globalThis.fetch`。
- 全量 evaluation 套件结果：642 pass / 0 fail / 2 既有 skip，证明新增未破坏既有行为。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`、`evaluation/gate/fetch-resource.test.mjs`
- 团队经验 skill：`eval-skill-resource-download`（skill_id: skl-XAzqAgejM7O4）

## 演化记录
- [2026-09-13]：功能定位明确为"取团队 skill 资源文件到本地"，对外签名固定为 `fetchResource({ skillId, path, bridgeBase, fetcher })`；行为契约（原始字节 Buffer / 空内容零字节 / 错误信封透传 message / fetcher 可注入）经 5 用例测试固化。
- [2026-09-13]：补测试任务由进行中转为完成——已交付 `fetch-resource.test.mjs`（5 用例）并跑通全量套件（642 pass / 0 fail / 2 skip），据此确认「先补测试、再跑全量套件」可作为新增工具的收口标准。
- [2026-09-13]：信封识别规则由"数字 code + 字符串 message"放宽为"数字 code +（字符串 message 或对象 data）"，原因：确保缺 message 的错误信封也能被识别并抛错。

## 待确认问题
- bridge 对空资源返回完整信封的行为是否会被上游修复，fetchResource 是否需长期兼容该分支。
