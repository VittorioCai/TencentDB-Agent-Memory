-----META-START-----
created: 2026-09-13T12:42:44.137Z
updated: 2026-09-13T13:53:58.922Z
summary: evaluation/gate 下新增 fetch-resource.mjs 的实现与交付 SOP：接口契约、边界行为、补测试与保持既有测试全绿的执行口径。
heat: 3
-----META-END-----

## 工作场景
适用于本仓库 `evaluation/gate/` 下新增工具模块（以 `fetch-resource.mjs` 为代表）的实现与交付：需要为团队 skill 资源取回本地、补齐单元测试，并在不破坏既有行为的前提下合并。该模式可复用到同目录任何新工具的开发。

## 适用条件
- 在既有 `evaluation/` 目录内新增模块，目录下已有 `*.test.mjs`。
- 交付要求"只改必要文件、既有行为不变"。
- 接口需要注入 HTTP 实现以便测试。

## 核心 SOP
- 先检索团队经验（见"团队知识库-Skill检索与资源拉取"），命中即参考，未命中按判断实现。
- 定义并锁定导出契约：`fetchResource({ skillId, path, bridgeBase, fetcher })`，调用方能把返回值直接写入文件。
- 通过 `bridgeBase` 发起 `POST {bridgeBase}/files/download`（body `{ skill_id, path }`）取资源。
- 注入 HTTP：`fetcher` 参数用于测试传桩，缺省回退 `globalThis.fetch`。
- 补一条针对新工具的测试，覆盖成功、空、错误、非信封等分支。
- 收尾自检：运行 `node --test` 跑通 `evaluation/` 下全部 `*.test.mjs`，确认既有行为不变，最后说明改了什么、为什么。
- 交付物只含工具与其测试两份文件，交付说明写清改动内容与原因，便于评审对照。

## 判断逻辑
接口契约以"调用方零适配"为口径：成功直接返回 Buffer 便于落盘；空内容返回零字节 Buffer 而非 null/报错，保证调用方逻辑统一。错误处理以"不吞错"为底线：上游 `code !== 0` 时抛出 Error 且 message 携带信封 message，避免把失败伪装成空数据。注入 `fetcher` 是为了让测试无需真实网络即可覆盖解码与错误分支。投递策略上优先保证既有测试全绿，只改必要文件，避免为新增功能引入回归面。

## 禁忌与反模式
- 不要把空资源（`content: ""`）当异常或返回信封：空文件合法，应返回零字节 Buffer。
- 不要吞掉错误信封 message：必须抛出且透传。
- 不要只看 HTTP 状态码判断成功：按响应体形状识别信封。
- 不要改动与本次无关的文件：只改必要文件，保持既有行为不变。
- 不要略过测试自检：必须实际运行 `node --test` 并说明改动理由。
- 不要为新增功能改端口径或重构无关代码：保持既有行为不变是第一约束，改动面越小回归风险越低。

## 关键事实依据
- 新增：`evaluation/gate/fetch-resource.mjs`（工具）与 `evaluation/gate/fetch-resource.test.mjs`（测试）。
- 测试覆盖：base64 与 UTF-8 解码、空资源返回零字节 Buffer、错误信封抛错且不吞 message、非信封原始响应原样返回、信封缺 `content` 报错、`fetcher` 缺省用 `globalThis.fetch`。
- 实现按 `data.encoding`（base64/utf8）解码 `data.content`。

## 相关任务与资产
- 测试入口：`node --test` 运行 `evaluation/` 下 `*.test.mjs`。
- 参考资产：skill `eval-skill-resource-download`、bridge 端点约定 skill。

## 演化记录
- [2026-09-13]：确立空文件返回零字节 Buffer、错误必须抛出不吞、`fetcher` 可注入三条契约。
- [2026-09-13]：多批 L1 记忆对同一契约反复描述，内容一致，视为契约已稳定，不再引入新变体。
- [2026-09-13]：又一批 L1 记忆再次复述同一契约与交付口径（接口签名、空文件、错误信封、fetcher 注入、只改必要文件+补测试），无新增语义，仅刷新热度，不扩写正文。

## 待确认问题
- 除 base64/utf8 外是否还需支持其他 `data.encoding`？未声明时默认如何解码？
