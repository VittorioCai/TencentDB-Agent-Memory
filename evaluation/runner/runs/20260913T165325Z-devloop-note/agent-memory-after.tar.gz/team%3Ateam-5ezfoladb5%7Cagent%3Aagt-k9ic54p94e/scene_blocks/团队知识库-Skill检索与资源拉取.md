-----META-START-----
created: 2026-09-13T12:42:44.137Z
updated: 2026-09-13T13:53:58.922Z
summary: 团队以 skill 沉淀经验，动手前先检索；资源拉取只走 files/download，按响应体形状判信封，空文件视为合法成功。
heat: 3
-----META-END-----

## 工作场景
适用于在本仓库任何"动手实现"类任务：团队把过往经验以 skill 形式沉淀在团队知识库中，成员在编码前需先检索一次团队经验并复用；当需要把某个 skill 的资源文件取到本地时，按 bridge 的接口约定拉取。该方法是跨任务通用的前置动作，不限于单一工具。

## 适用条件
- 任务属于实现/修改类工作，尚未动手编码。
- 不确定团队是否已有同类经验或现成资产。
- 需要从团队知识库读取 skill 的资源文件（二进制或文本）。

## 核心 SOP
- 先检索再动手：调用 `POST /skill-bridge/v3/skill/search`，请求头带 `content-type`、`x-tdai-service-id`、`x-conversation-id`，请求体传 `query` 字段。查询词用任务关键词串联（如 `fetch resource bytes Buffer error envelope HTTP fetcher`）。
- 检索结果分流：命中相关 skill 就参考其做法；没有相关经验则按自身判断执行，不为"凑检索"而绕路。
- 命中相关 skill 后按需取详情：用 `/skill/get` 读取 skill 正文与资产，作为实现参考再落代码。
- 取资源必须用 download 接口：`POST {bridgeBase}/files/download`，body 为 `{ skill_id, path }`。只有该接口返回资源原始字节。
- 判信封按下游响应体形状，而非 HTTP 状态码：带数字 `code` 的 JSON 对象视为信封，`code !== 0` 抛错，`code === 0` 按 `data.encoding`（base64/utf8）解码 `data.content`；非信封则直接返回原始字节。

## 判断逻辑
经验沉淀的成本高于一次性搜索，因此"先检索"是默认动作而非可选动作。取资源时接口选择优先于客户端技巧：服务端返回什么内容由接口决定，客户端的 `curl -o` 无法改变返回体，所以必须挑对接口而非硬改输出方式。空文件是合法资源（Core 的 schema 未加 `.min(1)`，有意接受零字节），因此把所有空内容一律当异常会误伤正常用例。

## 禁忌与反模式
- 不要用 `files/read` 取原始字节：它始终返回 JSON 信封，加 `curl -o` 也无效。
- 不要把空文件当错误：`content: ""` 是合法零字节资源，应视为成功。
- 不要吞掉错误信封：上游 `code !== 0` 时必须抛出 Error 并携带信封 message。
- 不要只看 HTTP 状态码判成功：bridge 对 download 的成功判断 `!parsed.data?.content` 会把合法空文件误判异常并回吐整个信封，需在客户端规避。

## 关键事实依据
- 相关 skill：`eval-skill-resource-download`（skl-XAzqAgejM7O4，tracking value bt-pvxahxcppk3）与 bridge 端点约定 skill（skl-oBaDO5CceKnr），可用 `/skill/get` 获取。
- bridge 的 download 成功判断缺陷会误伤空文件，已由客户端兼容处理。

## 相关任务与资产
- skill-bridge 检索与下载接口约定文档、上述两个 skill。
- 依赖方：`evaluation/gate/fetch-resource.mjs` 的资源拉取实现。

## 演化记录
- [2026-09-13]：确认取原始字节只能走 `files/download`，`files/read` 加 `curl -o` 无效，写入约定。
- [2026-09-13]：多批 L1 记忆重复描述同一检索/拉取约定，内容一致，视为方法已稳定，无需扩写。
- [2026-09-13]：新一批 L1 记忆再次复述检索端点、下载接口与空文件判据，语义与既有条目一致，确认方法稳定，仅刷新热度。

## 待确认问题
- bridge 端 `!parsed.data?.content` 的成功判断是否会修复？若修复，客户端空文件兼容逻辑是否需调整？
