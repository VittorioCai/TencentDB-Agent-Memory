-----META-START-----
created: 2026-09-13T11:41:18.292Z
updated: 2026-09-13T12:52:25.439Z
summary: 沉淀仓库工具脚本的开发SOP与接口契约：动手前先检索团队skill经验，接口用依赖注入保可测试，错误信封不吞错、空资源视零字节，编码按 encoding 解码，交付前全量跑 node --test。
heat: 3
-----META-END-----

## 工作场景
适用于在团队仓库中新增/修改工具脚本的协作场景，典型如在 evaluation/gate/ 下新增 .mjs 工具并补配套测试。方法体系有两条：动手前的团队经验检索惯例，以及工具接口契约的设计规范（依赖注入、错误信封与边界语义处理）。

## 适用条件
- 任务需调用上游接口（如 skill-bridge 的 files/read）把远端资源取回本地。
- 团队以 skill 形式保存历史经验，存在可检索的知识库。
- 需求强调增量交付：只改必要文件、已有行为不变。
- 以 node --test 作为测试驱动。

## 核心 SOP
- 动手前检索团队经验一次：命中就参考，未命中按自己判断实现。
- 先读上游接口契约源码（如 MemoryProxy/src/skill/skill-bridge.ts）再写调用。
- 接口用依赖注入：fetcher 参数注入 HTTP 实现，缺省回退 globalThis.fetch。
- 工具与测试成对放置并同名前缀（<name>.mjs + <name>.test.mjs），便于定位与全量回归。
- 为新增工具补一条测试，覆盖关键边界（原始字节、编码解码、空资源、错误信封、尾斜杠、缺省回退）。
- 改完即运行相关测试，再用 node --test 跑 evaluation 下全部 *.test.mjs，确认全过且已有行为不变。
- 交付时说明改了什么、为什么。

## 判断逻辑
- 依赖注入是为可测试性：测试传桩即可，无需真实网络。
- 信封 code !== 0 视为错误，必须抛 Error 并带上信封 message，避免静默失败掩盖上游问题。
- 空资源是合法文件，返回零字节 Buffer 而非报错，避免把"空"误判为"失败"。
- bridgeBase 拼接前去掉尾部斜杠，避免 //files/read 这类错误。
- 按 encoding 解码而非默认当文本：base64 走 base64，其他走 utf-8，否则二进制资源会被损坏。

## 禁忌与反模式
- 不检索团队经验就动手：易重复造轮子或违背既有约定。
- 吞掉上游错误信封：调用方会拿到空/错数据却以为成功。
- 把空资源当错误抛出：空文件是合法输入。
- 硬编码 fetch 而不留注入点：测试无法用桩，可测性下降。
- 大范围改动无关文件：违背"只改必要文件、行为不变"。

## 关键事实依据
- fetchResource({ skillId, path, bridgeBase, fetcher })：成功返回原始字节 Buffer（可直接写文件）；空资源返回零字节 Buffer；code !== 0 抛 Error。
- skill-bridge files/read 返回信封 { code, message, data: { path, content, encoding, size_bytes, mime_type, version } }；content 按 encoding 解码（base64→base64，其他→utf-8）。
- 交付物：evaluation/gate/fetch-resource.mjs 与 fetch-resource.test.mjs，测试覆盖原始字节、base64 解码、空资源零字节、错误信封抛错、bridgeBase 尾斜杠、fetcher 缺省回退。

## 相关任务与资产
- 实现前命中的参考 skill：deploy-lookup-note-b（skl-eM1xP28pXiYA）、eval-bridge-endpoint-b（skl-oBaDO5CceKnr）。

## 演化记录
- [2026-09-13]：本场景由同批 fetch-resource 记忆（接口契约、skill 检索惯例、交付要求、命中的参考 skill）归纳而成；未与既有规则冲突，故仅补充交付命名与编码解码判断依据。
- [2026-09-13]：后续多批重复记忆再次印证同一契约（含 bridgeBase 去尾斜杠、零字节空资源、错误信封必抛），内容一致未冲突，仅提升热度并细化测试覆盖边界。

## 待确认问题
（暂无）
