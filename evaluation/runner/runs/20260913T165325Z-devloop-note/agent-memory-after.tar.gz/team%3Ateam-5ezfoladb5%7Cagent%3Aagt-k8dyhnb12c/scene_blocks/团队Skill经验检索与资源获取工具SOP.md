-----META-START-----
created: 2026-09-13T12:29:49.047Z
updated: 2026-09-13T13:30:00.527Z
summary: 本仓库团队开发 evaluation 工具的协作 SOP：动手前检索团队 skill 经验、最小改动保行为不变、补测试并跑通、最后说明改动与原因；含 fetchResource 接口契约与禁忌。
heat: 2
-----META-END-----

## 工作场景
适用于本仓库团队（含 Agent）在 evaluation/ 尤其 evaluation/gate/ 下新增或修改工具类代码的场景。沉淀的是"动手前检索团队经验 + 最小改动 + 测试保障 + 说明交付"的通用协作流程，以及把团队 skill 资源取到本地的 fetchResource 接口契约。该 SOP 可复用到同仓库后续任何新增 gate 工具的任务。

## 适用条件
任务类型为新增/修改仓库内工具模块，尤其是需要访问团队知识库（skill）资源的工具。风险背景：仓库存在已有测试与既有行为，改动可能破坏回归；团队以 skill 形式沉淀过往经验，需要显式检索而非依赖记忆。约束：只改必要文件、保持已有行为不变。

## 核心 SOP
- 动手前先检索一次团队知识库中的 skill 经验：有相关经验即参考，没有则按自己判断执行；目的是复用组织沉淀、避免重复踩坑。
- 只修改必要的文件，不牵连无关代码，保持已有行为不变。
- 为新增工具补一条测试；改动后运行 `node --test` 跑 evaluation 下所有 `*.test.mjs`，确保全部通过。
- 结束时说明"改了什么、为什么改"，让审查者能快速校准。
- 工具对外接口按契约实现（见下），并优先保证可测试性。

## 判断逻辑
- 用参数注入解耦外部依赖：`fetchResource({ skillId, path, bridgeBase, fetcher })` 中 `fetcher` 用于注入 HTTP 实现（测试传桩），缺省 `globalThis.fetch`——使测试无需真实网络。
- 区分"空"与"错"：资源内容为空是合法文件，返回零字节 Buffer，不能与错误混淆；只有在业务信封失败（code !== 0）时才抛错。
- 保留上游信息：错误信封的 message 必须透传到 Error.message，不吞掉，便于排障与上层判断。
- 按编码解码保证字节保真：请求 `encoding: "base64"`，按响应的 `data.encoding` 把 content 解码回原始字节，直接以 Buffer 返回供调用方写文件。
- 归一化 baseUrl：`bridgeBase` 末尾斜杠需先去掉再拼接请求路径，避免出现双斜杠或重复拼接。

## 禁忌与反模式
- 不要吞掉上游错误信封：code !== 0 必须抛出并携带信封 message，静默降级会掩盖真实故障。
- 不要把空资源当错误或返回 null/抛异常：空文件合法，应返回零字节 Buffer。
- 不要硬编码或直接调用 `globalThis.fetch` 而忽略 `fetcher` 注入：会破坏测试可用桩替换的能力。
- 不要在拼接请求 URL 时直接连接 `bridgeBase`：尾斜杠会导致路径重复，需先去尾斜杠。
- 不要改动超出任务范围的文件或改变已有行为；不要新增测试后不跑通 evaluation 下全部 `*.test.mjs`。

## 关键事实依据
- 新增实现文件 `evaluation/gate/fetch-resource.mjs`，通过 `POST /skill-bridge/v3/skill/files/read` 向 bridge 请求 skill 资源。
- 请求体：`{ skill_id, path, encoding: "base64" }`；响应为 JSON 信封 `{ code, message, data: { path, content, encoding, size_bytes, ... } }`。
- `fetchResource` 成功返回资源原始字节 Buffer；空资源返回零字节 Buffer；错误信封抛 Error（message 携带信封 message）。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`：新增工具实现。
- `evaluation/gate/fetch-resource.test.mjs`：桩 fetcher 覆盖五类行为——二进制资源 base64 往返字节不变、空资源零字节 Buffer、utf-8 信封按原样解码、错误信封转为携带上游 message 的 Error、bridgeBase 带尾斜杠时 URL 不重复拼接。

## 演化记录
- [2026-09-13]: 首次沉淀团队 skill 经验检索约定、最小改动流程与 fetchResource 接口契约。
- [2026-09-13]: 后续批次以多份同义表述重复确认同一套约定（检索经验 / 最小改动 / fetchResource 契约），未引入新的方法或规则，判断逻辑与禁忌保持稳定，故仅增热度不新增场景。

## 待确认问题
- 团队知识库"skill 经验"的检索入口与匹配方式未明确（如何判断"有相关经验"）。
