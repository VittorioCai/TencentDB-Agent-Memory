-----META-START-----
created: 2026-09-13T10:56:43.435Z
updated: 2026-09-13T10:56:43.435Z
summary: 本仓库团队"先检索经验再动手"的工作法：动手前经 skill-bridge 检索团队经验 skill，按最小改动、先跑基线、补测试、说明缘由的规范完成 evaluation 工具类改动。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库（evaluation 相关模块）中 Agent 或成员进行工具类新增/改动的工作场景，典型如 evaluation/gate/fetch-resource.mjs 这类"把团队 skill 的资源文件取到本地"的工具。方法核心是：动手前先检索团队经验，实现时最小化改动并用测试自证不破坏已有行为。

## 适用条件
- 接到任务、动手改代码之前。
- 团队知识库中存在以 skill 形式沉淀的过往经验时。
- 改动涉及 evaluation 目录下的脚本与其测试。
- 需要保证已有行为不变且可复现验证的场景。

## 核心 SOP
- 先检索再动手：通过 skill-bridge 检索一次团队经验，有相关经验则参考执行，没有则按自身判断推进。
- 检索接口：v3/skill/search（按 query 关键词检索）、v3/skill/get（按 skill_id 取内容与 manifest）；请求带 content-type: application/json 及 x-tdai-service-id、x-conversation-id 头。
- 先跑基线：改动前运行 node --test 记录改动前状态，改动后对比以确认已有行为不变。
- 最小改动：只改必要文件。
- 补测试：为新增工具至少补一条测试。
- 自证通过：用 node --test 运行 evaluation 下 *.test.mjs（如 node --test evaluation/gate/*.test.mjs）全部通过。
- 收尾说明：最后说明改了什么、为什么。

## 判断逻辑
- 经验以 skill 沉淀后检索成本低、复用收益高，故"先检索再动手"是默认前置步骤；无匹配经验时不阻塞，按判断推进。
- 验收以"测试全绿 + 已有行为不变"为硬口径，而非口头声明。
- 强调最小改动与说明缘由，是为了让改动可审、可回溯。

## 禁忌与反模式
- 不检索就动手：可能重复造轮子或违反团队既有约定。
- 吞掉上游错误：错误信封（code !== 0）必须抛出 Error 并带上信封的 message，不得静默。
- 把空资源当失败：资源内容为空应返回零字节 Buffer，空文件是合法文件。
- 跳过基线直接改：无法证明已有行为不变。
- 顺带改无关文件：违反"只改必要文件"的约束。

## 关键事实依据
- fetch-resource.mjs 导出 fetchResource({ skillId, path, bridgeBase, fetcher })：成功返回资源原始字节 Buffer（调用方可直接写文件）；空资源返回零字节 Buffer；错误信封抛 Error 且 message 带信封 message；fetcher 注入 HTTP 实现（测试传桩），缺省 globalThis.fetch。

## 相关任务与资产
- 待交付：evaluation/gate/fetch-resource.mjs 及其配套测试。

## 演化记录
（暂无）

## 待确认问题
- skill-bridge 的 bridgeBase 默认值与鉴权头取值未在记忆中明确，待确认。
