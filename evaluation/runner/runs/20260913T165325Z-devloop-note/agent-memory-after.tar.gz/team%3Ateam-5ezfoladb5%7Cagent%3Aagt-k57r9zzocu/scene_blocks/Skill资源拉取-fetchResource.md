-----META-START-----
created: 2026-09-13T11:46:47.818Z
updated: 2026-09-13T12:54:36.031Z
summary: 团队 skill 资源拉取工具 fetchResource 的方法与约束：先检索团队经验、按 files/download 消费响应、区分原始字节与 JSON 信封、空文件合法、透传上游错误、补测试且不改既有行为。
heat: 3
-----META-END-----

## 工作场景
适用于为团队知识库 skill 实现"资源拉取/桥接消费"类工具的研发，也适用于任何消费 bridge 下载端点、把上游资源落地本地的 Agent 或团队任务。方法可复用到其它 bridge 端点消费与 HTTP 桩注入测试。

## 适用条件
在 evaluation/gate 等 Node ESM 工具目录新增工具、需复用团队既有 skill 经验、需消费 SkillBridge（MemoryProxy/src/skill/skill-bridge.ts）接口、并要求测试全绿且不改动既有行为时适用。

## 核心 SOP
- 动手前先检索团队知识库的 skill 经验：有则参考，无则自行判断。
- 确认接口：skill 资源走 files/download（非 files/read），请求为 POST <bridgeBase>/files/download。
- 拼接 URL 去除 bridgeBase 尾部斜杠，避免重复斜杠。
- 处理响应：先看 content-type，非 JSON 且支持 arrayBuffer 则按原始字节返回；否则解析 JSON 信封 { code, message, data }。
- 按 code 判成败：非零才失败；按 data.encoding 解码（base64→字节，其它按 utf-8）。
- 暴露 fetcher 注入点，缺省 globalThis.fetch，使测试可传桩不触网。
- 补测试覆盖关键分支，保证 evaluation 下 node --test 全部 *.test.mjs 通过，只改必要文件。
- 交付时说明改了什么、为什么：让改动可被评审追溯，避免隐性行为变化。

## 判断逻辑
空文件是合法资源，缺失/空 content 不代表失败，若当错误处理则每个空文件都会误报，故仅以非零 code 判失败；上游错误信封的 message 必须原样透传到抛出的 Error，通用信息会掩盖真实原因；fetcher 注入既保证可测，又能兼容 Response 或已解析信封两种返回。

## 禁忌与反模式
- 不要假设下载响应总是 JSON 信封：正常非空文件以原始字节流返回，content-type 为资源自身 mime type。
- 不要把空/缺失 content 当失败，也不要吞掉或替换上游错误 message。
- 不要用 files/read 拼接请求。
- 不要为过测试而改动无关文件或既有行为。

## 关键事实依据
- fetchResource 签名 { skillId, path, bridgeBase, fetcher }，成功返回 Buffer，调用方直接写文件。
- bridge 信封 { code, message, data }；零字节资源以 content:"" 且 code:0 返回。
- SkillBridge 实现：MemoryProxy/src/skill/skill-bridge.ts。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs（工具）；evaluation/gate/fetch-resource.test.mjs（测试，含"原始字节流需原样返回"用例）。
- 全量 evaluation 测试 645 条通过。

## 演化记录
- [2026-09-13]: 对 files/download 的认知由"总是返回 JSON 信封"修正为"正常文件返回原始字节流、仅未命中/空/错误返回信封"，据此 fetchResource 增加 content-type 分支。
- [2026-09-13]: 工具已按约定交付（fetch-resource.mjs + fetch-resource.test.mjs），全量 evaluation 645 条测试通过——验证了"先检索经验→定契约→补测试→全绿不改既有行为"这条链路可稳定复用。

## 待确认问题
- 无。
