-----META-START-----
created: 2026-09-11T18:49:36.204Z
updated: 2026-09-11T20:11:45.170Z
summary: 修复 evaluation 验收器解析外部工具输出时的大小写误判，含定位方法、red check、测试基线与回归约束
heat: 3
-----META-END-----

## 工作场景
适用于修复仓库 evaluation 验收器（如 evaluation/tasks/bridge-addr/verify.mjs）在解析外部工具（CodeBuddy）执行结果时的判定错误。本场景沉淀"定位解析错配→最小修复→补回归→red check→按正确基线验证"的方法，可复用于同类解析器/正则类缺陷。

## 适用条件
- 验收器把外部工具输出解析为成功/失败/不可读（如 timed out / exit N / outcome not readable）等状态时出错。
- 要求不改变已有行为、补充回归测试、只改必要文件。
- 需区分"本次引入的失败"与"仓库既有失败"。

## 核心 SOP
- 定位：对照解析逻辑与实际工具输出文本，找出匹配失败点。
- 最小修复：只改必要文件；本次为退出码标签正则加 /i，使匹配大小写不敏感。
- 补回归测试：覆盖触发场景——CodeBuddy 输出大写 `Exit Code:` 的超时调用应被判为失败。本次新增 verify.exit-status.<marker>.test.mjs，覆盖四类：`Exit Code: 28` 无 curl 报错文本时应判 timed out、`Exit Code: 52` 应判 exit 52 失败而非不可读、小写 `Exit code:` 拼写仍兼容、静默超时的完整 verify 流程应给 FAIL 而非 ERROR。
- 验证：从仓库根执行 node --test 'evaluation/**/*.test.mjs'（evaluation 下测试期望以仓库根为 cwd），确认通过且已有行为不变。
- red check：用 git stash 临时回退修复，确认新增回归测试在未修复版本上确实失败，再恢复修复，证明测试覆盖并锁定了该缺陷（而非只是"顺便通过"）。
- 收尾：说明改了什么、为什么。

## 判断逻辑
大小写敏感正则在解析外部工具输出时是常见隐患。verify.mjs 第 159 行只匹配小写 `Exit code:`，而真实输出为 `Exit Code:`（大写 C）。当 curl 静默超时（用 -s 但不带 -S）时没有 `curl: (N)` 之类报错文本，只有退出码行，匹配不上便落入 "outcome not readable"，使该次运行被判 ERROR 而非 FAIL。故修复方向是让 outcomeOfAttempt 的 exit 匹配大小写不敏感。
回归基线需排除无关既有失败：单独跑 bridge-addr 基线为 39/39 全通过，修复并新增测试后 43 个全通过；全量 evaluation 套件有 3 个既有失败，原因是缺少被 gitignore 的 fixtures，与本次修复无关，不应作为回归判断依据。

## 禁忌与反模式
- 用全量套件中的既有失败判定本次回归：会误报，应先用单测基线校准。
- 在 evaluation 目录内直接跑测试：cwd 与期望不符会失败，必须从仓库根执行。
- 为让测试通过而改动无关文件或改变已有行为：违反最小改动约束。
- 补了回归测试却不做 red check：无法证明测试真的覆盖该缺陷。
- 同一类大小写/解析问题修完不补回归：会再次回归。

## 关键事实依据
- 根因：verify.mjs 第 159 行 exit 标签匹配区分大小写；CodeBuddy 实际输出 `Exit Code:`。
- 修复：给该正则加 /i（outcomeOfAttempt 的 exit 匹配）。
- 回归测试：evaluation/tasks/bridge-addr/verify.exit-status.bt-78yk9r3bfrm.test.mjs（命名与 marker 沿用团队 skill）。
- 受影响调用：Exit Code 28、52 等静默超时未被识别为失败。

## 相关任务与资产
- evaluation/tasks/bridge-addr/verify.mjs
- evaluation/tasks/bridge-addr/verify.exit-status.bt-78yk9r3bfrm.test.mjs
- 相关 skill：「eval-tool-result-exit-line」

## 演化记录
- [2026-09-11] 补充 red check 步骤、回归测试文件名/覆盖场景；基线由"39/39"更新为修复后"43/43 全通过"。
- [2026-09-11] 本批再次确认：全量 evaluation 套件的 3 个既有失败源于缺失被 gitignore 的 fixtures，属无关既有噪声，不得用作本次回归判断依据——回归结论只以 bridge-addr 单测基线为准。

## 待确认问题
（空）
