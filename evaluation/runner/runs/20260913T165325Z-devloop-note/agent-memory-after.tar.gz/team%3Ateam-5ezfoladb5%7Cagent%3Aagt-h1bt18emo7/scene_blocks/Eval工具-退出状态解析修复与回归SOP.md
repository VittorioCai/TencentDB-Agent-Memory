-----META-START-----
created: 2026-09-11T19:08:24.813Z
updated: 2026-09-11T20:15:32.898Z
summary: 修复 evaluation 归因工具退出状态解析缺陷的通用 SOP：先建测试基线、检索并核实团队经验、大小写不敏感匹配、补边界齐全的回归测试、对齐既有失败、只改必要文件并说明原因。
heat: 3
-----META-END-----

## 工作场景
适用于仓库中 evaluation/attribution 等评测工具脚本的缺陷修复与配套回归测试，尤其外部工具输出（shell 结果）解析类问题。可复用于任何"读外部结果字段→下游按该字段分类"的采集器（collect-artifacts 类）维护，也适用于"经验 skill 与真实代码不一致"时的复用判断，以及团队"先检索经验再动手"协作约定的落地。

## 适用条件
- 任务类型：单点缺陷修复 + 回归测试，要求改动最小、已有行为不变。
- 环境：存在既有测试套件基线，且可能含 pre-existing failures。
- 执行者：Agent 独立处理仓库任务，需先检索团队经验并自证正确性。

## 核心 SOP
- 先建基线：动手前运行 `node --test evaluation/`（或 `node --test "evaluation/**/*.test.mjs"`），先区分既有失败与本次引入的失败。
- 检索并核实团队经验：先从团队知识库 skill 取经验；本次 eval-tool-result-exit-line 只指向 bridge-addr/verify.mjs，与本任务目标文件不同，只能借用其"真实结果用大写 Exit Code"的结论，仍需自行定位真实问题。
- 定位根因：核对解析正则与真实输出差异。真实 CodeBuddy shell 结果用大写 `Exit Code:`，原正则仅匹配小写 `Exit code:`，致 exit_code 恒为 null，下游按退出状态分类失败（如超时 curl）失效。
- 最小化修复：对标签做大小写不敏感匹配，保留旧小写兼容，只改任务指定位置（collect-artifacts.mjs:124），即便该正则在仓库另有多处。
- 补回归测试：覆盖大写标签读取、非零失败码（如 Exit Code: 28 / 52）、成功码 0、旧小写兼容，并对 collectArtifacts 做端到端验证；标题保留唯一标记（如 bt-78yk9r3bfrm）便于定位。
- 验证口径：跑完整 evaluation *.test.mjs 套件，只确认"不引入新失败"且回归测试通过。
- 收尾：说明改了什么、为什么，只改必要文件。

## 判断逻辑
团队以"不引入新失败"而非"全绿"为准绳，避免被无关历史失败阻塞交付。经验 skill 是线索而非可直接套用的补丁，需核实其指向文件与上下文，防止改错目标。修复范围以任务指定位置为准，即便同一缺陷在仓库多处出现也不擅自扩大。测试标记内嵌标题，是为可追溯性与后续定位做的权衡。

## 禁忌与反模式
- 不检索团队经验就动手，或反之把 skill 当补丁直接套用：前者重复踩坑，后者可能改错文件。
- 跳过基线直接修复：无法区分既有失败与新增失败。
- 只改匹配逻辑不补回归测试，或只测正向不测兼容：缺兼容用例会漏掉回归。
- 删/放宽既有用例、擅自扩大改动范围：违反"只改必要文件、已有行为不变"。
- 凭假设写正则，忽略大小写、格式等真实输出特征。

## 关键事实依据
- 根因：collect-artifacts.mjs:124 的 outcomeOf 正则大小写敏感。
- 同一正则模式 `/(?:^|\n)Exit code:\s*(\d+)/` 在仓库 3 个文件中出现，任务指定只修 collect-artifacts.mjs:124。
- 基线 3 个既有失败由缺少 artifacts 引起，与本次修复无关。
- 验收：evaluation *.test.mjs 全部通过且既有行为不变；代码修复与回归测试已完成，正跑完整套件确认。

## 相关任务与资产
- evaluation/attribution/collect-artifacts.mjs（修复对象，第 124 行；任务状态：进行中→修复已完成待验证）
- evaluation/attribution/collect-artifacts.exit-status.bt-78yk9r3bfrm.test.mjs（新增回归测试）
- 团队经验笔记：eval-tool-result-exit-line（指向 bridge-addr/verify.mjs，仅作参考）

## 演化记录
- [2026-09-11]：根因由"疑似"确认为 collect-artifacts.mjs:124 正则大小写敏感；修复方式定为对标签做大小写不敏感匹配。
- [2026-09-11]：回归用例细化到 Exit Code: 28 / 52 / 0 与旧小写兼容并含端到端校验；任务状态推进为"修复+测试已完成，待跑全套件确认"。

## 待确认问题
- evaluation 套件 3 个既有失败（缺 artifacts）的边界与归属未明确，后续改动仍需以其为基线。
