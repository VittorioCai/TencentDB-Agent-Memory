-----META-START-----
created: 2026-09-13T11:50:06.940Z
updated: 2026-09-13T12:56:26.521Z
summary: 沉淀团队 skill 资源获取工具 fetchResource 的接口契约、bridge /files/read 信封解析与编码还原、端点不可信原则、动手前检索团队经验与最小改动交付流程。
heat: 3
-----META-END-----

## 工作场景
适用于团队 skill 资源获取工具的开发与联调：从 bridge 读取远端 skill 的资源文件并落地为本地字节，覆盖接口调用、编码还原、错误处理与测试。可复用于任何"通过 bridge 读文件并把字节落地"的共享工具。

## 适用条件
- 本仓库任何开发任务动手前（先检索团队经验，再决定是否自行判断）。
- 需通过 bridge 读取团队 skill 资源文件时。
- 编写共享工具、需要为 HTTP 调用预留可测试注入点时。
- skill 文档端点与实际环境可能不一致时。

## 核心 SOP
- 前置检索：动手前经 skill-bridge `skill/get` 取团队经验 skill（含内容与 manifest）；有相关先参考，没有按自身判断，避免重复踩坑。
- 接口调用：POST `<bridgeBase>/files/read`，body `{ skill_id, path }`；解析信封 `{ code, message, request_id, data }`，按 `data.encoding`（`utf-8`/`base64`）还原原始字节。
- 工具契约：`fetchResource({ skillId, path, bridgeBase, fetcher })` 成功返回原始字节 `Buffer`，供调用方直接写文件；`fetcher` 注入 HTTP 实现，缺省 `globalThis.fetch`。
- 交付流程：先跑新增测试，再跑 `evaluation` 下全量 `*.test.mjs`（基线 637 pass / 0 fail）确认无回归；仅改必要文件；最后说明改了什么、为什么。

## 判断逻辑
- 端点以实际可达为准：调用方传入的 base URL 优先，其次对实际服务验证，不硬编码。
- 空文件合法：`content` 为 `""` 时按零字节 `Buffer` 返回，不视为缺失，避免误报资源不存在。
- 错误不吞：上游 `code !== 0` 抛 `Error` 且 message 携带信封 message，便于定位。
- base URL 末尾斜杠需归一化，保证路径拼接一致。
- 可复现性优先：`fetcher` 注入桩使测试不依赖真实网络。
- 经验参考但不盲从：skill 是经验非权威，需与环境交叉验证后再采纳。

## 禁忌与反模式
- 硬编码 skill 文档端点：文档可能过时（案例：skill 记为 `127.0.0.1:47318` 且要求 `x-team-trace` 头，实际 8096 且无需该头）。
- 向共享工具注入未经验证的 `x-team-trace` 头：会污染调用方请求。
- 把空内容当缺失：会误报资源不存在。
- 吞掉错误信封：隐藏上游故障，难以排查。

## 关键事实依据
- 工具 `evaluation/gate/fetch-resource.mjs`；测试 `evaluation/gate/fetch-resource.test.mjs`。
- 测试覆盖：utf-8 直读、base64 解码、空文件两种编码均零字节、base URL 斜杠归一化、错误信封抛 Error 带 bridge message、fetcher 缺省 `globalThis.fetch`。
- 端点冲突沉淀为 `reference_skill_bridge_endpoint.md`（type: reference），在 `MEMORY.md` 登记索引。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`、`evaluation/gate/fetch-resource.test.mjs`、`reference_skill_bridge_endpoint.md`、`MEMORY.md` 索引。

## 演化记录
- [2026-09-13]：将 bridge 端点冲突从非显性经验沉淀为 reference 记忆并登记索引，供后续共享工具开发参考。
- [2026-09-13]：补充"动手前先检索团队知识库经验 skill"为前置 SOP，明确经验参考不等于盲从。
- [2026-09-13]：二次整合接口契约与交付流程，明确空内容按 `""` 处理（非缺失）、编码需按 `data.encoding` 还原、错误不得吞掉。

## 待确认问题
- skill 文档端点与实际环境不一致是普遍现象还是个别案例？是否需统一校对/刷新 skill 端点说明？
