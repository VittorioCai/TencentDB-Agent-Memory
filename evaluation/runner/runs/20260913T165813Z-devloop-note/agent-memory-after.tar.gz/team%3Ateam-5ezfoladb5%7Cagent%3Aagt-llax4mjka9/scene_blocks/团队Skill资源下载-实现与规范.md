-----META-START-----
created: 2026-09-13T16:58:58.581Z
updated: 2026-09-13T16:58:58.581Z
summary: 团队在仓库内新增 skill 资源下载工具与测试的方法：先检索团队 skill 经验、最小改动、跑通全部测试；并沉淀 download 子路径与空内容处理等关键判断。
heat: 1
-----META-END-----

## 工作场景
适用于在本仓库（尤其 evaluation/gate）新增或维护"从团队 skill bridge 取回资源文件"的工具与测试，也适用于团队通用的开发流程：动手前检索团队知识库、最小改动交付、改完跑测试并说明原因。

## 适用条件
- 团队把过往经验以 skill 形式存于知识库，仓库开发需先参考这些经验。
- 任务涉及通过 skill bridge 下载资源、构造字节级工具函数。
- 交付要求：evaluation 下全部 *.test.mjs 通过，且不改变既有行为。

## 核心 SOP
- 动手前检索一次团队知识库 skill 经验：有相关的就参考，没有则按自己判断做。
- 只改必要文件；改完运行 evaluation 下全部 *.test.mjs，确认通过且既有行为不变；交付时说明改了什么、为什么。
- 下载资源走子路径 skill-bridge/v3/skill/files/download，不要用 files/read。
- fetchResource({skillId,path,bridgeBase,fetcher})：按字节读取响应一次后处理——信封 code!==0 抛出携带 message 的 Error；code===0 解码 data.content（允许为空）；非信封直接返回原始下载字节。
- 统一返回 Buffer 供调用方直接写文件；空内容返回零字节 Buffer；fetcher 注入 HTTP 实现，缺省 globalThis.fetch。
- 导出常量 DOWNLOAD_SUBPATH，并为新增工具补测试。

## 判断逻辑
- bridge 按子路径分发：只有 download 子路径返回原始字节，files/read 总返回 JSON 信封，把其响应体直接存盘会得到 JSON 文件而非目标脚本，curl -o 也改变不了。
- 空文件是合法的（Core 的 skillResourcePayloadSchema 中 content 为 z.string()，未加 .min(1)），但 proxy download 分支仍以 !parsed.data?.content 判断，会返回整个信封而非 0 字节，故调用方要按 code===0 信封处理空内容。
- 容错取严：上游错误信封必须抛出、不得吞掉，便于定位问题。

## 禁忌与反模式
- 不要用 files/read 取资源或依赖 curl -o 得到脚本：子路径分发决定只有 download 返回字节。
- 不要把空内容当错误、用 falsy 判断空文件：会让空文件退化为信封。
- 不要吞掉 code!==0 的错误信封：丢失上游 message。
- 不要改动非必要文件或跳过测试交付。

## 关键事实依据
- 新增资产 evaluation/gate/fetch-resource.mjs，导出 fetchResource 与 DOWNLOAD_SUBPATH="skill-bridge/v3/skill/files/download"。
- 团队知识库笔记 eval-skill-resource-download 记录了上述下载子路径与空内容条款。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs（工具）及其测试；团队知识库笔记 eval-skill-resource-download。

## 演化记录
- [2026-09-13]：确立下载用 download 子路径、统一返回字节 Buffer、空内容合法且按 code===0 信封处理。

## 待确认问题
- proxy download 分支以 !content 判断空内容与 Core 允许空字符串不一致，是否修复由 proxy 侧对齐尚未确认。
