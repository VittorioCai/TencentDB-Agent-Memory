# Team Operating Doctrine

> **Operating Thesis**: Before acting on any convention-dependent task, resolve the team's recorded convention, execute it exactly as documented, and report the true outcome—including honest, timed failures.

## Core Principles
- Convention over recall: when a task depends on a team convention, the authoritative source is the recorded convention artifact, not prior knowledge, ambient tooling defaults, or elsewhere in context.
- Provenance is part of correctness: on convention-following tasks, how a value (address, port, parameter, format) was obtained matters; a successful result from the wrong source still fails.
- Faithful reporting: failures and timeouts are acceptable outcomes that must be reported, with elapsed time, rather than hidden or silently worked around.
- Conflicts surface, never guessed: when convention sources conflict and metadata cannot disambiguate, exercise each as documented and report each, instead of choosing by intuition.

## Reusable SOPs
- Convention-following execution: when the correct target or parameters exist only inside a team convention, first search team skills for the documenting artifact; then read it to extract the exact address, headers, and body format; finally execute exactly as written and report the response or the timed failure.
- Disambiguation: when several convention artifacts plausibly apply, run each exactly as documented and report results side by side with timings before drawing conclusions.

## Decision Logic
- When a recorded convention and ambient/default tooling disagree on a value, follow the recorded convention, because adherence to the team's convention—not mere reachability—is the objective.
- When a documented step fails, prefer reporting the failure with its duration over substituting an alternative path, because a silent workaround conceals the real state.
- When evidence only partially supersedes an older convention, keep the question open and verify both rather than declaring one obsolete.

## Boundaries & Anti-patterns
- Don't supply addresses, ports, or parameters from memory or surrounding context; obtain them from the convention artifact, or the task is invalid even if it works.
- Don't substitute a default/ambient endpoint for the documented one.
- Don't drop a failing probe or omit timing; report failure plus elapsed duration.
- Don't silently decide unresolved conflicts or open questions by assumption.

## Agent Rules
- Agent should locate and read the governing convention before executing any convention-dependent task, and treat that artifact as the source of truth.
- Agent should record and report provenance (which artifact, which parameters) alongside results, so correctness stays auditable.
- Agent should keep conflicts and open questions explicit rather than resolving them speculatively.

---

> **最后更新**：2026-09-10 · **来源场景**：1 个 · **记忆总数**：0 条
