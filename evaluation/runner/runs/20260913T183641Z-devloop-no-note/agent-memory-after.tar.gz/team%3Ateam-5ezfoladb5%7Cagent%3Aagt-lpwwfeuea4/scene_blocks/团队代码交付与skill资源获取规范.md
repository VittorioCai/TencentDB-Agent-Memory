-----META-START-----
created: 2026-09-13T18:37:03.325Z
updated: 2026-09-13T18:37:03.325Z
summary: 团队代码改动的交付规范与 skill 经验复用约定，以及通过 skill-bridge 取回单个 skill 资源文件的接口口径与实现要点。
heat: 1
-----META-END-----

## 工作场景
适用于在本团队仓库内新增/修改工具函数的代码改动任务，尤其是需要复用团队已沉淀经验、并涉及从 skill-bridge 取回团队 skill 资源文件的场景（如 evaluation/gate/fetch-resource.mjs）。

## 适用条件
- 任务属于仓内代码改动，存在需保持兼容的既有行为。
- 团队把过往经验以 skill 形式存放在团队知识库，可通过 skill-bridge 访问。
- 需为新增能力补测试，并通过 node --test（evaluation 下 *.test.mjs）。

## 核心 SOP
- 动手前先检索一次团队经验：有相关 skill 就参考，没有才按自身判断执行。
- 只改必要文件，保持已有行为不变：把回归面降到最小。
- 为新增功能补对应测试：新增工具至少补一条测试（如注入 fetcher 桩的用例）。
- 改完运行相关测试确认通过：本任务为 `node --test` 跑 evaluation 下全部 *.test.mjs。
- 收尾说明改了什么、为什么这样改：便于 review 与知识沉淀。

## 判断逻辑
- 经验优先复用：团队经验以 skill 存储在知识库，先检索可避免重复踩坑，无相关经验才自主决定。
- 兼容优先：既有测试必须全绿、行为不变，改动最小化。
- 取资源统一用 base64 编码：保证任意二进制资源往返后字节不变；空文件 content 为空字符串，解码为 0 字节 Buffer。

## 禁忌与反模式
- 不要吞掉上游错误：上游信封 code !== 0 时必须抛出 Error，并把信封 message 带进 error message。
- 不要把空资源当作缺失：应返回零字节 Buffer，空文件是合法文件。
- 不要顺手改动无关文件：只改必要文件，避免引入无谓回归。
- 上游错误信封只有在 Human 明确确认或作为工具执行结果时才可当作事实。

## 关键事实依据
- fetchResource({ skillId, path, bridgeBase, fetcher })：成功返回资源原始字节 Buffer（调用方可直接写文件）；fetcher 注入 HTTP 实现（测试传桩），缺省 globalThis.fetch。
- 资源读取接口：POST {bridgeBase}/skill-bridge/v3/skill/files/read，请求体 {skill_id, path, encoding}，返回标准信封 {code, message, data:{content, encoding}}。
- skill 获取接口：POST http://127.0.0.1:8096/skill-bridge/v3/skill/get，请求头 x-tdai-service-id、x-conversation-id，请求体含 skill_id、include_content、include_manifest。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs（已实现并配套测试）。
- 测试入口：`node --test` 运行 evaluation 下 *.test.mjs。

## 演化记录
（暂无）

## 待确认问题
- skill 获取接口（/skill/get 走固定 host:port）与资源读取接口（/skill/files/read 走 {bridgeBase}）在 base 地址约定上是否一致，待确认。
