-----META-START-----
created: 2026-09-13T18:57:15.200Z
updated: 2026-09-13T18:57:15.200Z
summary: 团队仓库开发与团队 skill 知识库交互工具的通用方法：先检索 skill 经验再动手、按接口契约取资源原始字节、最小化改动并跑通测试、说明改动原因。
heat: 1
-----META-END-----

## 工作场景
适用于在本团队仓库中开发"与团队 skill 知识库交互"的工具（如 `fetch-resource.mjs` 这类取资源文件的工具），以及所有"动手前先检索经验"的常规开发协作任务。本场景沉淀的是可复用的开发 SOP、接口契约判断与禁忌，而非单次任务进展。

## 适用条件
- 本仓库所属团队把过往经验以 skill 形式保存在团队知识库中，可通过 skill-bridge 接口检索。
- 任务涉及获取/读取 skill 资源文件，且需要严格、可测试的接口契约。
- 由 Agent 执行：需遵守最小化改动、测试回归与结果说明的执行约束。

## 核心 SOP
- 动手前先检索团队经验：按关键词调用 skill 检索接口（如 skill/search），有相关经验就参考，无相关经验再按自身判断实现。
- 取资源原始字节走 files/download 接口（而非 files/read）；这是团队 skill 明确指出的正确路径。
- 新增工具时同步补测试：保证 `node --test` 下 evaluation 目录 `*.test.mjs` 全部通过、已有行为不变。
- 最小化改动：只改必要文件，改完运行相关测试，最后说明改了什么、为什么。
- 依赖注入优先：HTTP 实现通过 `fetcher` 参数注入（测试传桩），缺省用 `globalThis.fetch`，保证可测。

## 判断逻辑
- 先检索经验再动手：避免重复踩坑，把团队已有结论作为默认先验；无经验时才启用个人判断，且该判断后续应可回归为团队 skill。
- 接口契约以"调用方视角"定义行为（返回可直接落盘的原始字节），而不是以内部实现方便为准。
- 空内容与错误信封必须区分：空文件是合法产物，而上游 `code !== 0` 是真实失败，两者不可混同。

## 禁忌与反模式
- 获取原始字节不要用 files/read：应用 files/download，否则拿不到原始字节。
- 不要把空内容当错误或跳过：空文件合法，应返回零字节 Buffer。
- 不要吞掉上游错误：上游返回错误信封（`code !== 0`）必须抛 Error 并携带信封 message。
- 不要扩大改动面：顺手重构、改无关文件会破坏"已有行为不变"的约束。

## 关键事实依据
- `fetchResource({ skillId, path, bridgeBase, fetcher })` 契约：成功返回资源原始字节 Buffer（调用方可直接写文件）；空内容返回零字节 Buffer；错误信封抛 Error 且 message 携带信封 message；`fetcher` 注入 HTTP 实现，缺省 `globalThis.fetch`。
- skill-bridge 提供检索/获取能力：skill/search、`/skill-bridge/v3/skill/get`。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs` 及其对应 `*.test.mjs` 测试。

## 演化记录
- [2026-09-13]：确认取资源原始字节应走 files/download 而非 files/read，且空内容视为合法内容。

## 待确认问题
- 团队经验 skill 的检索接口以 skill/search 还是 `/skill-bridge/v3/skill/get` 为主路径，需统一口径。
