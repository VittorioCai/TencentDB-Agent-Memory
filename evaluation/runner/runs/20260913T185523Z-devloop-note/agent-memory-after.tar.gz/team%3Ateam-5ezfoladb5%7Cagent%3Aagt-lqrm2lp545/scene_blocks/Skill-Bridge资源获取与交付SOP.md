-----META-START-----
created: 2026-09-13T18:55:27.172Z
updated: 2026-09-13T18:55:27.172Z
summary: 沉淀本仓库新增工具类模块的可复用方法：动手前经 skill-bridge 检索团队经验，按接口契约实现（原始字节、空文件合法、错误透传、依赖注入），并遵守补测试、全量通过、只改必要文件、说明改动的交付SOP。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库（含 evaluation/gate/ 等目录）新增或修改工具类模块的任务，尤其是通过 skill-bridge 从团队知识库取 skill 资源文件的工具，如 `fetchResource({ skillId, path, bridgeBase, fetcher })`。可复用要点：任何"取远程资源→落地为本地文件"的小工具，都可套用同一套接口契约与交付流程。

## 适用条件
- 团队把过往经验以 skill 形式存于知识库，可经 skill-bridge 检索；
- 任务为新增小工具/功能，且要求不破坏现有行为；
- Agent 独立实现并交付，需自证质量；
- 仓库用 `node --test` 运行 evaluation 下的 `*.test.mjs`。

## 核心SOP
- 先检索团队经验：动手前用 skill-bridge 检索一次；命中就参考（如 eval-skill-resource-download、bridge 端点 skill），未命中再按自身判断执行。原因：避免重复踩坑，复用已验证经验。
- 先定接口契约再编码：明确入参、成功返回值、空值语义、错误语义、可注入依赖。原因：契约先行让测试与实现解耦。
- 用依赖注入保证可测：`fetcher` 注入 HTTP 实现，缺省 `globalThis.fetch`，测试传桩。
- 为新增功能补一条测试，覆盖成功返回原始字节、空文件合法、非零 code 抛错。
- 运行 `node --test`，确认 evaluation 下 `*.test.mjs` 全过且已有行为不变。
- 只改必要文件，收尾说明改了什么、为什么。

## 判断逻辑
- 选端点：`files/download` 直接返回原始字节，`files/read` 总把内容包进 JSON 信封，取二进制资源应 POST 到 download。
- 判信封：依据响应结构形状（是否为含 code/message/data 的普通对象）判断，而非 Content-Type——被下载资源本身可能就是 JSON 文件。
- 空值语义：该端点判空用 `!parsed.data?.content`（空字符串为 falsy），但空文件合法（`skillResourcePayloadSchema.content` 无 `.min(1)`），故空资源应返回零字节 Buffer，而非信封字节。
- 错误语义：业务出错时端点原样透传上游信封，调用方应在 code !== 0 时抛出带信封 message 的 Error，不得吞错。

## 禁忌与反模式
- 用 `files/read` 取二进制资源：会把字节包进 JSON 信封，破坏可直接写文件性。
- 靠 Content-Type 判断信封：JSON 资源文件会误判。
- 把空文件当错误丢弃：空文件合法，应返回零字节 Buffer。
- 吞掉上游错误信封：应抛出携带信封 message 的 Error。
- 顺手改动无关文件或让既有测试变红：违反"只改必要文件 + 行为不变"。

## 关键事实依据
- 交付产物：`evaluation/gate/fetch-resource.mjs`（export fetchResource）与配套 `fetch-resource.test.mjs`。
- 测试固定场景：成功返回原始字节、空资源零字节合法、非零 code 抛带 message 的 Error；另验证以 `/v3` 结尾的 bridgeBase 仍能解析出 `files/download` 路径。
- 参考 skill：eval-skill-resource-download（tracking bt-pu6nyfhmu2v）、bridge 端点 skill。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`、`evaluation/gate/fetch-resource.test.mjs`
- 团队知识库 skill：skl-XAzqAgejM7O4（eval-skill-resource-download）、skl-oBaDO5CceKnr（bridge 端点）

## 演化记录
（暂无）

## 待确认问题
- fetchResource 对非二进制资源、超时/网络异常的处理约定未在记忆中明确，待后续补充。
