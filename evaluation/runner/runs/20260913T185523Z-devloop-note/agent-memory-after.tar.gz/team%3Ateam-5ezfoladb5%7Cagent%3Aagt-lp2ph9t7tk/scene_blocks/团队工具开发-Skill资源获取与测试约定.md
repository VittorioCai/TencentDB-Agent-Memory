-----META-START-----
created: 2026-09-13T18:55:45.483Z
updated: 2026-09-13T18:55:45.483Z
summary: 团队在仓库内新增 Node 工具（如 fetch-resource）的可复用流程：先检索 skill 经验、按场景判断是否采纳、依赖注入实现、补测试、跑全量测试并说明改动。
heat: 1
-----META-END-----

## 工作场景
适用于团队在仓库内新增或维护 Node 工具模块（.mjs）的场景，典型是"通过 skill-bridge 获取团队 skill 资源"的工具（evaluation/gate/fetch-resource.mjs）及其配套 *.test.mjs。方法可复用于任何"先查团队沉淀经验 → 自行判断实现 → 补测试 → 跑全量测试 → 说明改动"的工具开发任务。

## 适用条件
- 在仓库内动手实现新工具之前（前置检索环节）。
- 工具需访问外部资源（HTTP bridge），且要求可测试、可离线运行。
- 团队以 skill 形式沉淀经验，且经验可能过时或与当前场景冲突。

## 核心 SOP
- 先检索团队知识库中 skill 形式的过往经验：有相关内容则参考，没有则按自身判断实施。
- 实现工具：HTTP 实现通过 `fetcher` 参数注入，缺省 `globalThis.fetch`；按上游返回的 encoding（base64 / utf-8）把 `data.content` 解码为原始字节 Buffer 返回，调用方可直接写文件。
- 补齐 `*.test.mjs`：正常请求校验 URL/method/body；空内容返回零字节 Buffer；base64 资源解码回原始字节；错误信封被抛出且带信封 message；未注入 fetcher 时缺省 `globalThis.fetch`。
- 完成后运行 evaluation 目录下全部 `*.test.mjs`（`node --test evaluation`），确认新增测试与存量测试全部通过、已有行为不变。
- 交付时说明改了什么、为什么。

## 判断逻辑
- 经验检索结果必须与当前场景匹配才采纳；命中项若场景不符，或记载与实际在用的 bridge（端口 8096）冲突，则不采纳，改按自行判断实现。
- 空文件与错误必须区分：空内容是合法文件（返回零字节 Buffer），错误信封（`code !== 0`）必须抛出。
- 依赖注入（fetcher）的目的是让测试用桩替换真实网络，保证测试确定性与离线可跑。

## 禁忌与反模式
- 不要用 falsy 短路把空内容误判为失败或缺失。
- 不要吞掉错误信封；必须抛出携带 message 的 Error。
- 不要让测试依赖真实网络或真实 bridge，应注入桩。
- 不要跳过前置经验检索，也不要盲从与当前场景冲突的旧经验。
- 不要只跑新增测试，必须跑 evaluation 全量测试以确认无回归。

## 关键事实依据
- fetch-resource.mjs 通过 POST skill-bridge v3 的 `skill/files/read` 端点读取团队 skill 资源，并按上游 encoding 解码 content。
- 经验检索命中 deploy-lookup-note-*（部署清单）与 eval-bridge-endpoint-b（HTTP bridge 端点），均与本本地场景无关；后者与实际 bridge 端口 8096 冲突。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs、evaluation/gate/fetch-resource.test.mjs
- 全量测试命令：`node --test evaluation`

## 演化记录
（空）

## 待确认问题
- eval-bridge-endpoint-b 记载的端点与实际 bridge（8096）冲突，需确认以哪一版为准并更新该 skill 经验。
- 是否应将"实现前先检索 skill 经验、完成后跑全量测试"升级为团队级（L3）通用规则。
