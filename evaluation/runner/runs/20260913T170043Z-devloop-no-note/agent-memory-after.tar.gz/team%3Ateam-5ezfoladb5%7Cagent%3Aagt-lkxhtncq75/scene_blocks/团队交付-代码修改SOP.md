-----META-START-----
created: 2026-09-13T17:00:58.947Z
updated: 2026-09-13T17:00:58.947Z
summary: 团队仓库交付与代码修改 SOP：先检索团队 skill 经验、先跑基线测试、只改必要文件、用 node --test 验证并说明改动；含 fetch-resource 资源读取工具的行为契约与调用协议。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库（evaluation 评测相关模块）的新增工具、测试补充与代码修改类任务，也适用于任何"先借鉴团队经验、再最小化改动并保证已有行为不变"的交付场景。Agent 接到此类任务时，应按本文件的 SOP 执行，而不是直接开写。

## 适用条件
- 任务涉及新增/修改工具与测试，且要求"已有行为不变"。
- 任务需要读取团队知识库中 skill 的资源文件（bridge 交互）。
- 交付目录的测试统一以 `node --test` 运行 `*.test.mjs`。

## 核心 SOP
- 先检索团队经验：动手前检索一次团队知识库中的 skill，有相关参考就借鉴，没有则按自己的判断处理（团队把过往经验沉淀为 skill）。
- 先建基线再改动：改动前运行 `node --test evaluation/`，确认当前测试状态，才知道后续"行为是否改变"。
- 只改必要的文件：最小化改动面，降低回归风险与 review 成本。
- 为新增工具补测试：每个新工具至少覆盖其行为契约的关键分支。
- 回归验证：改动后用 `node --test` 跑 evaluation 下全部 `*.test.mjs`。
- 交付说明：结尾说明改了什么、为什么改。

## 判断逻辑
- 先基线后改动的价值：只有掌握改动前的 pass 状态，"已有行为不变"才是可验证的结论，而非口头承诺。
- 经验检索优先于自造：团队经验以 skill 形式沉淀，先检索可以复用既有判断、避免重复踩坑；无参考时才退回自主判断。
- "只改必要文件"是评价口径：改动越聚焦，越容易证明没有引入无关回归。

## 禁忌与反模式
- 不要吞掉上游错误：上游错误信封（code !== 0）必须抛出 Error 并在 message 中带上信封 message，禁止静默处理。
- 不要假定资源一定是文本：必须按 `data.encoding`（utf-8 / base64）解码还原字节。
- 不要把空内容等同于缺失或错误：空资源（或信封缺少 content）应返回零字节 Buffer，空文件是合法文件。
- 拼接 base 与子路径时不要出现双斜杠或漏斜杠。
- 不要跳过测试直接交付，也不要顺手改与任务无关的文件。

## 关键事实依据
- fetchResource({ skillId, path, bridgeBase, fetcher }) 契约：成功返回资源原始字节 Buffer（调用方可直接写文件）；空资源→零字节 Buffer；上游错误信封→throw Error 且带 message；fetcher 用于注入 HTTP 实现（测试传桩），缺省 `globalThis.fetch`。
- skill-bridge 读取协议：`POST <bridgeBase>/files/read`，请求体 `{ skill_id, path }`，请求头 `content-type: application/json` 与 `x-tdai-service-id: default`；响应为标准信封 `{ code, message, request_id, data }`，`data.content` 为内容字符串，`data.encoding` 标明编码。
- 验证结果：evaluation 全量测试 637 pass / 0 fail / 2 skipped。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs（fetchResource 实现）
- evaluation/gate/fetch-resource.test.mjs（5 条用例：按 encoding 解码返回 Buffer、空资源返回零字节 Buffer、错误信封抛出带 message 的 Error、POST /files/read 请求参数、缺省使用 globalThis.fetch）

## 演化记录
（暂无）

## 待确认问题
- 工具导出参数名写作 `skillId`，而 bridge 请求体字段为 `skill_id`，命名映射由实现负责转换；是否需要统一命名待团队确认。
