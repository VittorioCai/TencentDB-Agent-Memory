-----META-START-----
created: 2026-09-13T17:01:39.217Z
updated: 2026-09-13T17:01:39.217Z
summary: 团队 skill 资源拉取工具的接口契约、bridge 信封解码规则、空资源与错误透传处理，以及动手前先检索团队知识库经验的协作约定与测试回归要求。
heat: 1
-----META-END-----

## 工作场景
适用于在仓库工具链（如 evaluation/gate/）中新增"把团队 skill 资源文件取到本地"一类的拉取工具，涉及 skill bridge 的信封协议、按 encoding 解码原始字节、错误透传，以及"动手前先检索团队知识库 skill"的协作约定。核心产出是可复用的接口契约与测试策略。

## 适用条件
需要从团队知识库 / skill bridge 拉取资源时；需要为 evaluation 下工具补测试且要求既有 *.test.mjs 全部通过、行为不变、只改必要文件时；Agent 接到此类任务准备动手前。

## 核心 SOP
- 先检索团队经验：动手前在团队知识库以 skill 形式检索一次过往经验，有相关就参考，没有则按自己判断处理。
- 明确接口契约：fetchResource({ skillId, path, bridgeBase, fetcher }) —— 成功返回资源原始字节 Buffer（调用方可直接写盘）；空资源返回零字节 Buffer；错误信封抛出 Error。
- 从信封解码：`<bridgeBase>/files/read` 始终返回 JSON 信封，不流式返回原始字节；按 data.content 的 encoding（utf-8 / base64）在客户端解码得到字节。
- 注入 fetcher：HTTP 实现经 fetcher 参数注入，测试传桩，缺省 globalThis.fetch。
- 补测试并回归：覆盖原始字节、空资源零字节、base64 解码、错误信封抛错、缺失 content 报错；运行确认 evaluation 下 *.test.mjs 全绿且行为不变。
- 交付时说明改了什么、为什么。

## 判断逻辑
- bridge 只返回信封，字节必须客户端解码，否则会把 JSON 误当文件内容写盘。
- 空字符串是合法资源：只有 content 缺失或非字符串才算错误，避免误判字段缺失。
- 错误必须透传：code !== 0 时把信封 message 带进 Error，否则调用方只剩无解释的失败。
- 最小改动优先：只改必要文件，保持既有测试与行为不变，降低回归风险。

## 禁忌与反模式
- 不要把空 content 当字段缺失报错：空文件是合法文件，应返回零字节 Buffer。
- 不要吞掉上游错误原因：应抛出携带信封原始 message 的 Error。
- 不要指望用 curl 的 -o 等客户端参数让服务端"流式"返回原始字节：服务端看不到，仍需从信封解码。
- 不要改动无关文件或破坏既有 *.test.mjs 行为。

## 关键事实依据
- MemoryCore 核心 readFile 返回 content: string，encoding 取值为 "utf-8" 或 "base64"。
- 团队知识库 skill `eval-skill-resource-download`（tracking 值 bt-pu6nyfhmu2v）记录 bridge 信封行为。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs：skill 资源拉取工具，注释说明 bridge 信封行为与空资源/错误信封处理规则。
- evaluation/gate/fetch-resource.test.mjs：配套测试（原始字节返回、空资源零字节、base64 解码、错误信封抛错、缺失 content 报错）。

## 演化记录
- [2026-09-13]：建立本场景，沉淀 fetchResource 契约、bridge 信封解码与错误透传规则、团队经验检索约定。

## 待确认问题
- 团队经验检索目前依赖人工执行，是否需要在 Agent 工作流中固化为前置步骤尚待确认。
