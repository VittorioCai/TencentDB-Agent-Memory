-----META-START-----
created: 2026-09-13T17:02:35.101Z
updated: 2026-09-13T17:02:35.101Z
summary: 本仓库新增工具类任务的复用方法：动手前先检索团队 skill 经验，按接口契约实现，补测试并保证现有测试全绿，只改必要文件，最后说明改了什么与为什么。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库（如 evaluation/ 目录）新增或修改工具、脚本的工程任务，尤其需要对接团队知识库 skill-bridge 并要求交付可验证的场景。可复用于任何"先查经验、再动手、后验证"的工具开发。

## 适用条件
团队把过往经验沉淀为 skill 存于知识库；任务涉及新增可被测试覆盖的工具模块；约束为改动范围小、不破坏已有行为、结果可验证。

## 核心 SOP
1. 先检索团队经验：开发前检索一次团队 skill，有相关经验（如 eval-bridge-endpoint，skl-oBaDO5CceKnr）则参考，没有则按自己判断实现。
2. 先定接口契约，再写实现。
3. 只改必要文件，保持已有行为不变。
4. 为新增能力至少补一条测试；用 node --test 跑 evaluation 下 *.test.mjs，确保全部通过。
5. 交付时说明改了什么、为什么。

## 判断逻辑
- 团队经验优先于个人判断，避免重复踩坑；只有无匹配经验时才自主决策。
- 接口以"调用方直接可用"为准：返回资源原始字节 Buffer，调用方可直接写文件，减少适配层。
- 空与错误必须分离：空内容返回零字节 Buffer（空文件合法）；上游错误信封（code !== 0）必须抛出 Error 并携带信封 message，不得吞掉，使调用方能区分"合法空结果"与"调用失败"。
- 依赖可注入：fetcher 用于注入 HTTP 实现（测试传桩），缺省 globalThis.fetch，便于测试且不绑定全局实现。

## 禁忌与反模式
- 未检索团队经验就直接实现：可能重复已有方案或踩已知坑。
- 吞掉上游错误信封：错误被静默，调用方无法感知失败；应抛出 Error 并带信封 message。
- 把空文件当错误：空内容是合法文件，应返回零字节 Buffer 而非抛错。
- 硬编码 HTTP 实现：应经 fetcher 注入，缺省 globalThis.fetch。
- 超范围改动或破坏已有行为：提交前必须跑通 evaluation 下全部 *.test.mjs。

## 关键事实依据
- 交付物：evaluation/gate/fetch-resource.mjs，导出 async fetchResource({ skillId, path, bridgeBase, fetcher })。
- skill-bridge 接口：POST /skill-bridge/v3/skill/files/read（skill_id、path、encoding，如 utf-8）；/v3/skill/get（skill_id、include_content、include_manifest）；/v3/skill/search（query）。调用需带 x-tdai-service-id 与 x-conversation-id 头部。

## 相关任务与资产
- 新增 fetch-resource.mjs 并补测试，保证 evaluation 下 node --test 全部通过、行为不变。

## 演化记录
（暂无）

## 待确认问题
- bridgeBase 的具体取值与与技能资源的拼接方式未明确，实现前需确认。
