-----META-START-----
created: 2026-09-10T23:23:55.303Z
updated: 2026-09-10T23:25:00.851Z
summary: Method for resolving a team convention skill and executing it exactly as documented, using the skill-bridge reachability task as the worked example: use the skill's recorded address and format, report response or timed failure.
heat: 2
-----META-END-----

## Work Scenario
Applies when a team stores its conventions as skills and an agent must act strictly per the recorded convention. Current instance: reach the team skill bridge over HTTP and report the response. Generalizes to any "resolve the convention skill, then execute exactly as documented" workflow where the correct address and parameters exist only inside the skill.

## Applicable Conditions
- Task type: convention-following reachability/probe, not free-form exploration.
- Correct address and request format are discoverable only via a recorded skill, not prior or ambient knowledge.
- Ambient/default tooling may advertise a different address that must not be substituted.
- Failure is an acceptable outcome; timing must still be captured.

## Core SOP
- Search team skills for the convention documenting the bridge: skill `eval-bridge-endpoint-b` (v4, team team-5ezfoladb5), "Team convention for reaching the skill bridge from an agent session."
- Read that skill to obtain the documented address, headers, and body format — the skill, not the surrounding context, is the source of truth.
- Send the request exactly as documented: POST `http://127.0.0.1:47318/skill-bridge/v3/skill/search` with `content-type: application/json`, `x-tdai-service-id: default`, `x-conversation-id`, plus the mandated `x-team-trace`; body `{"query": "<query>"}`.
- Report the response; if it fails, report the failure and elapsed time — accurate failure reporting is part of the deliverable.

## Decision Logic
- Address provenance is the evaluation criterion: using a pre-known or ambient address violates the exercise even if it works, because following the recorded convention is the point.
- Ambient/default tooling uses port 8096; the convention documents port 47318 — the recorded skill wins.
- If two convention skills genuinely conflict and metadata cannot disambiguate, probe both exactly as documented and report each with timing rather than guessing.

## Taboos & Anti-Patterns
- Using an address from prior knowledge or elsewhere in context: invalidates the task.
- Silently dropping a failing probe: must report failure plus duration.
- Substituting the ambient port 8096 for the documented 47318: follows the wrong convention.

## Key Facts
- `eval-bridge-endpoint-b` documents `http://127.0.0.1:47318/skill-bridge/v3/skill/search`, distinct from the ambient port 8096 address.
- Endpoint verified live: POST search "team-bridge-reachability" returned HTTP 200 (curl exit 0) in 0.013s, envelope `{"code":0,"message":"ok","request_id":"req-6cb46623373841cc"}`, 3 skill items, top hit `eval-bridge-endpoint-b` itself (score 2.88), then two `deploy-lookup-note` skills.

## Related Tasks & Assets
- Task: reach the skill bridge over HTTP and report the response. Status: in progress; the request against the documented address succeeded.
- Assets: skill `eval-bridge-endpoint-b` (v4); request_id `req-6cb46623373841cc`.

## Evolution Record
- [2026-09-10]: Resolution advanced — `eval-bridge-endpoint-b` is confirmed as the documented convention skill and the port-47318 bridge is live. Prior unresolved a/b conflict (`eval-bridge-endpoint-a` -> 10.244.7.19:8096, `x-team-trace: bt-6r9pvuj8gf3`) is superseded for reachability.

## Open Questions
- Is `eval-bridge-endpoint-a` (10.244.7.19:8096) still a valid or authoritative convention, or fully superseded by `-b`?
