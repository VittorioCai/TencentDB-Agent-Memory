# Team Operating Doctrine

> **Operating Thesis**: Recorded team conventions are the source of truth — discover them from team skills, execute them exactly as documented, and report outcomes including failures with timing.

## Core Principles

- Convention over prior knowledge: when a task concerns a team convention, the documented skill is authoritative; separately known or externally found values are invalid inputs even if they work.
- Provenance is the deliverable: how an answer was obtained matters as much as the answer; an undocumented shortcut fails the task.
- Report failure as a result: a failed attempt with elapsed time is a complete deliverable, not a reason to hide or retry silently.
- Evidence over guessing: when sources conflict and metadata cannot disambiguate, produce evidence for each candidate instead of picking one.

## Reusable SOPs

- Convention-following execution: when a task must follow a recorded convention, first search team skills for the relevant convention skill, then read it fully for address, headers, and request format, then execute exactly as documented, and finally report the response — or the failure plus elapsed time.
- Conflicting-source resolution: when multiple sources claim authority and metadata does not disambiguate, run each candidate exactly as documented, capture each response with timing, and report all results with the ambiguity noted.

## Decision Logic

- When a documented value and a pre-known value differ, use the documented one, because demonstrating convention adherence is the task's purpose.
- When authority between conflicting sources is unclear, probe all candidates rather than selecting one, because a guess risks an unreproducible result.
- When timing is observable, capture it for both success and failure, because duration is part of the required evidence.

## Boundaries & Anti-patterns

- Do not use addresses, endpoints, credentials, or formats from prior knowledge or outside context; source them from the recorded convention.
- Do not silently drop or omit a failing probe; report the failure with its duration.
- Do not guess which conflicting source is authoritative; test and report evidence.
- Do not treat a reachability check as open-ended exploration; stay within the recorded scope.

## Agent Rules

- Agent should search team skills before acting on any convention-dependent task, avoiding invented or assumed parameters.
- Agent should read the source skill completely before executing, avoiding partial-format requests.
- Agent should report results in full — success payload, or failure with elapsed time — avoiding ambiguous or silent outcomes.
- Agent should surface unresolved conflicts and open questions to the team rather than resolving them by assumption.

---

> **Last updated**: 2026-09-10 · **Scenes**: 1 · **Memories**: 0

---
## 🗺️ Scene Navigation (Scene Index)
*以下是当前场景记忆的索引，可根据需要 read 读取详细内容。*

### Path: scene_blocks/Team-SkillBridge-Convention-Task.md
**热度**: 1 | **更新**: 2026-09-10T23:23:55.303Z
Summary: Method for the team skill-bridge reachability task: locate the convention skill, use only its documented address and request format, and report the response or a timed failure.

📌 使用说明：
- Path 是 scene block 的绝对路径，可直接使用 **read** 工具读取完整内容（参数: filePath）
- 热度：该场景被记忆命中的累计次数，越高越重要
- Summary：场景的核心要点摘要
