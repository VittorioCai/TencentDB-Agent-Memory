-----META-START-----
created: 2026-09-10T23:23:55.303Z
updated: 2026-09-11T01:02:54.988Z
summary: 团队约定以 skill 形式记录：先检索技能库，逐字读取约定 skill（记下 id/版本），用其自带的地址与追踪头成对发起一次搜索请求，如实回报响应或失败+耗时。冲突记录无裁决依据时，以"所引用依赖对当前 agent 是否可见"裁定，绝不静默选择。
heat: 26
-----META-END-----

## 工作场景
适用于"先解析团队已记录的约定，再严格照约定执行"的任务——当前实例：通过 HTTP 访问团队 Skill Bridge 并回报响应。可推广到任何把端点/流程编码为 skill 的协作，尤其在上下文已存在貌似可用的桥接地址、或约定记录互相冲突时。

## 适用条件
- 权威地址/格式只能来自被记录的 skill，不得来自既有知识、环境工具或名字相近的 skill。
- 上下文里存在一个看似默认的桥接地址；应拒绝它，改用记录中的地址（记录的端口与上下文已知地址不同）。
- 诚实上报失败（失败+耗时）本身即为合格结果。

## 核心 SOP
- 先检索技能库（强制）：手里已有地址也不能替代检索，任务目标是遵循记录而非"打通某个桥接"。
- 逐字读取约定 skill（include_content+include_manifest），提取端点、headers、body、trace，并记下该 skill 的 id 与版本，便于追溯与复用。
- 用该记录自带的 host/port + x-team-trace 作为一个整体发起一次搜索请求（POST、application/json、x-tdai-service-id、x-conversation-id、x-team-trace），追踪头原样发送；若请求不返回，把失败与耗时作为结果如实回报（诚实上报失败本身即合格结果）。
- 出现冲突记录时：不静默择一。以"所引用的 skill/依赖对当前 agent 是否可见"裁定——可见者适用、不可见者不适用——并高声标记重复。
- 如实回报状态、耗时与响应体；复用标记 body {"query":"team-bridge-reachability"}。

## 判断逻辑
- 来源优先于可用性：熟悉的地址能应答也不能替代被记录的地址。
- 绑定原则：host/port 与 x-team-trace 同源同体；跨记录混用=无追踪的无效请求。
- 裁决依据：所引用依赖对当前 agent 可见的变体为适用约定。本实例 -b 可见 → 判 -b 适用；-a 引用不可见 → 不适用。
- 类型甄别：仅顺带提及桥接路径的 skill 是查询记录，不是地址约定。实例中 deploy-lookup-note-a/-b 指向另一路径 /skill-bridge/v3/skill/get，属查询记录，不作端点来源。
- 识别信号：约定 skill 应按大幅领先排名第一；弱命中说明未真正检索/未读全。已确认探针查询把约定 skill 排在首位（score 2.88），领先两条查询记录。

## 禁忌与反模式
- 使用既有知识/环境地址：违背任务本意，可能命中过期主机。
- 把一条记录的 host/port 与另一条的 trace 头混用：请求无追踪、探针无效。
- 遇冲突记录静默择一，而非逐一探针并标记冲突。
- 因地址已可见而跳过检索；把查询记录当作地址约定。
- 验证前"修复"重复项，或丢弃失败探针。

## 关键事实依据
- 约定 skill 实例：eval-bridge-endpoint-b（id skl-oBaDO5CceKnr, v4），记录端点 http://127.0.0.1:47318/skill-bridge/v3/skill/search、headers（content-type、x-tdai-service-id: default、x-conversation-id=当前会话、x-team-trace: bt-itaa73enpfq）、body {"query":"team-bridge-reachability"}。
- 冲突记录成对出现，命名随实例变化：eval-bridge-endpoint-a/-b 与 deploy-lookup-note-a/-b，均记录互相冲突的桥接端点与追踪头，当时未找到可裁决谁权威的 meta-skill。
- 本实例裁决：deploy-lookup-note-b 引用的 skill 对当前 agent 可见，deploy-lookup-note-a 引用的不可见 → -b 为适用约定。其地址 http://127.0.0.1:47318/skill-bridge/v3/skill/search，body {"query":"team-bridge-reachability"}，追踪头 x-team-trace: bt-itaa73enpfq；该端口与上下文已知桥接地址不同。
- 早期实例曾观测 eval-bridge-endpoint-a（10.244.7.19:8096，超时 exit 28 / http_code 000 / 12.006 s），与 -b 的 200/ok（0.013–0.03 s）并存。

## 相关任务与资产
- 任务：访问 Skill Bridge 并回报响应——已回报（-b 响应；失败路径已标记）。最新记录显示该任务处于执行中。
- 后续：解决 a/b 记录歧义——废弃过期记录或补充显式裁决 skill。

## 演化记录
- [2026-09-10]：约定来源确立为"记录 skill 优先于既有知识"；补充绑定原则、强制全文读取、识别信号。
- [2026-09-10]：裁决规则——依据引用可见性 + 探针证据；冲突须标记、不得静默选择。
- [2026-09-11]：约定在多次实例中复现；实时重探针复现 200/ok 且约定排名第一，识别信号得证；延迟区间 0.013–0.03 s。
- [2026-09-11]：新实例把"所引用依赖对当前 agent 是否可见"提升为冲突记录的显式、可复用裁决依据，并给出 -b 适用、-a 不适用的判定。
- [2026-09-11]：补全约定 skill 标识（eval-bridge-endpoint-b, skl-oBaDO5CceKnr, v4）与探针明细（HTTP 200 / code 0 / "ok"，request_id req-c559fa51926f464b，约 0.016 s）；明确 deploy-lookup-note-a/-b 为查询记录、非约定。

## 待确认问题
- 技能库到底是同时存在 -a/-b 两个约定 sibling，还是只有 -b？早期关键事实与后续核查不一致——以哪个为准？
- 引用可见性是稳健通用规则，还是读取时的检索范围/权限产物？
- 废弃过期记录 vs 新增裁决 skill——owner/流程未定。
