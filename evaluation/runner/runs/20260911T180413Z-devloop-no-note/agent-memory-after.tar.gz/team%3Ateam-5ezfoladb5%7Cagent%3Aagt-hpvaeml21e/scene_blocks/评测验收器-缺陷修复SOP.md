-----META-START-----
created: 2026-09-11T15:00:56.385Z
updated: 2026-09-11T16:07:25.876Z
summary: 评测验收器/验证脚本缺陷修复的可复用SOP：先检索团队skill经验，定位根因做最小改动，补回归测试并保证全量测试通过，最后说明改动与原因。
heat: 3
-----META-END-----

## 工作场景
适用于修复评测验收器、验证脚本（如 evaluation/tasks/*/verify.mjs）及同类工具链缺陷。核心方法链：先检索团队经验 → 定位根因 → 最小改动 → 补回归测试 → 全量回归 → 说明变更，可复用于任何脚本级 bug 修复。

## 适用条件
- 任务类型：修复已有评测/验证工具的逻辑缺陷（含超时判定、退出码解析），非新功能开发。
- 背景：团队把过往经验以 skill 形式沉淀在知识库（如 bridge-addr 相关的 eval-bridge-endpoint-b），要求动手前先检索。
- 约束：改动可控、不破坏既有行为、且必须可验证。

## 核心 SOP
- 动手前检索一次团队知识库 skill：有相关经验则参考，没有则按自己判断执行。
- 定位根因：先确认「应失败却未失败」的信号为何丢失。bridge-addr 案例中，verify.mjs 的 outcomeOfAttempt 用大小写敏感正则 `/Exit code:/` 匹配 CodeBuddy 输出，而实际为 `Exit Code:`，致 curl 退出码 28 的超时被判 ERROR（不可读）而非 FAIL。
- 选可靠信号：短语匹配（如 'Resolving timed out'）可能不命中、stderr 可能为空；退出码始终存在，应作超时判定主依据。
- 最小改动：只改必要文件（本例将退出码提取正则改为大小写不敏感，追加 `/i`）。
- 补回归测试：覆盖缺陷场景（本例 verify.test.mjs 覆盖大写 `Exit Code: 28`，断言判为 FAIL/timed out 而非不可读）。
- 全量验证：修复后 evaluation 下全部 *.test.mjs 需通过 `node --test`，既有行为不变。
- 交付说明：最后说明改了什么、为什么。

## 通用交付检查清单
只改必要文件 · 保持已有行为不变 · 补回归测试 · 改完运行相关测试确认通过 · 说明改动与原因。

## 判断逻辑
- 验收口径为「全量测试通过 + 既有行为不变」，用测试防回归。
- 优先复用团队已有 skill 减少重复踩坑，无经验时才自行判断。
- 采用最小改动原则，控制影响面、降低风险。
- 根因优先于表象：区分「超时」与「失败」语义，避免把失败误记为「不可读」这类中间态。

## 禁忌与反模式
- 只依赖脆弱文案/短语匹配判定超时：文案变动或 stderr 为空即漏判，改用稳定退出码。
- 忽略大小写/格式差异：CodeBuddy 输出 `Exit Code:`（首字母大写），大小写敏感正则会漏匹配。
- 借机大范围重构、修改非必要文件：扩大风险面，违背最小改动。
- 只修 bug 不补回归测试：同类缺陷会再次出现。
- 跳过团队经验检索直接开工：可能重复已有踩坑。

## 关键事实依据
- bridge-addr 评测验收器 evaluation/tasks/bridge-addr/verify.mjs 超时误判已定位并修复：正则漏匹配大写 `Exit Code:` → 退出码 28 超时被判 ERROR 而非 FAIL；修复为大小写不敏感匹配并补回归测试，相关及 evaluation 全部 *.test.mjs 均通过。

## 相关任务与资产
- 状态：verify.mjs 超时误判修复与回归测试已完成并通过验证。
- 资产：evaluation/tasks/bridge-addr/verify.mjs；evaluation/tasks/bridge-addr/verify.test.mjs；evaluation 目录下的 *.test.mjs；团队知识库 skill（eval-bridge-endpoint-b）。

## 演化记录
- [2026-09-11]：由「待定位根因」推进为「根因确认并修复」——超时误判源于大小写敏感退出码正则漏匹配 `Exit Code:`，改为大小写不敏感并补回归测试。

## 待确认问题
- 团队知识库/skill 的检索入口与存放位置仍未记录（已知有 eval-bridge-endpoint-b，但无访问路径）。
- 是否还有其他 verify.mjs 使用同类脆弱正则（文案/大小写敏感匹配），需排查。
