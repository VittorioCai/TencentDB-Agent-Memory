-----META-START-----
created: 2026-09-11T18:06:03.428Z
updated: 2026-09-11T18:17:40.191Z
summary: 团队缺陷修复通用 SOP：先检索团队 skill 经验、定位根因、只改必要文件、保既有测试全绿并补回归；沉淀 shell 工具结果信封（Exit Code 大小写与尾部 section）解析原则。
heat: 2
-----META-END-----

## 工作场景
适用于本仓库团队的"定位并修复缺陷"类任务，尤其是带自动化测试（node --test 运行 *.test.mjs）的工具/脚本链路。典型实例是 evaluation/attribution/collect-artifacts.mjs 归因工具解析真实 CodeBuddy 工具结果、生成操作清单。该 SOP 与解析原则可复用到任何"改代码 + 保测试 + 补回归"的工程师或 Agent 任务，以及任何需要解析外部工具输出信封的场景。

## 适用条件
- 任务类型为 bug 修复，仓库已有测试基础设施与既有行为基线。
- 团队把过往经验以 skill 形式存放在团队知识库中。
- 缺陷源于"真实输入格式"与"代码假设格式"不一致（大小写、信封字段/尾部 section 差异）。

## 核心 SOP
- 动手前先检索团队经验：通过 skill-bridge v3 的 skill/get-by-name 接口检索一次；有相关经验就参考，没有则按自身判断执行。
- 先复现并定位根因：读真实输入样本，对比"实际格式"与"代码匹配模式"，不凭假设推断。
- 修复前记录基线测试结果，用于区分"预存在失败"与"本次引入失败"。
- 只改必要文件，最小改动范围，降低副作用风险。
- 修复后跑全量测试，确认全部通过且已有行为不变。
- 补一条回归测试，按真实样本形状断言，锁定同类问题不复发。
- 最后说明改了什么、为什么。

## 判断逻辑
验收硬基线是"既有测试全绿 + 已有行为不变"。先测基线再修：本次基线为 547 通过 / 3 失败，3 个失败是 evaluation/gate0/artifacts/ 缺少 fixture 的预存在问题，与本次无关，不能当作回归去修。根因定位优先看真实数据格式而非代码注释：outcomeOf 仅用小写正则 `Exit code:`，真实信封用大写 `Exit Code:`，且既有合成 fixture 不含尾部 section，故缺陷长期未被测试暴露。检索团队经验的目的在于避免重复踩坑，无相关经验时按自身判断推进并如实记录"无参考"结论。

## 禁忌与反模式
- 不要假设工具输出字段格式：大小写、字段名、尾部 section 都可能不同，假设即埋雷。
- 不要用与真实输入形状不一致的合成 fixture 做唯一验证：漏掉尾部字段正是此类缺陷长期潜伏的原因。
- 不要把预存在失败当本次回归去修，也不要因其误判修复失败。
- 不要扩大改动范围或改变既有行为来"顺带修好"。

## 关键事实依据
- 真实 CodeBuddy Bash 结果信封：`Command:`、`Stdout:`、`Stderr:`（空写作 `Stderr: (empty)`）、`Exit Code: <数字>`（大写 C，在 Stderr 之后）、`Signal:`（无写作 `Signal: (none)`）。
- 修复内容：`Exit Code:` 改为大小写不敏感匹配并支持负数码；stderr 截断到下一个尾部 section（`Exit Code:` / `Signal:`）之前；`(empty)` 归一化为空字符串。
- 回归测试：新增 evaluation/attribution/collect-artifacts.test.mjs，断言 exit_code 为 0 和 28，且尾部 section 不被读入 stderr。

## 相关任务与资产
- 已完成：collect-artifacts.mjs exit_code 恒 null 的根因定位与修复；回归测试已补齐。
- 检索工具：skill-bridge v3 skill/get-by-name 接口。检索结果为无关干扰（deploy-lookup-note-b、eval-bridge-endpoint-b），本次按自身判断修复。

## 演化记录
- [2026-09-11]：缺陷由"待修复/根因未定"推进为"已定位并修复（大小写不敏感 + 尾部 section 截断）并补回归测试"；因果链从"大小写不一致"细化为"大小写不一致 × 合成 fixture 缺尾部 section"。

## 待确认问题
- 3 个预存在 fixture 缺失失败是否另行跟进，尚无结论。
