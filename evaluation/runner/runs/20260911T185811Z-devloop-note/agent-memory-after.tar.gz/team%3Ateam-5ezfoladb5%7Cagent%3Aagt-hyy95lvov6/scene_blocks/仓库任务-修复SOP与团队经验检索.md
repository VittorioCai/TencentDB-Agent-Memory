-----META-START-----
created: 2026-09-11T18:02:27.405Z
updated: 2026-09-11T18:17:40.828Z
summary: 本仓库任务方法：动手前先检索团队 skill 知识库；修复遵循"复现根因→最小改动→补回归测试→跑全量→说明改动"SOP，区分既存与新引入失败，回归 fixture 须用真实系统输出格式。
heat: 2
-----META-END-----

## 工作场景
适用于本仓库（含 evaluation/ 归因工具链）的工程任务，尤其是缺陷定位与修复；凡"团队有知识库沉淀"的仓库，任务启动流程同样适用。

## 适用条件
- 任何动手处理仓库任务之前（团队约定必执行）。
- 带既有测试、要求"已有行为不变"的修复类任务。
- 解析真实运行时数据的解析器（正则/文本匹配）调试场景。

## 核心 SOP
- 先检索团队经验：动手前用关键词（工具结果、exit status、exit_code、capture、归因、CodeBuddy 格式等）检索一次团队 skill 知识库；命中则参考，未命中则按自身判断处理。
- 修复流程：在真实数据上复现并定位根因→最小化改动→补针对该缺陷的回归测试→用 node --test 跑 evaluation 下全部 *.test.mjs→说明改了什么、为什么。
- 回归测试设计：覆盖真实格式、兼容旧格式、无状态段返回 null，并做端到端断言（结果字段被正确填充）。
- 结果核验：区分"既存失败"与"本次引入的失败"，并对比改动前后的用例/通过数再判定成功。

## 判断逻辑
- 为何行为不变 + 只改必要文件：压缩改动半径，降回归风险，使修复可审计、可回退。
- 为何用大小写不敏感标志而非改写正则字面量：真实数据为大写、手写 fixture 为小写，/i 同时兼容两者且不破坏旧 fixture。
- 为何先复现再改：确认真实 capture 的实际文本形态，避免凭猜测改错位置或漏改。
- 为何用真实格式做 fixture：缺陷长期未被发现正是因 fixture 拼写与真实不符；真实格式才能暴露问题。

## 禁忌与反模式
- 不要只按手写 fixture 格式写解析正则：真实数据可能在大小写/空格/符号上不同，导致字段恒 null 而静默失效。
- 不要把既存失败当作自己引入的回归：先确认失败来源（如缺失 fixtures）。
- 不要为修一个字段重写整段逻辑或改无关文件。
- 不要跳过回归测试与最终改动说明。

## 关键事实依据
- 缺陷：collect-artifacts.mjs 的 outcomeOf 仅匹配小写 `Exit code:`，而真实 CodeBuddy Bash 结果信封为分段格式 Command/Stdout/Stderr/Exit Code/Signal，写 `Exit Code:`（正常 0、超时 28），故 exit_code 恒为 null，下游按退出状态分类失败调用的逻辑失效。
- 修复：正则改为 /(?:^|\n)Exit code:\s*(-?\d+)/i，大小写不敏感并支持负数退出码。
- 验证：改动后全量 555 tests/550 pass/3 fail，改动前 552/547/3 fail；3 个失败均为 evaluation/gate0/artifacts/ fixture 缺失的 ENOENT，无新增回归。

## 相关任务与资产
- evaluation/attribution/collect-artifacts.mjs（修复）；collect-artifacts.test.mjs（新增回归测试，含大写 0/28、旧小写+无状态段返回 null、端到端 exit_code 0/1 三组用例）。
- 测试入口：node --test 运行 evaluation 下全部 *.test.mjs。

## 演化记录
- [2026-09-11]：从"仅按手写 fixture 写解析"调整为"以真实 capture 格式为准并加 /i 兼容"，原因：小写 fixture 掩盖了大写 `Exit Code:` 的真实拼写，导致字段恒 null。

## 待确认问题
- evaluation/gate0/artifacts/ fixtures 是否会补齐，3 个既存失败是否需单独跟进。
