-----META-START-----
created: 2026-09-13T12:18:29.262Z
updated: 2026-09-13T12:18:29.262Z
summary: 团队在改造仓库（如 evaluation/gate 新增工具）时的通用方法：先检索团队 skill 经验库，再做最小改动，补测试并用 node --test 验证，最后交付改动说明。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库所属团队的任何"在现有代码库中新增/修改工具与模块"的任务，尤其是 evaluation/gate 一类带接口契约与测试门槛的目录。可复用场景包括：Agent 接到实现类任务后的开工前准备、改动范围控制、测试验收与交付汇报。

## 适用条件
- 项目阶段：已有代码基线与测试套件，改动需保持向后兼容。
- 团队约束：过往经验以 skill 形式沉淀在团队知识库中，成员与 Agent 均可检索。
- 风险背景：接口契约（返回类型、错误处理）必须精确，测试需可在 CI 中运行（node --test）。

## 核心 SOP
- 开工前检索团队经验：先查一次团队知识库中的过往 skill，有相关经验则参考，无则按自身判断执行；目的是复用已验证做法、避免重复踩坑。
- 只改必要的文件：改动面越小，回归风险与评审成本越低；不顺手重构无关代码。
- 为新增能力补测试：新工具至少一条测试，用桩依赖覆盖边界行为。
- 改动后运行验证：`node --test` 跑通 evaluation 下所有 `*.test.mjs`，且已有行为不变。
- 交付时说明"改了什么、为什么改"：让 reviewer 不必靠 diff 反推意图。

## 判断逻辑
团队把"经验检索"放在开工之前而非遇到困难之后，因为方案选型成本远高于检索成本。契约优先于实现：先固定返回类型与错误语义，再写实现与桩测试，可让测试在不依赖真实上游的情况下验证边界。测试通过且旧用例不回退，被当作"改动正确"的统一口径；因此宁可少改，也不为"顺手优化"引入不确定性。

## 禁忌与反模式
- 跳过经验检索直接实现：可能重复已有 skill 中已解决的方案。
- 空资源返回 null 或抛错：空文件是合法文件，必须返回零字节 Buffer。
- 吞掉上游错误：`code !== 0` 的信封必须转为 Error 并在 message 中带上信封 message。
- 改动无关文件或放宽现有测试：破坏"已有行为不变"的验收前提。
- 交付只给 diff 不给理由：增加评审与回溯成本。

## 关键事实依据
- `evaluation/gate/fetch-resource.mjs` 契约：`fetchResource({ skillId, path, bridgeBase, fetcher })` 成功返回资源原始字节 Buffer（调用方可直接写文件）；空内容返回零字节 Buffer；上游错误信封 `code !== 0` 抛 Error 并携带信封 message；`fetcher` 用于注入 HTTP 实现（测试传桩），缺省 `globalThis.fetch`。
- 实现方式：POST `/skill-bridge/v3/skill/files/read`，请求体 `{ skill_id, path, encoding: "base64" }`，响应信封 `{ code, message, data: { path, content, encoding, size_bytes } }`，按 `data.encoding` 解码回原始字节；`bridgeBase` 末尾斜杠先去掉再拼路径，避免重复拼接。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`（实现）、`evaluation/gate/fetch-resource.test.mjs`（测试）：桩 fetcher 覆盖二进制 base64 往返字节不变、空资源零字节、utf-8 原样解码、错误信封转 Error、bridgeBase 带尾斜杠时 URL 不重复拼接。

## 演化记录
（空）

## 待确认问题
- 团队经验检索的知识库入口与检索方式（API/目录/skill 索引）尚未在记忆中明确，影响 SOP 第一步的可执行性。
