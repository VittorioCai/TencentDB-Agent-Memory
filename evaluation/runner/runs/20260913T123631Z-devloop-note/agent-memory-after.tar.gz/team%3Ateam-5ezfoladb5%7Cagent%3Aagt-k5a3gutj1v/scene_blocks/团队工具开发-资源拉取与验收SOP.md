-----META-START-----
created: 2026-09-13T12:38:05.405Z
updated: 2026-09-13T12:38:05.405Z
summary: 团队新增工具的开发与验收方法：先检索团队 skill 经验，遵循接口契约与最小改动，补测试并全量回归，开发中规避 skill bridge 的 download 缺陷。
heat: 1
-----META-END-----

## 工作场景
适用于在本仓库新增或修改工具类代码（如 `evaluation/gate/*.mjs`）并需交付测试的任务。方法可迁移到任何"先查团队经验、再按契约实现、最后回归验收"的 Agent 开发流程。

## 适用条件
- 任务属于团队共享代码库，团队把过往经验以 skill 形式存于团队知识库。
- 有明确的接口契约与验收标准（测试全绿、行为不变）。
- 涉及与上游服务（如 skill bridge）交互，需要处理信封返回值与字节内容。

## 核心 SOP
- 检索团队经验在前：动手前先检索一次团队知识库；有相关经验就参考，没有则按自身判断实现。检索可能命中 release notes 等干扰项，需判断是否真是可复用经验。
- 按契约实现接口：严格对齐参数签名、返回类型、异常语义，不自行增减或吞掉信息。
- 只改必要的文件：不做无关重构，保持已有行为不变。
- 为新增工具补一条测试，覆盖正常、边界与错误路径。
- 改完运行相关测试确认通过（`node --test` 跑 evaluation 下全部 `*.test.mjs`）。
- 交付时说明改了什么、为什么。

## 判断逻辑
- 团队经验优先：避免重复踩坑，经验缺失时以工程师判断兜底，并记录为该工具的依据。
- 验收口径以"现有测试全绿 + 已有行为不变"为准，最小改动降低回归风险。
- 取字节必须走面向字节的 `POST {bridgeBase}/files/download`，而非 `files/read`：后者无论怎么调用（含 `-o`）都只返回 JSON 信封，调用方得自行剥离 `data.content`；`files/download` 也是 `curl -o <local_path>` 配方对应的接口。
- 空资源（content 为空串）是合法文件，须解码为零字节 Buffer，不能误判为"无返回内容"而抛错。

## 禁忌与反模式
- 用 `files/read` 取资源字节：永远拿不到原始字节，替代做法是 `files/download`。
- 吞掉错误信封：上游返回 `code !== 0` 时必须抛 Error 且 message 携带信封 message。
- 把空内容当错误：空文件合法，应返回零字节 Buffer。
- 忽略 skill bridge 缺陷：其 download 路径存在把 `!content` 折叠进错误分支的问题，实现时须规避，不能照抄其分支逻辑。
- 顺带改无关文件：导致"已有行为不变"难以保证。

## 关键事实依据
- 新增工具：`evaluation/gate/fetch-resource.mjs`，导出 `async function fetchResource({ skillId, path, bridgeBase, fetcher })`，把团队 skill 资源取到本地。
- 接口契约：成功返回资源原始字节 `Buffer`（可直接写盘）；空资源返回零字节 Buffer；错误信封（`code !== 0`）抛 Error 并保留信封 message；`fetcher` 注入 HTTP 实现（测试传桩），缺省 `globalThis.fetch`。
- 实现：内部 `POST {bridgeBase}/files/download` 提交 `{ skill_id, path }`，按 `encoding`（base64 / utf-8）解码 content 为 Buffer。
- 测试：`evaluation/gate/fetch-resource.bt-dl7q3mx8vke.test.mjs` 覆盖非空原始字节、base64 解码、空资源零字节、只走 files/download、错误信封抛出并保留 message、未注入 fetcher 时回退 globalThis.fetch 六种情形。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`（工具实现）
- `evaluation/gate/fetch-resource.bt-dl7q3mx8vke.test.mjs`（回归测试，6 场景）

## 演化记录
（空）

## 待确认问题
（空）
