-----META-START-----
created: 2026-09-13T11:50:06.940Z
updated: 2026-09-13T11:56:16.229Z
summary: 沉淀团队 skill 资源获取工具 fetchResource 的设计约束、bridge /files/read 接口解析方式、端点不可信原则、动手前检索团队经验与交付测试流程。
heat: 2
-----META-END-----

## 工作场景
适用于团队 skill 资源获取工具的开发与联调：把远端 skill 的资源文件取回本地，以及围绕 bridge 数据面接口的调用、错误处理与测试。可复用于任何需要"通过 bridge 读文件并把字节落地"的共享工具。

## 适用条件
- 本仓库任何开发任务动手前（先检索团队经验，再决定是否自行判断）。
- 需通过 bridge 读取团队 skill 资源文件时。
- 编写/维护共享工具，需要为 HTTP 调用预留可测试的注入点。
- skill 文档中的端点信息与实际环境可能不一致时（案例：文档 `127.0.0.1:47318` vs 实际 `127.0.0.1:8096`）。

## 核心 SOP
- 前置检索：动手前先通过 skill-bridge 的 `skill/get` 检索团队知识库里的经验 skill（含内容与 manifest）；有相关 skill 先参考，没有则按自身判断实施。团队把过往经验以 skill 形式沉淀，忽略此步可能重复踩坑。
- 接口调用：POST `<bridgeBase>/files/read`，body `{ skill_id, path }`；解析信封 `{ code, message, request_id, data }`；按 `data.encoding`（`utf-8` / `base64`）还原原始字节。
- 工具设计：`fetchResource({ skillId, path, bridgeBase, fetcher })` 成功返回原始字节 `Buffer`；`fetcher` 注入 HTTP 实现，缺省 `globalThis.fetch`，便于测试传桩。
- 交付流程：先跑新增测试，再跑 `evaluation` 下全量 `*.test.mjs`（基线 637 pass / 0 fail）确认无回归；仅改必要文件；最后说明改了什么、为什么。

## 判断逻辑
- 端点以"实际可达"为准：调用方传入的 base URL 优先，其次对实际服务做验证，不硬编码。
- 空文件是合法文件：`content` 为空按零字节 `Buffer` 处理，而非视为缺失，避免误判。
- 错误不吞：上游 `code !== 0` 必须抛出 `Error` 并在 message 中保留信封 message，便于定位。
- Base URL 末尾斜杠需归一化，保证路径拼接一致。
- 可复现性优先：用 `fetcher` 注入桩使测试不依赖真实网络。
- 经验参考但不盲从：skill 记录的是经验而非权威，需与当前环境/实际可达性交叉验证后再采纳（端点冲突即典型）。

## 禁忌与反模式
- 硬编码 skill 文档端点：文档可能过时（案例：skill `eval-bridge-endpoint-b` 记为 `127.0.0.1:47318` 且要求 `x-team-trace` 头，实际 8096 且无需该头）。
- 向共享工具注入未经验证的 `x-team-trace` 头：会污染调用方请求。
- 把空内容当作缺失：会误报资源不存在。
- 吞掉错误信封：隐藏上游故障，难以排查。

## 关键事实依据
- 工具 `evaluation/gate/fetch-resource.mjs`；测试 `evaluation/gate/fetch-resource.test.mjs`。
- 测试覆盖：utf-8 直读、base64 解码、空文件两种编码均零字节、base URL 斜杠归一化、错误信封抛 Error 带 bridge message、fetcher 缺省 `globalThis.fetch`。
- 端点冲突经验沉淀为 `reference_skill_bridge_endpoint.md`（type: reference），在 `MEMORY.md` 登记索引。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`、`evaluation/gate/fetch-resource.test.mjs`、`reference_skill_bridge_endpoint.md`、`MEMORY.md` 索引。

## 演化记录
- [2026-09-13]：将 bridge 端点冲突从非显性经验沉淀为 reference 记忆并登记索引，供后续共享工具开发参考。
- [2026-09-13]：补充"动手前先检索团队知识库经验 skill"为前置 SOP，明确经验参考不等于盲从，需交叉验证。

## 待确认问题
- skill 文档端点与实际环境不一致是普遍现象还是个别 skill？是否需统一校对/刷新 skill 端点说明？
