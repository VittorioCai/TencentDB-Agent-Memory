-----META-START-----
created: 2026-09-11T19:00:01.252Z
updated: 2026-09-11T19:00:01.252Z
summary: 归因工具 exit_code 恒为 null 缺陷的定位与修复方法：先检索团队 skill 经验，再以大小写不敏感正则兼容真实结果，补回归测试并保持既有行为。
heat: 1
-----META-END-----

## 工作场景
适用于仓库内 evaluation/attribution 等归因、采集工具（如 collect-artifacts.mjs）的解析类缺陷定位与修复；也适用于团队处理任何"先查经验、再动手"的排查类任务。

## 适用条件
- 解析器对真实工具输出（如 CodeBuddy 工具结果）解析失败，字段恒为默认值（null）。
- 仓库已有 *.test.mjs 测试体系，要求修复不破坏既有行为。
- 团队知识库以 skill 形式沉淀过往经验。

## 核心 SOP
1. 动手前先检索团队知识库中的 skill 经验（如 eval-tool-result-exit-line）：有相关经验则参考，无则按自身判断执行。
2. 对比真实输入与手写 fixture 的差异，定位解析失败根因，而非先改下游分类逻辑。
3. 让解析规则兼容真实写法：本案例将第 124 行退出码正则改为大小写不敏感 `/(?:^|\n)Exit code:\s*(\d+)/i`，同时匹配 `Exit code:` 与真实 `Exit Code:`。
4. 仅改必要文件，保持既有行为不变。
5. 补一条覆盖真实拼写、fixture 拼写及失败传递（如 curl 52）的回归测试。
6. 运行 `node --test` 确认 evaluation 下全部 *.test.mjs 通过，最后说明改动与原因。

## 判断逻辑
exit_code 恒为 null 时优先怀疑"输入实际格式与解析假设不一致"，而非下游逻辑本身。手写 fixture 恰好用小写拼写，掩盖了大写真实结果的缺陷——fixture 若不同步真实输出就会掩盖 bug。因此修复口径是让解析兼容两种拼写，而不是改 fixture 迁就代码。

## 禁忌与反模式
- 不要用调整 fixture 来"修复"真实结果解析失败：会掩盖缺陷根源。
- 不要图省事重写下游分类逻辑：问题在解析层。
- 不要忽略既有失败基线：本仓库 HEAD 存在 3 个与本次无关的既有失败（extract-tokens fixture 缺失、缺少 gate0/artifacts/*.jsonl），基线通过 547/552；须区分既有失败与新引入失败。
- 不要改非必要文件。

## 关键事实依据
- 根因：正则只匹配小写 `Exit code:`，真实结果为大写 `Exit Code:`。
- 修复新增回归测试 evaluation/attribution/collect-artifacts.exit-status.test.mjs，新增 3 条通过测试，未引入新失败。

## 相关任务与资产
- 团队 skill：eval-tool-result-exit-line（退出状态解析经验）。
- 修复文件：evaluation/attribution/collect-artifacts.mjs。
- 回归测试：evaluation/attribution/collect-artifacts.exit-status.test.mjs。

## 演化记录
- [2026-09-11]：确立"动手前先检索团队 skill 经验"为团队约定；本案例中该 skill 直接提供了根因线索。

## 待确认问题
- 既有 3 个无关失败（extract-tokens fixture、gate0/artifacts）是否另行修复，尚未决定。
