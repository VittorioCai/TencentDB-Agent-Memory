-----META-START-----
created: 2026-09-13T11:41:07.150Z
updated: 2026-09-13T12:41:19.341Z
summary: 团队以 skill 沉淀经验，动手前先检索；新增 fetchResource 工具拉取 skill 资源文件的接口约定、交付约束与反模式。
heat: 2
-----META-END-----

## 工作场景
适用于把过往经验以 skill 形式存放在团队知识库的仓库。团队成员（含 Agent）在动手实现前需先检索团队经验，并在需要时新增 Node 工具把 skill 资源文件拉取到本地（如 `evaluation/gate/` 目录、`node --test` 测试环境）。

## 适用条件
- 仓库有团队 skill 知识库，且可经 skill-bridge 接口访问。
- 任务为新增一个 Node 工具（`.mjs`）并配套测试，且不得破坏 `evaluation` 下现有 `*.test.mjs`。
- 上游是可能返回错误信封的 HTTP 接口，需要可注入的 HTTP 实现以便测试。

## 核心 SOP
- 先检索一次团队经验 skill：有相关经验就参考，没有则按自身判断执行。
- 新增 `evaluation/gate/fetch-resource.mjs`，导出 `export async function fetchResource({ skillId, path, bridgeBase, fetcher })`，把团队 skill 的资源文件取到本地。
- 为新工具补一条测试，测试通过 `fetcher` 传桩注入 HTTP 实现。
- 只改必要的文件；用 `node --test` 跑 `evaluation` 下 `*.test.mjs`，确认全部通过且已有行为不变。
- 完成后说明改了什么、为什么改。

## 判断逻辑
- 先检索经验：团队资产优先复用，避免与既有约定冲突、重复造轮子。
- `fetcher` 注入而非硬编码网络调用：便于测试传桩、隔离网络，缺省回退 `globalThis.fetch`。
- 返回原始字节 Buffer 而非解析后对象：调用方可直接写文件，工具保持「薄」且无业务假设。
- 空资源返回零字节 Buffer 并视为合法：空文件是有效文件，不应报错。
- 错误信封（`code !== 0`）必须抛 Error 并带上信封的 message：不吞错，保留上游诊断信息。
- 只改必要文件 + 行为不变：控制影响面，保证可回归、可验证。

## 禁忌与反模式
- 跳过团队经验检索直接动手：违背团队约定，易重复已有方案。
- 吞掉上游错误或返回 undefined：调用方无法区分失败与成功。
- 把空资源当失败处理：会导致合法空文件被误判。
- 硬编码 HTTP 实现绕过 `fetcher`：测试无法传桩，网络耦合。
- 改动无关文件或破坏现有测试行为：违反「只改必要文件、行为不变」的交付约束。
- 凭猜测编造接口字段或 skill 映射：接口约定与 `skl-*`→skill 名的对应关系应来自团队资产，不要臆造。

## 关键事实依据
- skill-bridge 接口：`POST http://127.0.0.1:8096/skill-bridge/v3/skill/get`；请求体含 `skill_id`、`include_content`、`include_manifest`；请求头含 `x-tdai-service-id`、`x-conversation-id`；已知 `skl-eM1xP28pXiYA` 对应 `deploy-lookup-note-b`。

## 相关任务与资产
- 待完成：`evaluation/gate/fetch-resource.mjs` 工具 + 一条测试；验证 `node --test` 全绿。

## 演化记录

- [2026-09-13]：多批输入重复描述同一套 `fetchResource` 接口约定、交付约束与 skill-bridge 访问方式，彼此一致、无冲突，统一收敛到本文件的 SOP 与判断逻辑，不新增重复场景。

## 待确认问题
- `bridgeBase` 的默认值与来源未明确（是否指向 `127.0.0.1:8096`）。
- 错误信封除 `code`、`message` 外的字段结构未确认。
