-----META-START-----
created: 2026-09-11T14:01:28.228Z
updated: 2026-09-11T15:12:04.560Z
summary: 缺陷修复与回归测试验证方法：用 git stash 反证回归测试、甄别既有失败并坚持最小改动；以解析外部工具退出码为例说明根因定位与兼容大小写/负值。
heat: 2
-----META-END-----

## 工作场景
适用于代码缺陷修复（尤其测试/验收器逻辑缺陷）及回归测试编写与验证，代表案例为 evaluation/tasks/bridge-addr/verify.mjs 修复。可复用于任何"改一处、证明没改坏别处、并证明回归测试真能拦住缺陷"的工程任务。

## 适用条件
- 有明确缺陷，需定位根因而非绕过；代码库已有测试套件（如 *.test.mjs），且可能存在历史/环境导致的既有失败。
- 交付要求含"行为不变""只改必要文件""补回归测试"；单人、多人与 Agent 执行同样适用。
- 缺陷位于"解析外部工具/CLI/Agent 输出并判定成功失败"的判定逻辑时尤其适用。

## 核心 SOP
- 先定位根因再动手：追到判定分支与输入来源，而非加兜底。
- 只改必要文件，补一条能复现原缺陷路径的针对性回归测试。
- git stash 反证回归测试有效性：提交前暂存修复，确认回归测试确实失败；恢复后再确认通过。
- git stash 甄别既有失败：暂存本次改动，在干净代码树上重跑同一测试集，干净树仍失败者即为既有失败。
- 交付前跑全量测试（如 node --test evaluation/tasks/bridge-addr/*.test.mjs），并说明改了什么、为什么。

## 判断逻辑
- "测试通过"不等于"修复有效"：回归测试若从未失败过，可能根本未覆盖缺陷路径，故需先证伪再证实。
- 干净树对比是区分"我引入的失败"与"环境/历史问题"的最低成本手段，避免误改无关代码。
- 解析外部工具结果应兼容大小写并接受负值退出码：当命令静默（如 curl -sSk 无 stderr 输出）时，退出码是区分"超时失败"与"结果不可读"的唯一信号，必须可靠读取。

## 禁忌与反模式
- 只跑修复后测试就宣布完成：无法排除"假绿"。
- 一见失败即归因本次改动：需先在干净树复现以确认来源。
- 为让测试变绿而改动无关文件或删改已有断言：违反行为不变要求。
- 匹配外部输出用大小写敏感正则、且忽略退出码：会漏判静默失败（本次即把超时误记"不可读"）。

## 关键事实依据
- verify.mjs 缺陷根因：CodeBuddy 渲染 Bash 结果用大写"Exit Code: 28"，而 outcomeOfAttempt（约 159 行）用大小写敏感 /(?:^|\n)Exit code:\s*(\d+)/，exitCode 保持 null；asset 文档（consumer-skill-v2.md、v3.md）让模型用 `curl -sSk`，-s 未带 --show-error，超时无 stderr 文字，最终落到 { ok:null, why:"outcome not readable" }。仅恰用 -sS 的超时因带 stderr 文字被识别，故只漏判部分。
- 修复：正则改为 /(?:^|\n)Exit code:\s*(-?\d+)/i（大小写不敏感、允许负数）。
- 回归测试"a timeout whose result carries no stderr prose is still a failure"（verify.test.mjs）覆盖 Stdout/Stderr 均空、带大写"Exit Code: 28"的静默超时，断言 ok=false 且 why 含 "timed out"、作为最后一次尝试时整体判 FAIL 而非 ERROR。
- evaluation 原有 3 个失败在干净树同样复现，由缺少 evaluation/gate0/artifacts/*.jsonl 导致，与本次修复无关。

## 相关任务与资产
- evaluation/tasks/bridge-addr/verify.mjs（验收器）、verify.test.mjs（回归测试）、assets/consumer-skill-v2.md、v3.md。

## 待确认问题
- 既有失败根因（缺 evaluation/gate0/artifacts/*.jsonl）由谁补齐、何时补，是否应纳入测试前置校验以避免重复误判？
