-----META-START-----
created: 2026-09-13T11:10:10.734Z
updated: 2026-09-13T11:10:10.734Z
summary: 沉淀 evaluation 下新增小工具的工作闭环：先检索团队 skill-bridge 经验、参考同类资产、实现明确契约、补测试并全量回归，只改必要文件。
heat: 1
-----META-END-----

## 工作场景
适用于在 evaluation 目录（尤其 evaluation/gate/）下新增小工具类能力的开发任务，也适用于任何"应优先复用团队沉淀经验"的实现类任务。可复用点在于把「检索团队 skill → 参考既有同类资产 → 实现明确契约 → 补测试 → 全量回归 → 说明改动」当作标准闭环。

## 适用条件
- 团队把过往经验以 skill 形式存入团队知识库，且约定动手前须检索一次。
- 新增独立小工具，需要导出契约清晰、可单测的纯函数（如 fetch-resource.mjs）。
- 上游为 HTTP 服务，需可注入桩以便测试不依赖真实网络。
- 交付强调「已有行为不变、只改必要文件」。

## 核心 SOP
- 检索团队经验：POST `/skill-bridge/v3/skill/search`，请求头带 `x-tdai-service-id` 与 `x-conversation-id`；有相关经验就参考，没有则按自己判断执行。
- 取详情：POST `/skill-bridge/v3/skill/get`，请求体带 `skill_id`、`include_content`、`include_manifest`，请求头同上。
- 参考同类资产风格：evaluation/gate/plan-visibility.mjs 及其测试、evaluation/attribution/collect-artifacts.mjs，沿用其实现风格与测试组织方式。
- 实现工具并导出明确契约；为新增工具补一条测试。
- 用 `node --test` 跑 evaluation 下全部 `*.test.mjs`，确认全绿且已有行为不变。
- 交付说明写清改了什么、为什么。

## 接口契约要点（以 fetchResource 为例）
- `export async function fetchResource({ skillId, path, bridgeBase, fetcher })`；成功返回资源原始字节 Buffer，调用方可直接写入文件。
- 资源内容为空返回零字节 Buffer（空文件视为合法文件）。
- 上游返回错误信封（`code !== 0`）时抛出 Error，message 携带信封的 message，不得吞掉。
- `fetcher` 用于注入 HTTP 实现（测试传桩），缺省使用 `globalThis.fetch`。

## 判断逻辑
- 先检索再动手：团队经验优先于个人判断，避免重复造轮子。
- 参考同类资产而非从零设计：保证目录内实现风格与测试组织一致，降低 review 成本。
- fetcher 可注入：把网络依赖收敛为参数，是新增工具可测性的关键设计。
- 全量回归 + 只改必要文件：控制对既有行为的影响面，使改动可验证、可解释。

## 禁忌与反模式
- 跳过 skill 检索直接实现：违背团队约定，可能重复已有方案。
- 吞掉上游错误（返回 null/空或静默）：掩盖失败，必须抛出并保留信封 message。
- 把空文件当错误：空内容应返回零字节 Buffer。
- 改动无关文件或漏补测试：破坏「行为不变、只改必要」的交付要求。
- 测试依赖真实网络：应通过 fetcher 注入桩，保证测试稳定。

## 关键事实依据
- 目标产物：evaluation/gate/fetch-resource.mjs，用于把团队 skill 的资源文件取到本地。
- 验收口径：evaluation 下 `*.test.mjs` 全部通过。

## 相关任务与资产
- 可参考资产：evaluation/gate/plan-visibility.mjs、evaluation/gate/plan-visibility.test.mjs、evaluation/attribution/collect-artifacts.mjs。
- 接口：skill-bridge `/skill-bridge/v3/skill/search`、`/skill-bridge/v3/skill/get`。

## 演化记录
（空）

## 待确认问题
- search 与 get 的配合方式（先搜索定位、再取详情）以团队实际约定为准；两者是否均可独立使用尚未明确。
