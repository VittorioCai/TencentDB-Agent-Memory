-----META-START-----
created: 2026-09-13T11:31:11.128Z
updated: 2026-09-13T11:31:11.128Z
summary: 团队 skill 知识库的检索约定与资源获取工具（fetchResource）的实现规约、接口语义与最小改动交付验证方法。
heat: 1
-----META-END-----

## 工作场景
适用于团队知识库中以 skill 形式沉淀经验时的检索与复用，以及为获取团队 skill 资源文件而开发/扩展工具（如 evaluation/gate/fetch-resource.mjs）的工程任务。可复用到任何"先查团队经验、再按最小改动实现并验证"的开发场景。

## 适用条件
- 团队把过往经验以 skill 形式保存于知识库，成员与 Agent 需先检索再动手。
- 任务落在 evaluation 目录下的工具开发与测试链路。
- 硬约束：不改动已有行为、只改必要文件、现有测试须全通过。

## 核心 SOP
1. 动手前先检索一次团队经验 skill：有相关经验则参考，没有则按自身判断实现——避免重复试错。
2. 通过 skill-bridge 接口获取 skill 内容/资源：POST http://127.0.0.1:8096/skill-bridge/v3/skill/get，body `{ skill_id, include_content, include_manifest }`，header `{ x-tdai-service-id, x-conversation-id }`。
3. 实现 `fetchResource({ skillId, path, bridgeBase, fetcher })`，把资源原始字节取回本地。
4. 为新增工具补一条测试。
5. 运行 `node --test` 跑 evaluation 下 `*.test.mjs`，确认全通过且已有行为不变。
6. 只改必要文件，最后说明改了什么、为什么。

## 判断逻辑
- 先复用团队经验而非从零实现：降低重复试错成本，是团队默认工作方式。
- `fetcher` 以参数注入、缺省 `globalThis.fetch`：便于测试传桩，隔离网络依赖。
- 空资源返回零字节 Buffer 而非报错：空文件是合法文件，语义上要区分"空"与"错误"。
- 上游 `code !== 0` 抛 Error 并带上信封 message：不吞错误，保证调用方可定位上游失败原因。
- 最小改动 + 全量回归：保护既有行为，控制回归风险。

## 禁忌与反模式
- 不检索团队经验就动手：可能重蹈已知错误。
- 吞掉上游错误信封（code !== 0 不抛）：调用方无法感知失败。
- 把空内容当错误处理：破坏合法空资源的语义。
- 改动无关文件或破坏现有测试：违反最小改动与行为不变要求。
- 将 HTTP 实现硬编码为 `globalThis.fetch` 不可注入：测试无法打桩。

## 关键事实依据
- 工具签名：`export async function fetchResource({ skillId, path, bridgeBase, fetcher })`。
- 成功返回资源原始字节 Buffer（调用方可直接写文件）；空内容返回零字节 Buffer；上游 `code !== 0` 抛 Error，message 带信封 message。
- skill-bridge 接口、请求体与请求头字段如上；已知 skill `skl-eM1xP28pXiYA` 对应 `deploy-lookup-note-b`。

## 相关任务与资产
- 待实现：`evaluation/gate/fetch-resource.mjs` 及其对应测试（位于 evaluation/gate/）。
- 验证命令：`node --test` 运行 evaluation 下 `*.test.mjs`。

## 演化记录
- [2026-09-13]：首次沉淀团队 skill 检索约定与 fetchResource 工具规约。

## 待确认问题
- `bridgeBase` 与 skill-bridge 的默认地址（http://127.0.0.1:8096）之间是否为同一约定，缺省值如何取值。
