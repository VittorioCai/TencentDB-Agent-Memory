-----META-START-----
created: 2026-09-13T11:31:43.114Z
updated: 2026-09-13T11:31:43.114Z
summary: evaluation 下新增 Node 工具的开发与交付方法：先检索团队 skill 经验，按信封 code 判失败、按 encoding 解码资源为 Buffer，补测试、最小改动、跑通现有测试并说明改动。
heat: 1
-----META-END-----

## 工作场景
适用于在仓库 evaluation/（尤其 gate/）目录下新增 Node 小工具的开发与交付，以及把团队知识库中的 skill 资源文件（含空文件）取到本地的桥接调用场景。核心可复用点是一套"检索经验 → 遵守接口契约 → 最小改动交付 → 测试验证并说明"的工作方法。

## 适用条件
- 任务落在 evaluation 目录，且要求不破坏现有行为、现有 *.test.mjs 全部通过。
- 团队约定：动手实现前先检索一次团队知识库中已沉淀的 skill 经验。
- 需要经 bridge 读取 skill 资源，且资源可能为空。

## 核心 SOP
- 先检索团队经验：动手前经 skill-bridge 检索一次过往 skill；有相关经验则参考，没有则按自己判断实现。
- 先对齐接口契约：明确入参、返回类型、错误语义、可注入点后再写代码。
- 交付即测试：新增功能必须补对应测试，用 `node --test` 跑 evaluation 下所有 *.test.mjs 且全绿。
- 最小改动：只改必要文件，不外扩。
- 交付说明：写清改了什么、为什么。

## 判断逻辑
- 失败判定只看信封的 code（code !== 0 即失败），与 content 是否为空无关；空资源返回 content: "" 属合法结果。
- 资源解码按信封 data.encoding 决定：base64 表示二进制内容、utf-8 表示文本内容，统一解码为 Buffer 交调用方直接写文件。
- 用 fetcher 参数注入 HTTP 实现（缺省 globalThis.fetch），使测试可传桩。

## 禁忌与反模式
- 不要用 content 真值判断失败：proxy 的 files/download 分支如此做，会把每个空文件误判为失败；同类陷阱见团队 skill `eval-tool-result-exit-line`（解析器误读真实信封）。
- 不要吞掉上游错误：code !== 0 必须抛出 Error，且 message 携带信封的 message。
- 不要把零字节文件当失败——空文件是合法文件，应返回零字节 Buffer。
- 不要改无关文件或为通过测试而修改已有行为。

## 关键事实依据
- fetchResource 契约：`export async function fetchResource({ skillId, path, bridgeBase, fetcher })`；成功返回资源原始字节 Buffer；内容为空返回零字节 Buffer。
- 资源读取协议：POST `<bridgeBase>/files/read`（bridgeBase 形如 http://127.0.0.1:47318/skill-bridge/v3/skill，末尾斜杠需剔除），body JSON `{ skill_id, path }`，响应信封 `{ code, message, data:{ content, encoding } }`。
- skill-bridge 检索接口：v3 search 用 POST /skill-bridge/v3/skill/search；get 用 POST /skill-bridge/v3/skill/get（body 带 skill_id、include_content、include_manifest）；请求头均需 x-tdai-service-id 与 x-conversation-id。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs（按 encoding 解码 content 并返回 Buffer）+ evaluation/gate/fetch-resource.test.mjs（覆盖 base64 二进制解码、空资源与缺失 content 返回零字节 Buffer、code 非 0 抛出带信封 message 的错误、POST skill_id/path 到 files/read；已通过）。
- 参考同类既有资产：evaluation/gate/plan-visibility.mjs 及其测试 evaluation/gate/plan-visibility.test.mjs、evaluation/attribution/collect-artifacts.mjs（体现目录既有实现风格与测试组织方式）。

## 演化记录
- （无）

## 待确认问题
- （无）
