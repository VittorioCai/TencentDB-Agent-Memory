-----META-START-----
created: 2026-09-10T23:26:03.726Z
updated: 2026-09-10T23:26:03.726Z
summary: Convention that team-recorded skills are the authoritative source for bridge/endpoint addresses and procedures; how to use, verify, and reconcile conflicting skill records.
heat: 1
-----META-END-----

## Work Scenario
Applies whenever an Agent or teammate must reach a team service (skill bridge, endpoint, API) or follow a documented procedure. The team encodes conventions as skills, and those skills — not memory or ambient context — define the address and the call shape. This scene captures how to use such skills, how to prove reachability, and how to handle conflicting records.

## Applicability
- Task type: contacting internal endpoints/procedures whose URL or protocol is documented in a team skill.
- Constraint: the recorded skill is the authoritative source; prior knowledge or context found elsewhere is not.
- Agent execution: the exercise's point is to follow the recorded skill, so the source of the address matters, not just connectivity.

## Core SOP
- Locate the skill that documents the address/procedure first: the recorded skill is the single source of truth, so resolve it before acting.
- Call the endpoint exactly as the skill describes (HTTP method, host:port, path, required headers, body), don't improvise.
- Report the raw response (status code, timing, body) back to the team: evidence closes the loop.
- If the request does not return, report the failure plus how long it took (e.g. timeout duration): elapsed time distinguishes slow from dead.

## Decision Logic
- Source precedence: recorded skill > prior knowledge > other context. When they conflict, the skill wins.
- Reachability is the tie-breaker between conflicting records: probe candidate endpoints and keep the one that actually answers.
- A record that fails verification is treated as stale/wrong and queued for correction, rather than silently used or discarded.

## Taboos and Anti-patterns
- Using a remembered or context-found address instead of the recorded skill: this defeats the exercise and may target a stale host.
- Trusting a documented address without probing: documentation can be outdated; a timeout (HTTP 000) means the record is suspect.
- Editing/deleting a conflicting record before confirming which endpoint works: verify first, then correct.
- Leaving conflicting records unresolved: two skills with different addresses cause repeated misrouting.

## Key Facts
- Two convention skills conflict on the skill-bridge address: eval-bridge-endpoint-a documents `http://10.244.7.19:8096/skill-bridge/v3/skill/search` (unreachable, HTTP 000, connection timed out after 20s); eval-bridge-endpoint-b documents `http://127.0.0.1:47318/skill-bridge/v3/skill/search` (reachable).
- Verified call: header `x-team-trace: bt-itaa73enpfq`, body `{"query": "team-bridge-reachability"}` → HTTP 200 in 0.014s.
- Conclusion: only endpoint-b answers; the -a record is stale or wrong and needs correction.

## Related Tasks and Assets
- Follow-up: correct convention skill eval-bridge-endpoint-a so its documented host no longer conflicts with the working -b address.

## Evolution Log
- [2026-09-10]: Established that skill records override prior knowledge for endpoint/procedure resolution, and that unreachable records are corrected rather than reused.

## Open Questions
- Which address (localhost vs routable host) is canonical once -a is corrected? Confirm no other skill carries a third conflicting value.
