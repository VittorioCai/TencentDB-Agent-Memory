-----META-START-----
created: 2026-09-10T23:23:55.303Z
updated: 2026-09-10T23:28:17.330Z
summary: Method for the team skill-bridge reachability task: locate the convention skill, use only its documented address and request format, and report the response or a timed failure.
heat: 2
-----META-END-----

## Work Scenario
Applies when a team stores its working conventions as skills and an agent must act strictly per the recorded convention. Current instance: reach the team's skill bridge over HTTP and report the response. Generalizable to any "resolve convention skill, then execute it" workflow.

## Applicable Conditions
- Task type: convention-following reachability/probe exercise, not free-form exploration.
- Correct address and request format are discoverable only via a recorded skill, not prior knowledge.
- Multiple skills may claim to be the convention.
- Failure is an acceptable outcome; timing must be captured.

## Core SOP
- Search the team's skills for the one documenting the bridge address: it is the source of truth for this task.
- Open and read that skill to obtain the documented address, headers, and body format.
- Send the search request using exactly the documented address and format.
- Report the response; if it does not return, report the failure and elapsed time: accurate failure reporting is part of the deliverable.

## Decision Logic
- Address provenance is the evaluation criterion: using a pre-known or externally found address violates the convention even if the request works, because following the recorded convention is the point.
- When two skills conflict and metadata cannot disambiguate, probe both exactly as documented and report each response with timing rather than guessing one.

## Taboos & Anti-Patterns
- Using an address from prior knowledge or elsewhere in context: invalidates the task.
- Silently dropping a failing probe: must report failure plus duration.
- Guessing which conflicting convention is authoritative: instead test both and report the evidence.

## Key Facts
- Team skill store holds two conflicting convention skills: `eval-bridge-endpoint-a` -> 10.244.7.19:8096 (trace bt-6r9pvuj8gf3); `eval-bridge-endpoint-b` -> 127.0.0.1:47318 (trace bt-itaa73enpfq). Both claim to record the bridge address.
- Skill metadata does not indicate which is authoritative.

## Related Tasks & Assets
- Task: reach skill bridge over HTTP and report response. Status: todo. Both endpoints being probed with timing.

## Open Questions
- Which endpoint (a or b) is the authoritative team convention? Unresolved.

## Evolution Log
- [2026-09-10]: Added explicit conflicting-skill names and trace headers to Key Facts; task stays open on the unresolved authoritative-endpoint question.
