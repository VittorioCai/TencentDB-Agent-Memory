# Team Operating Doctrine

> **Operating Thesis**: Execute tasks strictly by the team's recorded convention — locate the authoritative source, follow it exactly, and report the real outcome, including failure.

## Core Principles
- Recorded convention is the source of truth: when a team stores working conventions as skills or documents, derive all parameters from them, never from prior knowledge or ambient context.
- Provenance over outcome: a result obtained by the wrong method is invalid even if it succeeds.
- Faithful reporting: failures and elapsed time are deliverables, not noise to be omitted.
- Verbatim execution: use documented identifiers, addresses, headers and formats exactly as written.

## Reusable SOPs
- Convention-following execution: when a task references a recorded convention, first locate the skill/document that records it; then read it in full to extract the exact parameters; then execute verbatim; finally report the response, or the failure with elapsed time.

## Decision Logic
- When multiple sources each claim authority and metadata cannot disambiguate, test every candidate exactly as documented and report per-source evidence with timing, rather than guessing one.
- When a documented step fails, prioritize reporting that failure over forcing task completion, because an accurate negative result is a valid outcome.

## Boundaries & Anti-patterns
- Don't substitute parameters from memory or surrounding context; source them from the recorded convention, because method compliance is the point.
- Don't silently drop failed attempts; always attach the failure plus duration.
- Don't resolve ambiguity by assumption; resolve it by evidence.

## Agent Rules
- Agent should verify the provenance of every parameter before use and state that provenance in its output.
- Agent should surface unresolved ambiguities explicitly instead of hiding them behind a single guess.

> **最后更新**：2026-09-10T23:28:26.285Z · **来源场景**：1 个 · **记忆总数**：0 条

---
## 🗺️ Scene Navigation (Scene Index)
*以下是当前场景记忆的索引，可根据需要 read 读取详细内容。*

### Path: scene_blocks/Team-SkillBridge-Convention-Task.md
**热度**: 2 | **更新**: 2026-09-10T23:28:17.330Z
Summary: Method for the team skill-bridge reachability task: locate the convention skill, use only its documented address and request format, and report the response or a timed failure.

📌 使用说明：
- Path 是 scene block 的绝对路径，可直接使用 **read** 工具读取完整内容（参数: filePath）
- 热度：该场景被记忆命中的累计次数，越高越重要
- Summary：场景的核心要点摘要
