-----META-START-----
created: 2026-09-11T18:47:20.121Z
updated: 2026-09-11T18:47:20.121Z
summary: 修复 CodeBuddy 工具结果退出状态解析的通用方法：先检索团队 skill 经验，定位标签大小写不一致根因，用大小写不敏感正则兼容新旧格式，并以回归测试加基线对比验证未引入回归。
heat: 1
-----META-END-----

## 工作场景
适用于从真实工具/Agent 会话 capture 中抽取结构化清单的解析类修复任务，典型载体是 CodeBuddy 归因工具 `evaluation/attribution/collect-artifacts.mjs`。可复用于任何"原始文本里明明有字段、但清单字段恒为 null/默认值"的解析缺陷排查，以及测试套件中已存在无关失败、对回归敏感的修复场景。

## 适用条件
- 仓库所属团队把过往经验以 skill 形式存在团队知识库，成员动手前需先检索一次经验。
- 修复约束常为：已有行为不变、补一条回归测试、只改必要文件、最后说明改动与原因。
- 测试套件可能带有与本次任务无关的既有失败。

## 核心 SOP
- 先检索团队经验：查知识库 skill，有相关经验（如 `eval-tool-result-exit-line`）即参考执行，没有则按自身判断处理。原因：解析类问题多有先例，可显著缩短定位时间。
- 定位根因时对照"真实结果原文 vs 解析器匹配串"，本次即发现大小写不一致（真实为 `Exit Code:`，解析器只匹配 `Exit code:`）。原因：字段恒为 null 通常是匹配条件与真实数据格式不符，而非数据本身缺失。
- 采用最小修复：把匹配退出状态标签的正则改为大小写不敏感（加 `/i`），同时兼容真实大写与旧夹具小写。原因：一次改动既修真实缺陷，又满足"已有行为不变"。
- 补回归测试：新增 `collect-artifacts.test.mjs`，覆盖真实 `Exit Code:`（curl 退出码 28/52/0）、旧小写拼写、缺失状态返回 null，并验证 `collectArtifacts` 会把真实退出状态带回操作结果。
- 运行测试时显式列出文件：`node --test $(find evaluation -name '*.test.mjs')`；目录直传 `node --test evaluation` 表现异常。
- 用基线对比判定回归归属：先 `git stash` 暂存改动跑一遍基线，比较失败数量。
- 收尾按约定说明改了什么、为什么。

## 判断逻辑
- 失败归属用"基线对比"而非直觉：修复前后失败数均为 3（全部为 fixture 缺失 ENOENT），据此判定与本次改动无关，避免把既有失败误判为新引入的回归。
- 兼容性优先于彻底清理：保留对旧小写标签的兼容，是因为"已有行为不变"是硬约束，清理式重写会破坏旧夹具与下游行为契约。

## 禁忌与反模式
- 只按小写标签做精确匹配：真实数据统一使用大写标签，会导致字段恒为 null、下游按退出状态分类失败调用的逻辑静默失效。
- 通过改测试期望或删除既有失败用例来"凑全绿"：会掩盖真实缺陷，且违反"已有行为不变"约束。
- 直接 `node --test evaluation` 直传目录来判断结果：该方式在本仓库表现异常，会给出误导性结论。
- 未跑基线就声称"未引入回归"：无法区分既有失败与新回归。
- 跳过团队经验检索直接动手：违背团队既定工作方式，容易重复踩坑。

## 关键事实依据
- 缺陷位置：`outcomeOf` 函数（约 124 行）。
- 根因结论来源：团队知识库 skill `eval-tool-result-exit-line`（编号 bt-78yk9r3bfrm）。
- evaluation 套件 3 个既有失败均由 fixture 文件缺失（ENOENT）导致，与本次修复无关。

## 相关任务与资产
- 资产：`evaluation/attribution/collect-artifacts.mjs`、`evaluation/attribution/collect-artifacts.test.mjs`。
- 团队知识库 skill：`eval-tool-result-exit-line`（bt-78yk9r3bfrm）。

## 演化记录
- [2026-09-11]：确立"解析类修复先检索团队 skill、再基线对比验证"的方法，来源为 collect-artifacts exit_code 修复实践。

## 待确认问题
- evaluation 下 3 个 fixture 缺失（ENOENT）的既有失败是否长期保留？应补齐 fixture、标记为已知失败，还是修复后纳入门禁？
