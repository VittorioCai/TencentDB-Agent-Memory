-----META-START-----
created: 2026-09-11T19:01:16.206Z
updated: 2026-09-11T19:01:16.206Z
summary: 修复归因工具 collect-artifacts.mjs 读取 CodeBuddy 工具结果退出状态的复用方法：先检索团队经验 skill，再定位正则大小写根因，以大小写不敏感匹配修复并补回归测试。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库所属团队修复归因/评估工具链（如 evaluation/attribution/collect-artifacts.mjs）的数据解析类 bug，尤其是"字段静默为 null、下游分类逻辑失效"的隐性故障；也适用于任何在动手实现或修复前需先检索团队经验的任务。

## 适用条件
- 任务类型：工具脚本 bug 定位与修复、解析字段缺失导致的隐性失效。
- 团队约束：经验以 skill 形式沉淀在团队知识库；交付需通过 `node --test` 且保持既有行为。
- Agent 执行场景：在本仓库先检索团队经验 skill，再决定是否按自身判断执行。

## 核心 SOP
- 先检索团队经验：动手前查团队知识库 skill，命中即参考，未命中再按自身判断处理。
- 定位根因而非打补丁：确认 exit_code 恒为 null 的直接原因——outcomeOf 正则仅匹配小写 `Exit code:`，真实 CodeBuddy 结果用大写 `Exit Code:`。
- 选兼容性修复：改为大小写不敏感匹配，同时兼容新大写与旧版小写信封，而非只放大写拼写。
- 补回归测试：覆盖真实大写拼写、旧版小写拼写、真实退出码 0、无退出行返回 null，并断言真实退出状态被传递到操作清单。
- 验证与说明：只改必要文件，运行 evaluation 下全部 `*.test.mjs` 确认通过，最后说明改了什么、为什么。

## 判断逻辑
- 字段静默变 null 比报错更危险：不抛异常却让下游"按退出状态分类失败调用"静默失效，故修复目标是恢复正确取值而非吞掉问题。
- 大小写不敏感优于单一大写：真实结果与旧信封拼写不一致，兼容两者才能既修 bug 又不破坏既有行为。
- 测试是交付门槛而非附属：先保证全量测试通过，再补本次修复的回归用例，避免修一处坏一处。
- 团队经验检索是前置成本更低的一步：先查再动手，避免重复造轮子或违背团队既有做法。

## 禁忌与反模式
- 只匹配单一大写或小写拼写：会再次漏掉另一种来源，问题复发。
- 改写上游或绕过字段来"消除"null：掩盖根因，下游仍无法分类失败调用。
- 改无关文件或改动既有行为：超出"只改必要文件"约束，增加回归风险。
- 跳过团队经验检索直接实现：可能重复劳动或与团队做法冲突。
- 只改代码不补回归测试、不说明原因：修复无法被验证与复用。

## 关键事实依据
- 根因：collect-artifacts.mjs 约第 124 行 outcomeOf 正则仅匹配小写 `Exit code:`；真实文本为大写（gate0/verify-capture.mjs:136 及多个 fixture 佐证）。
- 团队 skill：eval-tool-result-exit-line（marker bt-78yk9r3bfrm），与"工具结果退出状态解析"直接相关。
- 回归测试文件：evaluation/attribution/collect-artifacts.test.mjs（验证 collectArtifacts 能把真实退出状态传到操作清单）。

## 相关任务与资产
- 任务：修复 collect-artifacts.mjs 退出状态读取；约束：node --test 全绿、行为不变、补一条回归测试、最小改动、说明改动与原因。
- 资产：evaluation/attribution/collect-artifacts.mjs、evaluation/attribution/collect-artifacts.test.mjs、skill eval-tool-result-exit-line。

## 演化记录
- [2026-09-11]：将退出状态匹配从"仅小写 `Exit code:`"调整为"大小写不敏感（/i）"，原因：真实 CodeBuddy 结果使用大写 `Exit Code:`，导致 exit_code 恒为 null。

## 待确认问题
- 除该正则外，工具链中是否还有其他解析入口对真实工具结果大小写或格式敏感、存在类似静默 null 风险？

[PERSONA_UPDATE_REQUEST]
reason: 团队形成稳定共识——"动手实现或修复前先检索团队知识库中以 skill 形式沉淀的过往经验，命中则参考、未命中再自行判断"，属于跨场景复用的团队级执行规则，建议沉淀到 L3 Team Operating Memory。
[/PERSONA_UPDATE_REQUEST]