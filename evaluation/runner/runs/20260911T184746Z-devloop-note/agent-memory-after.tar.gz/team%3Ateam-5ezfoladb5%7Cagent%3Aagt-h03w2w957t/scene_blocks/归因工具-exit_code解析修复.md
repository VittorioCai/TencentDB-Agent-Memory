-----META-START-----
created: 2026-09-11T18:48:26.093Z
updated: 2026-09-11T18:48:26.093Z
summary: 归因工具 collect-artifacts 的 exit_code 解析修复方法与"先查团队经验"的 SOP：动手前检索团队 skill，定位大小写解析根因，按最小改动+回归测试交付。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库 evaluation/attribution 工具链的缺陷修复，以及任何"先检索团队经验再动手"的开发/修复任务。沉淀的是可复用的排障与交付方法链：查团队经验 → 定位根因 → 最小改动 + 回归测试 → 说明改动理由。

## 适用条件
- 任务类型：修复既有工具的解析/归类缺陷，而非从零开发。
- 团队约束：过往经验以 skill 形式存于团队知识库；改动需保证既有行为不变、仅改必要文件。
- Agent 执行场景：动手前先检索一次相关经验，再决定照搬还是自行判断。

## 核心 SOP
- 动手前检索团队经验：有相关 skill 就参考执行，没有则按自己判断推进；本次正是靠 skill `eval-tool-result-exit-line` 快速定位。
- 复现并定位根因：不满足于"读不到退出状态"，追到具体解析位置（collect-artifacts.mjs:124）。
- 按最小改动修复：只改必要文件，避免顺手重构扩大风险面。
- 修复后补一条回归测试，锁定本次缺陷（大写退出状态可被解析）。
- 交付前运行相关测试（node --test 跑 evaluation 下 *.test.mjs）并确认全绿，最后说明改了什么、为什么。

## 判断逻辑
真实 CodeBuddy 工具结果把退出状态拼写为 `Exit Code:`（大写 C），而解析器只匹配小写 `Exit code:`，于是 exit_code 恒为 null，下游按退出状态分类失败调用的逻辑随之失效。取舍标准：优先复用团队已有经验而非重新试错；以"既有测试全过 + 新增回归"作为修复完成的验收口径，而非只看单点现象消失。

## 禁忌与反模式
- 只做固定大小写匹配：大小写敏感匹配易漏真实数据，应改用大小写不敏感匹配（如 /exit code:/i）。
- 修复不补回归测试：同类大小写问题会再次回归。
- 借修复之名大范围重构：违反"只改必要文件"，放大回归风险。
- 跳过团队经验检索直接动手：可能重复踩已被沉淀过的坑。

## 关键事实依据
- 缺陷：evaluation/attribution/collect-artifacts.mjs 将一次会话 capture 整理成操作清单时 exit_code 恒为 null。
- 根因：collect-artifacts.mjs:124 仅匹配小写 `Exit code:`，真实结果为大写 `Exit Code:`。
- 关联团队 skill：`eval-tool-result-exit-line` 已记录该经验。

## 相关任务与资产
- 待办：修复 collect-artifacts.mjs 的 exit_code 解析，补回归测试并跑通 evaluation 下 *.test.mjs。
- 资产：evaluation/attribution/collect-artifacts.mjs；团队 skill `eval-tool-result-exit-line`。

## 演化记录
（暂无）

## 待确认问题
- 除退出状态外，是否还有其他字段存在类似的大小写敏感解析问题？
