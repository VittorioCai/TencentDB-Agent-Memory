-----META-START-----
created: 2026-09-11T18:49:36.204Z
updated: 2026-09-11T19:04:53.174Z
summary: 修复 evaluation 验收器解析外部工具输出的超时误判（大小写正则/静默超时），含根因定位、red check 验证与回归基线约束
heat: 2
-----META-END-----

## 工作场景
适用于修复 evaluation 验收器（如 evaluation/tasks/bridge-addr/verify.mjs）解析外部工具（CodeBuddy/curl）结果时的判定错误。沉淀"定位解析错配→最小修复→补回归→red check 锁定→按正确基线验证"的可复用方法，适用于解析器、正则、状态机类缺陷。

## 适用条件
- 验收器把外部工具输出解析为成功/失败/超时/不可读等状态时误判。
- 要求不改变已有行为、只改必要文件，并补一条回归测试。
- 需区分"本次引入的失败"与"仓库既有失败"。

## 核心 SOP
- 定位：对照解析逻辑与实际输出文本，找出匹配失败点。
- 最小修复：只改必要文件；本次为退出码标签匹配加 /i，使其大小写不敏感。
- 补回归测试：沿用团队 skill 指定的命名与 marker（bt-78yk9r3bfrm）。
- red check：用 git stash 临时回退修复，确认新增测试在未修复版本上失败，再恢复修复。
- 验证：从仓库根执行 node --test 'evaluation/**/*.test.mjs'，确认通过且已有行为不变。
- 收尾：说明改了什么、为什么。

## 判断逻辑
大小写敏感正则在解析外部工具输出时是常见隐患：outcomeOfAttempt 只匹配小写 `Exit code:`，而真实输出为大写 `Exit Code:`。当 curl 静默超时（用 -s 但不带 -S）时无 `curl: (N)` 报错文本，只剩退出码行，匹配失败便落入"outcome not readable"，把本应判 FAIL 的调用误判为 ERROR。故修复方向是让 exit 标签匹配大小写不敏感。
red check 的价值在于证明回归测试确实覆盖并锁定该缺陷，而非"恰好通过"。
回归基线需排除无关既有失败：全量 evaluation 套件存在 3 个既有失败，源于缺少被 gitignore 的 fixtures，与本次无关，不应作为回归判断依据。

## 禁忌与反模式
- 只跑一次通过就认定测试有效：应做 red check 确认未修复时确实失败。
- 用全量套件既有失败判定本次回归：会误报，应先用单测基线校准。
- 在 evaluation 目录内直接跑测试：cwd 不符会失败，必须从仓库根执行。
- 为让测试通过而改无关文件或改变已有行为：违反最小改动约束。
- 修完不补回归测试：同类大小写/静默超时问题会再次回归。

## 关键事实依据
- 根因：outcomeOfAttempt 的 exit 标签匹配区分大小写，漏掉大写 `Exit Code:`。
- 修复：给该正则加 /i。
- 回归测试：evaluation/tasks/bridge-addr/verify.exit-status.bt-78yk9r3bfrm.test.mjs，覆盖四类场景——`Exit Code: 28` 且无 curl 报错应判 timed out；`Exit Code: 52` 应判 exit 52 失败而非不可读；小写 `Exit code:` 仍兼容；静默超时完整流程应给 FAIL 而非 ERROR。
- 基线：改动后 bridge-addr 下 43 个测试全部通过。

## 相关任务与资产
- evaluation/tasks/bridge-addr/verify.mjs；verify.exit-status.bt-78yk9r3bfrm.test.mjs。
- 相关 skill：「eval-tool-result-exit-line」。

## 演化记录
- [2026-09-11]：测试基线由 bridge-addr 39/39 更新为 43 全通过，因新增 4 条回归测试。
- [2026-09-11]：SOP 增加 red check（git stash 回退验证）步骤。

## 待确认问题
（空）
