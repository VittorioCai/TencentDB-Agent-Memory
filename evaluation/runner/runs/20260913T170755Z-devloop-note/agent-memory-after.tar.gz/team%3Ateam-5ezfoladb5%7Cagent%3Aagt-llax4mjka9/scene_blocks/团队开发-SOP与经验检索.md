-----META-START-----
created: 2026-09-13T17:09:39.193Z
updated: 2026-09-13T17:09:39.193Z
summary: 本仓库开发任务的通用工作法：动手前先检索团队 skill 经验、只改必要文件、为新增工具补测试并跑通 evaluation 全部 *.test.mjs，最后说明改动与原因；附 fetchResource 工具的行为契约与下载子路径经验。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库（evaluation 工具链 / skill bridge 相关）的工程任务：新增或修改工具、补测试、修复行为。该工作法可复用到任何"先检索团队经验 → 最小改动 → 跑测试 → 写说明"的开发场景，尤其适合由 Agent 独立执行、需自证交付质量的批量小任务。

## 适用条件
- 团队把过往经验以 skill 形式保存在团队知识库中，可通过检索复用；
- 仓库已有测试，约定用 `node --test` 运行 evaluation 下所有 `*.test.mjs`；
- 约束是保持既有行为不变，风险落在"改动扩散"和"漏测"上。

## 核心 SOP
- 动手前先检索一次团队经验：有相关 skill 就参考，没有则按自身判断实现——避免重复踩坑，也避免无经验时卡住。
- 只改必要的文件：改动面越小，回归风险越低，评审成本越低。
- 为新增工具补一条测试：新能力必须自带可验证证据，不能只靠口头说明。
- 改完运行相关测试（`node --test` 跑 evaluation 下 `*.test.mjs`），确认全部通过且既有行为不变。
- 最后说明改了什么、为什么：交付必须自带动机与影响说明，便于复盘与交接。

## 判断逻辑
交付验收口径 = 现有测试全过 + 新工具有测试 + 改动面最小 + 有改动说明。团队优先用"既有测试通过"作为行为不变的客观证据，用"新增工具补一条测试"保证新能力可回归；检索团队 skill 在实现之前进行，因为经验复用成本远低于试错成本。

## 禁忌与反模式
- 下载 skill 资源不要走 `files/read`：它总返回 JSON 信封，直接存盘会得到 JSON 而非目标脚本，`curl -o` 也改不了，因为 bridge 按子路径分发；应使用下载子路径 `skill-bridge/v3/skill/files/download`。
- 不要把空内容当错误：空文件是合法文件，应返回零字节 `Buffer`。
- 不要吞掉错误信封：上游 `code !== 0` 时必须抛出 `Error` 并在 message 中携带信封的 message。
- 不要为图省事扩大改动范围或跳过测试。

## 关键事实依据
- `fetchResource({ skillId, path, bridgeBase, fetcher })` 契约：成功返回资源原始字节 `Buffer`（供调用方直接写文件）；空内容返回零字节 `Buffer`；`code !== 0` 抛出携带信封 message 的 `Error`；`fetcher` 用于注入 HTTP 实现（测试传桩），缺省 `globalThis.fetch`。
- 实现要点（fetch-resource.mjs）：响应体按字节读取一次后处理——`code !== 0` 抛错，`code === 0` 解码 `data.content`（允许为空），非信封则直接返回原始下载字节；导出常量 `DOWNLOAD_SUBPATH = "skill-bridge/v3/skill/files/download"`。
- 已知缺陷：Core 的 `skillResourcePayloadSchema` 中 `content` 保持 `z.string()`（未加 `.min(1)`），但 proxy 的 download 分支用 `!parsed.data?.content` 判断，导致空文件返回整个信封而非 0 字节，调用方需按 `code === 0` 的信封处理空内容。
- 参考经验 skill：`eval-skill-resource-download`（skl-XAzqAgejM7O4）、`eval-bridge-endpoint-b`（skl-oBaDO5CceKnr）。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`：新增工具，导出 `fetchResource`，并补一条测试。

## 演化记录
（无）

## 待确认问题
- proxy download 分支对空内容的判断（`!content` vs schema）是否应统一修复，还是由调用方兜底？
