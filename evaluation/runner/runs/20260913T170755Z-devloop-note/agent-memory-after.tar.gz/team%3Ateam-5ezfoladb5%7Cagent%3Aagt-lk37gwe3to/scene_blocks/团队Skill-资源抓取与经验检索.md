-----META-START-----
created: 2026-09-13T17:08:35.535Z
updated: 2026-09-13T17:08:35.535Z
summary: 沉淀团队 skill 资源本地化抓取的 SOP 与判断逻辑：先检索团队经验、按信封协议解码、区分空资源与上游错误，并配套可注入 fetcher 的测试策略。
heat: 1
-----META-END-----

## 工作场景
适用于对接团队知识库 / skill bridge、把远端 skill 资源取回本地并还原为原始字节的工具开发与实现评审。核心可复用点是：动手前先检索团队经验、按接口信封协议解码、把"空资源"和"上游失败"明确区分，以及用可注入依赖的方式写测试。

## 适用条件
- 团队把经验以 skill 形式存于知识库，任务涉及消费或实现这类资源接口时。
- 上游接口以 JSON 信封返回，可能带错误码，且成功/失败/空结果三种情况需要不同处理。
- 需要新增或维护会被复用的抓取工具，要求最小改动（只改必要文件）。

## 核心 SOP
- 动手前先检索一次团队经验：有相关 skill 就参考，没有才按自己判断做；避免重复造轮子、绕过既有约定。
- 明确接口契约后再实现：读取 files/read 返回的 `{ code, message, data }`，按 `data.encoding`（base64 / utf-8）解码 `data.content` 还原原始字节。
- 工具签名需支持依赖注入：`fetchResource({ skillId, path, bridgeBase, fetcher })`，`fetcher` 缺省用 `globalThis.fetch`，便于测试替换 HTTP 实现。
- 分支处理三态：成功返回原始字节 Buffer；空资源返回零字节 Buffer；`code !== 0` 抛出携带信封 message 的 Error。
- 配套测试：覆盖字节返回、utf-8/base64 解码、bridgeBase 尾斜杠处理、空资源零字节、缺失 content 仍为零字节、错误信封抛出、纯信封桩 fetcher。
- 改动范围克制：只改必要文件，减少对调用方的连带影响。

## 判断逻辑
优先检索经验是因为团队约定以 skill 承载方法论，先例优先于个人判断，能保证一致性并降低返工。选择依赖注入而非直接调用 fetch，是为了让网络边界可被桩替换，测试不依赖真实上游。把空资源视为合法文件而非错误，是因为文件存在但内容为空是正常状态；把 `code !== 0` 视为必须抛出，是因为错误信息（如 SKILL_NOT_FOUND）在信封 message 中，吞掉会丢失可诊断性。

## 禁忌与反模式
- 不检索团队经验就直接实现：易与既有约定冲突。
- 把空资源当错误，或回退为返回整个 data 信封：空内容是合法零字节文件，回退信封会误导调用方。
- 吞掉错误信封或转成空字节：会掩盖上游失败，破坏可诊断性。
- 硬编码 HTTP 实现而不留注入点：测试将被迫打真实网络。

## 关键事实依据
- 信封结构：`{ code, message, data: { path, content, encoding, size_bytes, mime_type, version } }`，`content` 按 `encoding` 编码，`code !== 0` 为上游失败（如 SKILL_NOT_FOUND）。
- 交付资产：`evaluation/gate/fetch-resource.mjs` 及 `evaluation/gate/fetch-resource.test.mjs`。

## 相关任务与资产
- 资产：`evaluation/gate/fetch-resource.mjs`、`evaluation/gate/fetch-resource.test.mjs`。

## 演化记录
（空）

## 待确认问题
- 空资源的具体判定口径（content 为空字符串 vs 字段缺失）在更多上游实现下是否一致，尚需验证。
