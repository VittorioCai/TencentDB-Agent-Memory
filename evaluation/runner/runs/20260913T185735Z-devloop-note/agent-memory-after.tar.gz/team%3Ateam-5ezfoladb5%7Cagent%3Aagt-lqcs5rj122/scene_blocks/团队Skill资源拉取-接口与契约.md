-----META-START-----
created: 2026-09-13T18:58:08.215Z
updated: 2026-09-13T18:58:08.215Z
summary: 从团队知识库 skill bridge 拉取 skill 资源文件的复用方法：选对 files 子路径、处理空 content 与错误信封、以 Buffer 契约注入 fetcher。
heat: 1
-----META-END-----

## 工作场景
适用于从团队知识库（skill bridge）把某个 skill 的资源文件取回本地的任务，包括实现/维护 `fetchResource` 这类工具、以及排查资源下载相关故障。沉淀的是 skill bridge 资源接口的调用约定、响应结构差异与行为契约，可复用于任何"下载 skill 资源字节"的场景。

## 适用条件
- 需要通过 skill bridge 的 files 接口读取 skill 资源文件。
- 资源可能为空、上游可能返回错误信封，需要明确成败判定口径。
- Agent 或成员在实现资源拉取工具或排查下载问题时（实现入口为 `MemoryProxy/src/skill/skill-bridge.ts`）。

## 核心 SOP
- 选对子路径：取资源字节必须用 `files/download`（会解码上游返回原始字节）；不要用 `files/read`（总返回 JSON 信封，用 curl -o 保存得到信封结构而非资源本身）。二者不可互换。
- 归一化 `bridgeBase` 尾斜杠，避免拼接出重复斜杠。
- 解码成功信封：`content` 按 base64/utf-8 解码为 Buffer；空 `content` 的信封按普通信封解码并产出零字节 Buffer。
- 错误信封（`code !== 0`）抛 Error 并携带信封 message，不吞错。
- HTTP 实现经 `fetcher` 注入（测试传桩），缺省回退 `globalThis.fetch`。

## 判断逻辑
- 子路径取舍以"返回信封还是原始字节"为准，目标是拿到可直接落盘的字节。
- 空资源是合法文件：skill bridge 把空 content 视为下载失败（判断 `!parsed.data?.content`，空串为假值），真正空资源会以 `{code:0,data:{content:""}}` 信封返回而非零字节；工具需解码该信封并产出零字节 Buffer，维持"成功返回 Buffer"的一致契约。
- 仅凭 HTTP 状态判成败会误判：HTTP 200 也可能携带非零 code，仍需按错误信封处理。

## 禁忌与反模式
- 用 `files/read` 取资源字节：会得到 JSON 信封，落盘文件错误。
- 把空 content 当失败：空资源合法，应返回零字节 Buffer。
- 只看 HTTP 状态码：200 携带非零 code 也应抛错。
- 吞掉错误信封或丢弃 message：上层无法感知失败。

## 关键事实依据
- 实现：`evaluation/gate/fetch-resource.mjs`，导出 `fetchResource({ skillId, path, bridgeBase, fetcher })`，内含 `readBytes`（响应转 Buffer）与 `decodeContent`（按 base64/utf-8 解码 `data.content`），支持错误信封抛出、缺省 `globalThis.fetch`、`bridgeBase` 尾斜杠归一化；请求以 POST 提交 `skill_id`/`path` 到 `files/download`。
- 测试：`evaluation/gate/fetch-resource.test.mjs`，覆盖原始字节返回、尾斜杠不重复拼接、空资源零字节 Buffer、空原始响应体为零字节、base64 信封解码、错误信封抛出带 message、HTTP 200 非零 code 视为错误、未注入 fetcher 时缺省 `globalThis.fetch`。
- 参考经验：团队知识库 skill `eval-skill-resource-download`（skill_id `skl-XAzqAgejM7O4`，trace `bt-pu6nyfhmu2v`），实现与测试均声明遵循该经验。

## 相关任务与资产
- 资产：`evaluation/gate/fetch-resource.mjs`、`evaluation/gate/fetch-resource.test.mjs`。
- 参考 skill：`eval-skill-resource-download`。

## 演化记录
- [2026-09-13]：资源拉取从"待实现"推进到"已实现并配套测试"，契约细节（空 content 信封、`files/read` 与 `files/download` 差异）沉淀固化。

## 待确认问题
- `bridgeBase` 的取值来源与默认约定仍待补充。
