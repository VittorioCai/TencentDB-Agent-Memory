-----META-START-----
created: 2026-09-13T18:57:34.346Z
updated: 2026-09-13T18:57:34.346Z
summary: 通过 skill-bridge 拉取团队 skill 资源文件的可复用方法：用 files/download 取原始字节、空资源解码为零字节、错误信封抛错，并以可注入 fetcher 封装 helper 便于测试。
heat: 1
-----META-END-----

## 工作场景
面向 evaluation/gate 等工具链中"把团队 skill 的资源文件取到本地"的工作。当 Agent 或工程需要按 skillId + path 从 skill-bridge 下载 skill 资源（脚本、模板、笔记等）并落盘或校验时复用本方法，避免直接把 HTTP 响应体写文件而存错内容。

## 适用条件
- 资源来源是 skill-bridge，需要本地 Buffer 后写文件或做校验。
- 资源可能是空文件（合法），需区分"空"与"错误"。
- 需要单元测试，不能依赖真实网络。

## 核心 SOP
- 走 `files/download` 子路径取资源：它返回解码后的原始字节，可直接写文件；`files/read` 会把 payload 包进 JSON 信封，保存响应体会存成信封而非资源。
- 空资源处理：`files/download` 对合法空资源返回 content 为空字符串的信封，应解码为零字节 Buffer；只有 content 缺失或非字符串才视为错误。
- 错误判断：上游错误信封 `code !== 0` 时抛出 Error 并携带信封 message，便于定位。
- 测试可注入性：`fetchResource({ skillId, path, bridgeBase, fetcher })` 中 fetcher 注入 HTTP 实现（测试传桩），缺省用 `globalThis.fetch`。
- 交付前跑 evaluation 下全部 `*.test.mjs`（node --test），不改变已有行为，只改必要文件。

## 判断逻辑
资源拉取被封装成 helper（而非一行 fetch），根因来自 skill 笔记 eval-skill-resource-download（trace bt-pu6nyfhmu2v）踩过的坑：`files/read` 的 JSON 信封会污染落盘内容，空资源又容易被误判为失败。因此按"原始字节 + 空资源合法 + 错误信封显式抛错"建模，并用 fetcher 注入把网络依赖隔离到测试之外，使行为可回归。

## 禁忌与反模式
- 用 `files/read` 取资源并直接保存响应体：会把 JSON 信封写成文件，内容不可用。
- 把空 content 当错误：空文件是合法资源，会误伤正常场景。
- 实现里硬编码 `globalThis.fetch` 而不留注入点：测试只能走真实网络。
- 为接入新工具而改动 evaluation 下已有测试行为：应保证现有测试全绿。

## 关键事实依据
- 新工具 evaluation/gate/fetch-resource.mjs 导出 `fetchResource({ skillId, path, bridgeBase, fetcher })`。
- 契约：成功返回资源原始字节 Buffer，空资源返回零字节 Buffer，`code !== 0` 抛 Error 携 message。
- 来源经验：团队 skill 笔记 eval-skill-resource-download（trace bt-pu6nyfhmu2v）。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs（实现）、evaluation/gate/fetch-resource.test.mjs（覆盖原始字节返回、空资源零字节、错误信封抛错、base64 解码、fetcher 缺省为 globalThis.fetch）。
- 验收：evaluation 下 `*.test.mjs` 全部通过（node --test）。

## 演化记录
（无）

## 待确认问题
- `files/download` 返回的编码字段名与 base64 解码口径，是否在多版本 skill-bridge 上保持一致？
