-----META-START-----
created: 2026-09-13T18:44:30.497Z
updated: 2026-09-13T18:59:43.683Z
summary: 团队以 skill 形式沉淀经验，动手前须经 skill-bridge v3 检索；沉淀 fetchResource 资源拉取工具的接口契约，以及「补测试+全量回归+只改必要文件」的交付验收口径。
heat: 2
-----META-END-----

## 工作场景
适用于「团队用 skill 沉淀经验」的知识库工作场景，覆盖两件可复用的事：任务开工前的经验检索，以及通过 skill-bridge 拉取团队 skill 资源的工具开发与验收。适合本仓库所属团队及后续同类工具（bridge / skill 资源）任务复用。

## 适用条件
- 团队既定约定：动手实现前先检索团队知识库。
- 在 `evaluation/gate/` 下新增或维护工具时。
- 依赖 skill-bridge v3 HTTP 接口（如本地 `http://127.0.0.1:8096`）。

## 核心 SOP
- 先检索再动手：POST `http://127.0.0.1:8096/skill-bridge/v3/skill/search`，头带 `x-tdai-service-id`、`x-conversation-id`，body 的 `query` 为检索词；有相关经验则参考，无则自行判断。
- 拉取资源用 `fetchResource({ skillId, path, bridgeBase, fetcher })`，导出为 `evaluation/gate/fetch-resource.mjs`。
- 交付前自检：补测试 → 跑 `node --test` 让 evaluation 下全部 `*.test.mjs` 通过 → 确认无回归 → 只改必要文件 → 汇报「改了什么、为什么」。

## 判断逻辑
- 先检索后动手：避免重复造轮子并对齐既有实现；无匹配才自行决策，保留效率。
- 返回原始字节 `Buffer` 而非字符串：调用方可直接写文件，避免编码/二进制损坏。
- `fetcher` 注入 HTTP 实现：测试传桩隔离网络，缺省 `globalThis.fetch` 保持生产可用。
- 错误必须冒泡：抛 `Error` 并携带上游信封 `message`，便于定位而非静默失败。
- 验收看整体口径：以全量用例「0 失败、跳过项不计失败」判定无回归，而非只看新用例。

## 禁忌与反模式
- 不要吞错误：`code !== 0` 必须抛 `Error` 且 `message` 带上信封 `message`。
- 不要把空内容当失败：资源为空返回零字节 `Buffer`，空文件是合法文件。
- 不要硬编码 HTTP 调用：必须经 `fetcher` 注入。
- 不要跳过经验检索直接开工。
- 不要破坏现有用例或改动非必要文件；新增工具必须自带测试。

## 关键事实依据
- 参考 skill：`eval-skill-resource-download`（`skl-XAzqAgejM7O4`）；相关 skill：`eval-bridge-endpoint-b`（`skl-oBaDO5CceKnr`）。
- 交付验证：新增 `fetch-resource.mjs` 后跑 evaluation 全部测试 645 项，643 通过、0 失败、2 跳过，新增约 6 个用例已含在内，无回归。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`：已交付并通过全量测试（含新增测试用例）。

## 演化记录
- [2026-09-13]：`fetch-resource.mjs` 从「待实现」转为「已交付并验证」，验收口径明确为「全量 645 项 0 失败、2 跳过视为通过」。

## 待确认问题
- `fetchResource` 的导出/行为是否需与 `eval-skill-resource-download` 完全一致，还是允许按本工具契约演进？
