-----META-START-----
created: 2026-09-13T18:59:28.067Z
updated: 2026-09-13T18:59:28.067Z
summary: 沉淀团队 Skill 资源拉取工具 fetchResource 的接口契约设计、依赖注入测试与最小化交付纪律，及动手前检索团队经验、命名引用追踪值等可复用工作方法。
heat: 1
-----META-END-----

## 工作场景
适用于在仓库 evaluation/gate 下新增或维护与团队 skill 资源交互的工具函数（如 fetchResource），也适用于任何"取回远端资源到本地并配套测试"的交付任务。核心可复用点是接口契约设计、依赖注入式测试、以及最小化改动交付纪律。

## 适用条件
- 团队把过往经验以 skill 形式沉淀在知识库中，开发前可检索。
- 新增工具需融入既有测试套件（node --test 运行 evaluation 下 *.test.mjs）且不产生回归。
- 调用方会直接把返回字节写入文件，且资源内容可能为空。

## 核心 SOP
- 动手前先检索团队经验：有相关 skill 就参考执行，没有则按自身判断实施，避免重复踩坑。
- 固定接口签名 fetchResource({ skillId, path, bridgeBase, fetcher })，只暴露必要参数。
- 契约优先：先明确"成功/空/错误"三种返回语义，再写实现。
- 依赖注入隔离 HTTP：fetcher 参数供测试传桩，缺省用 globalThis.fetch。
- 新增工具必须补一条对应测试。
- 改完运行 evaluation 下 node --test，确认现有 *.test.mjs 全通过、已有行为不变。
- 收尾说明改了什么、为什么这样改。

## 判断逻辑
- 成功返回原始字节 Buffer，调用方可直接写文件，免去二次编解码。
- 资源为空返回零字节 Buffer：空文件是合法文件，不能当错误处理。
- 上游错误信封（code !== 0）抛 Error 并透传信封 message：错误必须外显，否则调用方会把失败当成功。
- 用参数注入 fetcher 而非硬编码 fetch：为可测试性预留接缝，是团队对新增工具的通用要求。

## 禁忌与反模式
- 吞掉上游错误信封：导致静默失败；替代做法是抛 Error 且 message 透传信封内容。
- 把空资源当错误或返回 undefined：空文件合法，应返回零字节 Buffer。
- 硬编码 globalThis.fetch：无法注入桩；应通过 fetcher 参数缺省注入。
- 顺手改动无关文件：违反"只改必要文件"约束，扩大回归面。
- 破坏既有行为或跳过测试：验收要求现有测试全部通过。

## 关键事实依据
- 目标产物：evaluation/gate/fetch-resource.mjs（导出 async function fetchResource）。
- 验收口径：evaluation 下 node --test 的现有 *.test.mjs 全通过、行为不变，且新增工具补一条测试。
- 从 evaluation/delivery 报告推断：追踪值（tracking token，如 bt- 前缀）会被引用在测试文件名中，可作为本次测试文件命名参考。

## 相关任务与资产
- 任务：新增 fetch-resource.mjs 并补一条测试。
- 资产：evaluation/gate/fetch-resource.mjs、evaluation/delivery 报告。

## 演化记录
（暂无）

## 待确认问题
- "追踪值引用在测试文件名中"是否为稳定团队约定、其适用范围与格式规范需团队确认。
