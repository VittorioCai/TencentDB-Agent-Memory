/**
 * One test per reading that would otherwise be scored wrong. Five of them
 * are the cases review found in the first draft of this module; they are
 * kept as tests rather than as notes because each was a real defect.
 */
import test from "node:test";
import assert from "node:assert/strict";
import { auditDelivery, allMessages, pathsModelWroteTokenInto, operationFromTargetRef, attributionFromCapture, verifyCoverage, assetOwningTokenInResult, jsonCandidates, verifyTokensDiscriminative, containsToken } from "./delivery-audit.mjs";

const req = (messages, requestId) => ({ requestId, body: { json: { messages } } });
const TOKENS = { "skl-hidden": { version: 2, tokens: ["10.244.7.19"] }, "skl-ok": { version: 2, tokens: ["47318"] } };
/** The collector's answer: what this content actually came from. */
const fromAsset = (idx, assetId) => (pos) => (pos.index === idx ? { asset_id: assetId } : null);

test("a bypass read is caught: the channel does not matter, the content and its attribution do", () => {
  const a = auditDelivery([req([
    { role: "system", content: "you are an agent" },
    { role: "user", content: "reach the bridge" },
    { role: "assistant", content: "reading it" },
    { role: "tool", content: "  1→address 10.244.7.19:8096" },
    { role: "assistant", content: "now probing" },
  ])], TOKENS, { operation: { request: 0, index: 4 }, attributionOf: fromAsset(3, "skl-hidden"), coverageAsserted: true });
  assert.equal(a.assets["skl-hidden"].verdict, "delivered");
  assert.equal(a.assets["skl-ok"].verdict, "not_delivered");
});

test("a token only ever in the model's own messages is not a delivery", () => {
  const a = auditDelivery([req([
    { role: "system", content: "you are an agent" },
    { role: "assistant", content: "from memory, 10.244.7.19:8096" },
  ])], TOKENS, { operation: { request: 0, index: 1 }, attributionOf: () => null, coverageAsserted: true });
  assert.equal(a.assets["skl-hidden"].verdict, "model_authored");
});

test("content that arrives after the operation does not explain it", () => {
  const a = auditDelivery([req([
    { role: "system", content: "you are an agent" },
    { role: "assistant", content: "probing" },
    { role: "tool", content: "probe done" },
    { role: "tool", content: "  1→notes mention 10.244.7.19:8096" },
  ])], TOKENS, { operation: { request: 0, index: 2 }, attributionOf: fromAsset(3, "skl-hidden"), coverageAsserted: true });
  const f = a.assets["skl-hidden"];
  assert.equal(f.verdict, "after_operation");
  assert.match(f.findings[0].why, /later content cannot explain/);
});

test("content that came from a known non-asset source did reach the model", () => {
  // Not "this asset leaked" and not "we cannot tell": the content arrived,
  // by a route that is identified. Whether that is an isolation failure is
  // for the calibration to decide from whether the asset was hidden.
  const a = auditDelivery([req([
    { role: "system", content: "you are an agent" },
    { role: "tool", content: "  1→10.244.7.19:8096 documented here" },
    { role: "assistant", content: "probing" },
  ])], TOKENS, { operation: { request: 0, index: 2 }, coverageAsserted: true,
    attributionOf: () => ({ asset_id: null, path: "/home/agent/memory/persona.md" }) });
  assert.equal(a.assets["skl-hidden"].verdict, "delivered_from_other_source");
  assert.match(a.assets["skl-hidden"].findings[0].why, /persona\.md/);
});

test("an empty capture is not seen, never clean; asserted coverage is what upgrades it", () => {
  assert.equal(auditDelivery([], TOKENS, {}).assets["skl-hidden"].verdict, "not_seen_in_capture");
  assert.equal(auditDelivery([], TOKENS, { coverageAsserted: true }).assets["skl-hidden"].verdict, "not_delivered");
});

test("no resolved operation position means the ordering is unknown, not favourable", () => {
  const a = auditDelivery([req([
    { role: "system", content: "you are an agent" },
    { role: "tool", content: "10.244.7.19:8096" },
  ])], TOKENS, { attributionOf: fromAsset(1, "skl-hidden"), coverageAsserted: true });
  assert.equal(a.assets["skl-hidden"].verdict, "delivered_order_unknown");
});

// ── the five review found in the first draft ──

test("REPRO 1a: a token written through a tool ARGUMENT, then read back, is an echo", () => {
  // A content-only scan never saw the Write argument, so the read-back was
  // the first "input" appearance and came out as a delivery.
  const a = auditDelivery([req([
    { role: "system", content: "you are an agent" },
    { role: "assistant", content: null, tool_calls: [{ id: "c1", function: { name: "Write", arguments: JSON.stringify({ file_path: "/tmp/n.md", content: "address 10.244.7.19:8096" }) } }] },
    { role: "tool", tool_call_id: "c1", content: "wrote /tmp/n.md" },
    { role: "assistant", content: null, tool_calls: [{ id: "c2", function: { name: "Read", arguments: JSON.stringify({ file_path: "/tmp/n.md" }) } }] },
    { role: "tool", tool_call_id: "c2", content: "  1→address 10.244.7.19:8096" },
    { role: "assistant", content: "probing" },
  ])], TOKENS, { operation: { request: 0, index: 5 }, coverageAsserted: true,
    attributionOf: (pos) => (pos.index === 4 ? { asset_id: null, path: "/tmp/n.md" } : null) });
  assert.equal(a.assets["skl-hidden"].verdict, "model_echo");
  assert.match(a.assets["skl-hidden"].findings[0].why, /\/tmp\/n\.md/);
});

test("REPRO 1b: guessing a token earlier does not make a later genuine read an echo", () => {
  // Order is not an echo relation. The model mentioned the address from
  // memory and then actually read the asset; that read IS a delivery.
  const a = auditDelivery([req([
    { role: "system", content: "you are an agent" },
    { role: "assistant", content: "I think it is 10.244.7.19:8096, let me check the skill" },
    { role: "assistant", content: null, tool_calls: [{ id: "c1", function: { name: "Bash", arguments: JSON.stringify({ command: "curl .../skill/get" }) } }] },
    { role: "tool", tool_call_id: "c1", content: "{\"content\":\"reach it at 10.244.7.19:8096\"}" },
    { role: "assistant", content: "probing" },
  ])], TOKENS, { operation: { request: 0, index: 4 }, attributionOf: fromAsset(3, "skl-hidden"), coverageAsserted: true });
  assert.equal(a.assets["skl-hidden"].verdict, "delivered");
});

test("REPRO 2: every request is scanned — the longest one is not the whole history", () => {
  // Turn one carried the token in a system prompt that turn two replaced.
  const turn1 = req([
    { role: "system", content: "context: the address is 10.244.7.19:8096" },
    { role: "user", content: "go" },
  ], "r1");
  const turn2 = req([
    { role: "system", content: "context: (trimmed)" },
    { role: "user", content: "go" },
    { role: "assistant", content: "working" },
    { role: "tool", content: "done" },
  ], "r2");
  const a = auditDelivery([turn1, turn2], TOKENS, { operation: { request: 1, index: 3 }, coverageAsserted: true,
    attributionOf: (pos) => (pos.request === 0 && pos.index === 0 ? { asset_id: "skl-hidden" } : null) });
  assert.equal(a.assets["skl-hidden"].verdict, "delivered");
  assert.equal(a.messages_scanned, 6);
  assert.equal(a.requests_scanned, 2);
});

test("REPRO 3a: with nothing recorded about the source, a hit is not a delivery", () => {
  const a = auditDelivery([req([
    { role: "system", content: "you are an agent" },
    { role: "tool", content: "10.244.7.19:8096" },
    { role: "assistant", content: "probing" },
  ])], TOKENS, { operation: { request: 0, index: 2 }, coverageAsserted: true });
  assert.equal(a.assets["skl-hidden"].verdict, "source_unknown");
});

test("REPRO 3b: naming an asset in a command is not fetching it", () => {
  // `grep skl-hidden /tmp/other-memory` mentions the id and reads something
  // else. Attribution comes from the collector, not from substrings — so
  // this is a delivery from a known other source, never a delivery of the
  // asset whose id the command happens to contain.
  const a = auditDelivery([req([
    { role: "system", content: "you are an agent" },
    { role: "tool", content: "10.244.7.19:8096 found" },
    { role: "assistant", content: "probing" },
  ])], TOKENS, { operation: { request: 0, index: 2 }, coverageAsserted: true,
    attributionOf: () => ({ asset_id: null, command: "grep skl-hidden /tmp/other-memory" }) });
  assert.equal(a.assets["skl-hidden"].verdict, "delivered_from_other_source");
  assert.notEqual(a.assets["skl-hidden"].verdict, "delivered");
});

test("helpers: messages carry their position; written paths are collected from arguments", () => {
  const msgs = [{ role: "system", content: "a" }, { role: "assistant", content: "tok" }];
  assert.equal(allMessages([req(msgs), req(msgs)]).length, 4);
  const entries = allMessages([req([
    { role: "assistant", content: null, tool_calls: [{ function: { name: "Write", arguments: JSON.stringify({ file_path: "/tmp/a.md", content: "tok here" }) } }] },
    { role: "assistant", content: null, tool_calls: [{ function: { name: "Bash", arguments: JSON.stringify({ command: "echo tok > /tmp/b.md" }) } }] },
  ])]);
  const paths = pathsModelWroteTokenInto(entries, "tok");
  assert.ok(paths.has("/tmp/a.md"));
  assert.ok(paths.has("/tmp/b.md"));
});

test("the operation's position comes from the used-event's target_ref", () => {
  const requests = [req([], "aaa"), req([], "b7dcd066")];
  const op = operationFromTargetRef("request(b7dcd066):msg[17]:call_00_x:arguments", requests);
  assert.deepEqual({ request: op.request, index: op.index, resolved: op.resolved_request }, { request: 1, index: 17, resolved: true });
  assert.equal(operationFromTargetRef("nonsense", requests), null);
});

test("attribution is the response's own binding, not the command text", () => {
  // The command may ask by name, or be a search returning several hits; only
  // the response says which asset the content came from. And a command that
  // merely mentions an id (`grep skl-hidden …`) returns content that names
  // no asset at all.
  const requests = [req([
    { role: "assistant", content: null, tool_calls: [{ id: "c1", function: { name: "Bash", arguments: JSON.stringify({ command: "curl .../skill/get-by-name -d '{\"skill_name\":\"endpoint-a\"}'" }) } }] },
    { role: "tool", tool_call_id: "c1", content: '{"data":{"skill_id":"skl-hidden","content":"reach it at 10.244.7.19:8096"}}' },
    { role: "assistant", content: null, tool_calls: [{ id: "c2", function: { name: "Bash", arguments: JSON.stringify({ command: "grep skl-hidden /tmp/other-memory" }) } }] },
    { role: "tool", tool_call_id: "c2", content: "10.244.7.19:8096" },
  ])];
  const attributionOf = attributionFromCapture(requests);
  const entries = allMessages(requests);
  // Asked by NAME, and still attributed — because the response carries the id.
  assert.equal(attributionOf({ request: 0, index: 1 }, entries[1], "10.244.7.19").asset_id, "skl-hidden");
  // The grep's output names no asset, so it attributes to none.
  assert.equal(attributionOf({ request: 0, index: 3 }, entries[3], "10.244.7.19").asset_id, null);
});

test("in a search result, the token belongs to the hit it sits inside", () => {
  const body = '{"items":[{"skill_id":"skl-ok","snippet":"port 47318 here"},{"skill_id":"skl-hidden","snippet":"10.244.7.19:8096 here"}]}';
  assert.equal(assetOwningTokenInResult(body, "47318"), "skl-ok");
  assert.equal(assetOwningTokenInResult(body, "10.244.7.19"), "skl-hidden");
  assert.equal(assetOwningTokenInResult("no ids here, just 10.244.7.19", "10.244.7.19"), null);
});

// ── coverage: absence is only evidence if the capture is the whole run ──

const turn = (id, finish, opts = {}) => [
  { event: "http.request", requestId: id, body: { json: { messages: [] } } },
  { event: "http.response", requestId: id, status: opts.status ?? 200,
    body: { truncated: opts.truncated ?? false, text: `data: {"choices":[{"finish_reason":"${finish}"}]}` } },
];

test("a run that asked for tools each turn and then stopped is complete", () => {
  const c = verifyCoverage([...turn("a", "tool_calls"), ...turn("b", "tool_calls"), ...turn("c", "stop")]);
  assert.equal(c.complete, true);
  assert.deepEqual(c.reasons, []);
  assert.equal(c.requests, 3);
});

test("a capture that stops while the model is still calling tools is not complete", () => {
  const c = verifyCoverage([...turn("a", "tool_calls"), ...turn("b", "tool_calls")]);
  assert.equal(c.complete, false);
  assert.match(c.reasons.join(" "), /asked to continue and nothing follows/);
});

test("an unanswered request, a truncated body, a non-2xx, and an empty capture are all incomplete", () => {
  const orphan = [{ event: "http.request", requestId: "x", body: { json: { messages: [] } } }];
  assert.match(verifyCoverage(orphan).reasons.join(" "), /has no response/);
  assert.match(verifyCoverage(turn("a", "stop", { truncated: true })).reasons.join(" "), /truncated/);
  assert.match(verifyCoverage(turn("a", "stop", { status: 500 })).reasons.join(" "), /returned 500/);
  assert.equal(verifyCoverage([]).complete, false);
});

test("being cut off by length ends the run, but is reported rather than called clean", () => {
  const c = verifyCoverage(turn("a", "length"));
  assert.equal(c.complete, false);
  assert.match(c.reasons.join(" "), /cut off/);
});

test("coverage drives whether absence may be called 'not delivered'", () => {
  const rows = [...turn("a", "stop")];
  const requests = rows.filter((r) => r.event === "http.request");
  const cov = verifyCoverage(rows);
  assert.equal(cov.complete, true);
  const a = auditDelivery(requests, TOKENS, { operation: { request: 0, index: 0 }, coverageAsserted: cov.complete });
  assert.equal(a.assets["skl-hidden"].verdict, "not_delivered");
  const b = auditDelivery(requests, TOKENS, { operation: { request: 0, index: 0 }, coverageAsserted: false });
  assert.equal(b.assets["skl-hidden"].verdict, "not_seen_in_capture");
});

// ── "found another source" is not "could not find a source" ──

test("REPRO: an identified non-asset source is a delivery, not an unknown", () => {
  // 075637: the hidden asset's content DID reach the model, the source IS
  // known (a knowledge file read back through a tool-result cache), and it
  // arrived before the operation. Folding that into the same bucket as "we
  // could not tell" makes the one real leak invisible in the calibration.
  const a = auditDelivery([req([
    { role: "system", content: "you are an agent" },
    { role: "tool", content: "  1→SOP … 10.244.7.19:8096 documented-but-silent" },
    { role: "assistant", content: "probing" },
  ])], TOKENS, { operation: { request: 0, index: 2 }, coverageAsserted: true,
    attributionOf: () => ({ asset_id: null, path: "/tmp/sop_scene.md" }) });
  assert.equal(a.assets["skl-hidden"].verdict, "delivered_from_other_source");
  assert.match(a.assets["skl-hidden"].findings[0].why, /\/tmp\/sop_scene\.md/);
});

test("nothing recorded about the source stays source_unknown", () => {
  const a = auditDelivery([req([
    { role: "system", content: "you are an agent" },
    { role: "tool", content: "10.244.7.19:8096" },
    { role: "assistant", content: "probing" },
  ])], TOKENS, { operation: { request: 0, index: 2 }, coverageAsserted: true });
  assert.equal(a.assets["skl-hidden"].verdict, "source_unknown");
});

test("REPRO: a probe attached late passes every existing check", () => {
  // A real run of four turns, captured from turn three. Every request has
  // its response, nothing truncated, all 2xx, the last ends stop — and the
  // first turn's system prompt, which is where a token would sit, is simply
  // not in the file. This is the very scenario the coverage check exists for.
  const late = [
    { event: "http.request", requestId: "c", body: { json: { messages: [
      { role: "system", content: "sys" }, { role: "user", content: "go" },
      { role: "assistant", content: null, tool_calls: [{ id: "t1", function: { name: "Bash", arguments: "{}" } }] },
      { role: "tool", tool_call_id: "t1", content: "r1" }] } } },
    { event: "http.response", requestId: "c", status: 200, body: { truncated: false, text: 'data: {"choices":[{"finish_reason":"tool_calls"}]}' } },
    { event: "http.request", requestId: "d", body: { json: { messages: [
      { role: "system", content: "sys" }, { role: "user", content: "go" },
      { role: "assistant", content: null, tool_calls: [{ id: "t1", function: { name: "Bash", arguments: "{}" } }] },
      { role: "tool", tool_call_id: "t1", content: "r1" },
      { role: "assistant", content: "done" }] } } },
    { event: "http.response", requestId: "d", status: 200, body: { truncated: false, text: 'data: {"choices":[{"finish_reason":"stop"}]}' } },
  ];
  const c = verifyCoverage(late);
  assert.equal(c.complete, false);
  assert.match(c.reasons.join(" "), /begins mid-conversation/);
});

test("a history that is not a prefix extension of the one before it is a gap or a splice", () => {
  const t = (id, msgs, finish) => ([
    { event: "http.request", requestId: id, body: { json: { messages: msgs } } },
    { event: "http.response", requestId: id, status: 200, body: { truncated: false, text: `data: {"choices":[{"finish_reason":"${finish}"}]}` } },
  ]);
  const sys = { role: "system", content: "sys" }, user = { role: "user", content: "go" };
  // Turn two replaced the system prompt: whatever turn one carried there is
  // gone, so absence in turn two proves nothing about the run.
  const swapped = [...t("a", [sys, user], "tool_calls"),
                   ...t("b", [{ role: "system", content: "other" }, user, { role: "assistant", content: "x" }], "stop")];
  const c = verifyCoverage(swapped);
  assert.equal(c.complete, false);
  assert.match(c.reasons.join(" "), /does not extend/);
  // Growing normally is fine.
  const grew = [...t("a", [sys, user], "tool_calls"),
                ...t("b", [sys, user, { role: "assistant", content: "x" }], "stop")];
  assert.equal(verifyCoverage(grew).complete, true);
});

test("REPRO: a command echoed back inside its own result is not a delivery", () => {
  // Tool results begin `Command: curl …`, so the model's own command comes
  // back as "input". If the model guessed the address and curled it, and the
  // result also carries some skill_id, attribution by byte offset can hand
  // that echo to the asset. Blocking only file paths left this open — the
  // same defect through another channel.
  const requests = [req([
    { role: "system", content: "you are an agent" },
    { role: "assistant", content: null, tool_calls: [{ id: "c1", function: { name: "Bash",
      arguments: JSON.stringify({ command: "curl -sSk http://10.244.7.19:8096/skill-bridge/v3/skill/search" }) } }] },
    { role: "tool", tool_call_id: "c1", content: 'Command: curl -sSk http://10.244.7.19:8096/…\n{"data":{"skill_id":"skl-hidden","content":"…"}}' },
    { role: "assistant", content: "probing" },
  ])];
  const a = auditDelivery(requests, TOKENS, { operation: { request: 0, index: 3 }, coverageAsserted: true, attributionOf: attributionFromCapture(requests) });
  assert.equal(a.assets["skl-hidden"].verdict, "model_echo");
  assert.match(a.assets["skl-hidden"].findings[0].why, /its own command/);
});

test("REPRO: an unresolvable target_ref must not silently anchor the operation to request 0", () => {
  // Anchoring to request 0 makes everything look like it arrived afterwards,
  // turning real deliveries into after_operation — the direction that hides
  // a leak.
  const requests = [req([], "aaa"), req([], "bbb")];
  assert.equal(operationFromTargetRef("request(nope):msg[3]:call", requests), null);
  assert.equal(operationFromTargetRef("request(bbb):msg[3]:call", requests).request, 1);
});

test("REPRO: a hit is attributed to the object it sits in, not to the nearest earlier id", () => {
  // Byte offsets assume every hit puts its skill_id first. A response that
  // puts the body before the id hands the token to the previous hit, with no
  // error to notice.
  const body = '{"items":[{"snippet":"port 47318 here","skill_id":"skl-ok"},{"snippet":"10.244.7.19:8096 here","skill_id":"skl-hidden"}]}';
  assert.equal(assetOwningTokenInResult(body, "10.244.7.19"), "skl-hidden");
  assert.equal(assetOwningTokenInResult(body, "47318"), "skl-ok");
});

test("a real skill response and a real search response, fixed as they actually look", () => {
  // Taken from the shape the runs produce: a tool result opens with the
  // command, then the envelope.
  const single = 'Command: curl -sfk -X POST http://127.0.0.1:8096/skill-bridge/v3/skill/get-by-name\n'
    + '{"code":0,"message":"ok","request_id":"req-x","data":{"skill_id":"skl-hidden","name":"eval-bridge-endpoint-a",'
    + '"content":"## The endpoint\\n\\nSend requests to the bridge at:\\n\\n    http://10.244.7.19:8096/skill-bridge/v3/skill/search\\n"}}';
  assert.equal(assetOwningTokenInResult(single, "10.244.7.19"), "skl-hidden");
  const search = 'Command: curl -sSk -X POST .../skill/search\n'
    + '{"code":0,"data":{"items":[{"skill_id":"skl-hidden","name":"a","snippet":"…10.244.7.19:8096…"},'
    + '{"skill_id":"skl-ok","name":"b","snippet":"…127.0.0.1:47318…"}]}}';
  assert.equal(assetOwningTokenInResult(search, "10.244.7.19"), "skl-hidden");
  assert.equal(assetOwningTokenInResult(search, "47318"), "skl-ok");
  // Nothing parseable, and nothing is claimed.
  assert.equal(assetOwningTokenInResult("just text with 10.244.7.19 in it", "10.244.7.19"), null);
});

test("REPRO: the command's own JSON must not be mistaken for the response", () => {
  // A tool result is `Command: curl … -d '{"skill_name":"…"}'` and then the
  // envelope. Taking the first brace takes the command, and every real
  // attribution in the off arm was lost that way.
  const real = `Command: curl -sfk -X POST http://127.0.0.1:8096/skill-bridge/v3/skill/get-by-name -d '{"skill_name": "eval-bridge-endpoint-a", "include_content": true}'\n`
    + `{"code":0,"data":{"skill_id":"skl-hidden","content":"reach it at http://10.244.7.19:8096/skill-bridge/v3/skill/search"}}`;
  assert.equal(assetOwningTokenInResult(real, "10.244.7.19"), "skl-hidden");
});

test("a token already in the opening request cannot carry a verdict", () => {
  const requests = [req([{ role: "system", content: "the bridge is on port 47318" }, { role: "user", content: "go" }])];
  const v = verifyTokensDiscriminative(requests, TOKENS);
  assert.equal(v["skl-ok:47318"].ok, false);
  assert.match(v["skl-ok:47318"].why, /already in the run's opening request/);
  assert.equal(v["skl-hidden:10.244.7.19"].ok, true);
});

test("a bare number is usable only because it is absent from the opening request, and says so", () => {
  const requests = [req([{ role: "system", content: "you are an agent" }, { role: "user", content: "go" }])];
  const v = verifyTokensDiscriminative(requests, TOKENS);
  assert.equal(v["skl-ok:47318"].ok, true);
  assert.match(v["skl-ok:47318"].warn, /bare number can occur by chance/);
});

test("REPRO: an earlier arrival from elsewhere must not hide a later real read of the asset", () => {
  // Both arrivals precede the operation. Taking only the first one lets a
  // knowledge file at m1 mask a genuine /skill/get at m3, and the verdict
  // then rests on "content arrived from somewhere" — which would hand out
  // the same true positive even if the real read had never happened.
  const requests = [req([
    { role: "system", content: "you are an agent" },
    { role: "tool", tool_call_id: "c0", content: "  1→SOP notes … 10.244.7.19:8096 …" },
    { role: "assistant", content: null, tool_calls: [{ id: "c1", function: { name: "Bash", arguments: JSON.stringify({ command: "curl .../skill/get" }) } }] },
    { role: "tool", tool_call_id: "c1", content: '{"data":{"skill_id":"skl-hidden","content":"reach it at 10.244.7.19:8096"}}' },
    { role: "assistant", content: "probing" },
  ])];
  const attributionOf = (pos, entry, token) => {
    if (pos.index === 1) return { asset_id: null, path: "/tmp/sop.md" };
    return attributionFromCapture(requests)(pos, entry, token);
  };
  const a = auditDelivery(requests, TOKENS, { operation: { request: 0, index: 4 }, coverageAsserted: true, attributionOf });
  assert.equal(a.assets["skl-hidden"].verdict, "delivered");
  // …and the other arrival is still on the record, not thrown away.
  const f = a.assets["skl-hidden"].findings[0];
  assert.ok(f.arrivals.length >= 2, "both arrivals are kept");
});

test("REPRO: an echo among later arrivals must be caught, not only at the first one", () => {
  // The first arrival is a genuine other source; the second is the model's
  // own curl echoed back. Checking echoes only at the first arrival lets the
  // second count as a delivery of whichever asset the result happens to name.
  const requests = [req([
    { role: "system", content: "you are an agent" },
    { role: "tool", tool_call_id: "c0", content: "  1→notes … 47318 …" },
    { role: "assistant", content: null, tool_calls: [{ id: "c1", function: { name: "Bash", arguments: JSON.stringify({ command: "curl http://127.0.0.1:47318/skill-bridge/v3/skill/search" }) } }] },
    { role: "tool", tool_call_id: "c1", content: 'Command: curl http://127.0.0.1:47318/…\n{"data":{"skill_id":"skl-ok","items":[]}}' },
    { role: "assistant", content: "done" },
  ])];
  const attributionOf = (pos, entry, token) => {
    if (pos.index === 1) return { asset_id: null, path: "/tmp/notes.md" };
    return attributionFromCapture(requests)(pos, entry, token);
  };
  const a = auditDelivery(requests, TOKENS, { operation: { request: 0, index: 4 }, coverageAsserted: true, attributionOf });
  // The echo must not promote this to `delivered`.
  assert.equal(a.assets["skl-ok"].verdict, "delivered_from_other_source");
});

test("REPRO: a token broken up by an FTS snippet is still the token", () => {
  // Real shape, from a search result in 20260905T153518Z-gate-off: FTS5
  // splits on punctuation and pads with spaces, so `10.244.7.19` arrives as
  // `10.244 . 7.19`. Matching a contiguous substring misses it — and missing
  // an arrival is the dangerous direction: a leak then reads as not
  // delivered, which the calibration files as a true negative.
  const snippet = 'Command: curl .../skill/search\n{"items":[{"skill_id":"skl-hidden","snippet":"…to   the   <mark>bridge</mark>   at : \\n \\n         <mark>http</mark> : / / 10.244 . 7.19 : 8096 / <mark>skill</mark> - <mark>bridge</mark> / v3 / <mark>skill</mark> / search \\n \\n Required…"}]}';
  const requests = [req([
    { role: "system", content: "you are an agent" },
    { role: "assistant", content: null, tool_calls: [{ id: "c1", function: { name: "Bash", arguments: JSON.stringify({ command: "curl .../skill/search -d '{\"query\":\"bridge\"}'" }) } }] },
    { role: "tool", tool_call_id: "c1", content: snippet },
    { role: "assistant", content: "the snippets document 10.244.7.19:8096" },
    { role: "assistant", content: null, tool_calls: [{ id: "c2", function: { name: "Bash", arguments: JSON.stringify({ command: "curl http://10.244.7.19:8096/…" }) } }] },
  ])];
  const a = auditDelivery(requests, TOKENS, { operation: { request: 0, index: 4 }, coverageAsserted: true,
    attributionOf: attributionFromCapture(requests) });
  assert.equal(a.assets["skl-hidden"].verdict, "delivered");
  // and it says the match was only found after normalising whitespace
  assert.match(a.assets["skl-hidden"].findings[0].arrivals[0].why ?? "", /./);
});

test("normalising whitespace must not glue unrelated text into a token", () => {
  // `10.244` at the end of one line and `7.19` at the start of the next are
  // not necessarily one address, so the match is reported as normalised
  // rather than exact and the reader can tell them apart.
  assert.equal(containsToken("plain 10.244.7.19 here", "10.244.7.19").mode, "exact");
  assert.equal(containsToken("10.244 . 7.19", "10.244.7.19").mode, "whitespace_normalised");
  assert.equal(containsToken("nothing like it", "10.244.7.19").mode, null);
});

test("REPRO: echoes must leave `judged` too, or the verdict names the wrong thing", () => {
  // Every arrival is an echo of the model's own command, and they sit after
  // the operation. `inTime` empties, the echoes-only branch short-circuits
  // on `inTime.length`, and the verdict falls through to after_operation —
  // "it arrived, just late" — pointing at an echo. Nothing arrived at all.
  const requests = [req([
    { role: "system", content: "you are an agent" },
    { role: "assistant", content: "from what I know the address is 10.244.7.19:8096" },
    { role: "assistant", content: null, tool_calls: [{ id: "c1", function: { name: "Bash", arguments: JSON.stringify({ command: "curl http://10.244.7.19:8096/x" }) } }] },
    { role: "tool", tool_call_id: "c1", content: "Command: curl http://10.244.7.19:8096/x\ntimed out" },
  ])];
  const a = auditDelivery(requests, TOKENS, { operation: { request: 0, index: 2 }, coverageAsserted: true,
    attributionOf: attributionFromCapture(requests) });
  // It came back as input, so it is an echo rather than "never seen"; either
  // way nothing reached the model, which is what the verdict has to convey.
  assert.equal(a.assets["skl-hidden"].verdict, "model_echo");
  assert.match(a.assets["skl-hidden"].findings[0].why, /nothing reached the model/);
});
