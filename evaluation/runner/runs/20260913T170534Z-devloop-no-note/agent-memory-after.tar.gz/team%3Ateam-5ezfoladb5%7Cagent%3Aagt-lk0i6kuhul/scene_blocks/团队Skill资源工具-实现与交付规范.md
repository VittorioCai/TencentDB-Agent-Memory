-----META-START-----
created: 2026-09-13T17:06:26.688Z
updated: 2026-09-13T17:06:26.688Z
summary: 团队 skill 资源抓取工具的实现 SOP 与交付规范：bridge 信封解析、空资源与错误处理边界、依赖注入与测试覆盖方法，以及"先查团队经验再动手"的协作约定。
heat: 1
-----META-END-----

## 工作场景
适用于为团队 skill 体系开发/扩展资源读写工具类代码的任务：需要从 bridge 拉取团队 skill 资源文件、需要与既有 v3 路由契约保持一致、需要补充可注入、可测试的抓取逻辑。也适用于团队 skill 知识库的使用与代码交付流程。

## 适用条件
- 仓库属于采用 skill 形式沉淀团队经验的团队；成员在实现前有可检索的团队知识库。
- 工具与 bridge 的 v3 路由交互，返回统一 `{code, message, data}` 信封。
- 交付物需在 `evaluation/` 下通过 `node --test` 的 `*.test.mjs` 验证。

## 核心 SOP
- 动手前先检索团队经验：在团队知识库按 skill 检索一次，命中则参考复用，未命中再按自身判断实现；目的是避免重复踩坑。
- 抓取链路固定：通过 bridge `POST /skill/files/read` 读取，解析统一信封；由 `data.encoding` 决定对 `data.content`（base64 或 utf-8）的解码方式，成功时返回资源原始字节 Buffer。
- 工具以 `fetchResource({ skillId, path, bridgeBase, fetcher })` 形式导出，`fetcher` 可注入以便传桩测试，缺省回退 `globalThis.fetch`。
- 配套测试覆盖四类用例：正常解码返回 Buffer、空资源返回零字节 Buffer、非零 code 抛出携带信封 message 的 Error、缺省 fetcher 使用 `globalThis.fetch`。
- 交付收尾：只改必要文件，运行 `evaluation` 下相关测试确认全绿且既有行为不变，最后说明改了什么、为什么。

## 判断逻辑
- 信封 code 非 0 时 HTTP 仍为 200，因此不能靠状态码判成败，必须解析信封；`message` 是唯一可用的诊断信息，故错误须原样透传。
- 空资源与"缺失"语义不同：空文件是合法产物，返回零字节 Buffer 而非 undefined/null，避免调用方误判为失败。
- 依赖注入优先于硬编码全局 fetch，便于测试与替换，缺省值保证生产可用。

## 禁忌与反模式
- 不要用 HTTP 状态码判断 bridge 调用是否成功：失败也返回 200，会漏掉业务错误。
- 不要吞掉非零 code 的 message 或替换成自造文案：会丢失唯一诊断线索。
- 不要把空资源当作缺失值返回，也不要在实现前跳过团队经验检索。
- 不要为完成任务而扩大改动面或跳过测试。

## 关键事实依据
- 新增 `evaluation/gate/fetch-resource.mjs`（导出 `fetchResource`）与 `evaluation/gate/fetch-resource.test.mjs`（覆盖上述四类用例）。
- bridge `POST /skill/files/read` 与其它 v3 路由一致，返回 `{code, message, data}`；`data.content` 为字符串，`data.encoding` 决定 base64 或 utf-8。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`、`evaluation/gate/fetch-resource.test.mjs`；团队 skill 知识库（经验检索入口）。

## 演化记录
（空）

## 待确认问题
- 团队经验检索的规范入口/路径与会话流程尚未记录，需确认统一的检索方式。
