-----META-START-----
created: 2026-09-13T17:07:29.570Z
updated: 2026-09-13T17:07:29.570Z
summary: 团队交付SOP与Skill检索约定：动手前先查团队知识库skill；最小改动、补测试、跑测试、说明原因；工具接口需可注入依赖、不硬编码配置、不吞错误信封、空文件合法。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库团队（成员或 Agent）承接代码交付任务的通用工作方法，尤其是"新增一个 .mjs 工具 + 补测试"这类小范围改动，以及需要调用团队知识库（skill bridge）资源文件的场景。可复用于同类仓库的任意增量交付。

## 适用条件
- 仓库含 evaluation/ 测试目录，用 `node --test` 跑 `*.test.mjs`。
- 团队过往经验以 skill 形式存于团队知识库，可经 bridge 访问。
- 任务为新增工具或局部改动，要求保持已有行为不变。

## 核心 SOP
- 先检索团队经验：动手前查一次团队知识库 skill，有相关就参考，没有则按自身判断实现。（本次参考了 skill bridge skill，id `skl-oBaDO5CceKnr`。）
- 先探接口再实现：用 `skill/get` 看候选 skill 的 manifest，用 `skill/files/read` 分别探测"文件不存在"与"skill 缺失"场景，确认真实响应与错误信封形状，避免凭猜测写分支。
- 最小改动：只修改必要的文件。
- 补测试：为新增工具至少补一条测试。
- 回归验证：运行 evaluation 下全部 `*.test.mjs`，确保通过且已有行为不变。
- 交付说明：最后说明改了什么、为什么。

## 判断逻辑
- 团队经验优先：先复用已验证方法，避免重复造轮子；无相关经验才自主判断。
- 配置外置：bridge 端口因部署而异（团队 skill 指向的端口 ≠ 本地），故 bridge 地址必须由 `bridgeBase` 参数传入、由调用方决定，不硬编码。
- 可测试性优先：HTTP 实现经 `fetcher` 注入（测试传桩），缺省使用 `globalThis.fetch`。
- 错误显式传播：上游返回错误信封（`code !== 0`）必须抛出 Error，message 带上信封的 message，不得吞掉。
- 空文件合法：资源内容为空时返回零字节 Buffer，不当作错误。

## 禁忌与反模式
- 不先查团队经验就动手：会重复踩坑、丢失团队已沉淀的做法。
- 硬编码 bridge 端口/地址：本地与团队部署不一致，必然错连。
- 直接依赖 `globalThis.fetch` 而不留注入点：测试无法打桩。
- 吞掉或改写上游错误信封：调用方无法感知真实失败。
- 把空资源当错误：空文件是合法资源。
- 改动范围外文件、不跑测试、不说明改动原因：违反团队交付约定。

## 关键事实依据
- 交付物：`evaluation/gate/fetch-resource.mjs`，导出 `async function fetchResource({ skillId, path, bridgeBase, fetcher })`，把团队 skill 的资源文件取到本地，成功返回原始字节 Buffer 供调用方直接写文件。
- 参考团队 skill：skill bridge（`skl-oBaDO5CceKnr`）。
- 探查接口：skill-bridge v3 的 `skill/get`、`skill/files/read`。

## 相关任务与资产
- 待跟进：为 fetchResource 补一条测试；实测确认 skill-bridge v3 错误信封形状（`nope.md` 与 `skl-000000` 两个场景）。

## 演化记录
（空）

## 待确认问题
- skill-bridge v3 在"文件不存在"与"skill 缺失"下的错误信封字段形状尚未实测确认，需对齐后才能定型错误处理分支。
