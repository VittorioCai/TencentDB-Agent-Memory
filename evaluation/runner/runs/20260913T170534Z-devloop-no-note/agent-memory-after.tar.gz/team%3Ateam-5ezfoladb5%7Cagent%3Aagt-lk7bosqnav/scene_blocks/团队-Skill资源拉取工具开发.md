-----META-START-----
created: 2026-09-13T17:07:00.961Z
updated: 2026-09-13T17:07:00.961Z
summary: 团队在 evaluation/gate 下开发 skill 资源拉取工具的复用方法：动手前检索团队 skill 经验，遵循最小改动与测试基线约束，并以明确接口契约设计 fetchResource。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库 evaluation/gate 类工具模块（当前为 fetch-resource.mjs）的新增与维护。核心目标是把团队知识库中 skill 的资源文件拉到本地，并为工具补齐契约测试。该场景可复用到任何"新增小型工具 + 补测试 + 不破坏既有行为"的仓库任务。

## 适用条件
- 任务落在 evaluation 目录，需新增或改动工具型 mjs 模块。
- 团队经验以 skill 形式保存在知识库中，可被检索。
- 仓库存在既有测试基线，改动不得破坏已有行为。

## 核心 SOP
- 先检索团队经验：动手前检索一次团队 skill 库，有相关 skill 就参考执行，没有则按自身判断完成。
- 先定接口契约再编码：导出 async function fetchResource({ skillId, path, bridgeBase, fetcher })。
- 依赖注入：HTTP 实现经 fetcher 注入，缺省 globalThis.fetch，便于测试传桩。
- 最小改动：只改必要文件，保持已有行为不变。
- 补测试：为新增工具补测试，覆盖成功字节、空内容、错误信封、注入 fetcher 的请求形状四类用例。
- 验证并说明：用 node --test 跑 evaluation 下 *.test.mjs，确认全部通过后说明改了什么、为什么。

## 判断逻辑
- 团队经验优先复用，避免重复造轮子，同时保留无经验时的自主判断空间。
- 接口以"调用方友好"为准：成功直接返回原始字节 Buffer 供写文件；空文件视为合法，返回零字节 Buffer。
- 错误不吞：上游 code !== 0 视为错误信封，抛 Error 且 message 必须携带信封 message，保留可诊断性。
- 用 fetcher 注入而非直接绑定 fetch，是为让测试能通过桩替换 HTTP 层。

## 禁忌与反模式
- 吞掉错误信封：code !== 0 必须抛出并携带 message，否则掩盖上游故障。
- 把空内容当异常：空文件是合法文件，应返回零字节 Buffer。
- 越界改动：改动超出必要范围或改变已有行为。
- 未验证交付：不跑测试就交付，或省略最终改动说明。

## 关键事实依据
- 测试基线：改动前 node --test evaluation 下 *.test.mjs 为 637 pass / 0 fail / 2 skipped。
- 相关 skill 资产：eval-skill-resource-download（skl-XAzqAgejM7O4）、eval-bridge-endpoint-b（skl-oBaDO5CceKnr）。
- 核心交付物：evaluation/gate/fetch-resource.mjs。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs（新增，核心交付物）
- 对应新增测试文件（覆盖四类用例）
- 参考 skill：eval-skill-resource-download、eval-bridge-endpoint-b

## 演化记录
（无）

## 待确认问题
- skill 资产中错误信封 code/资源格式的具体约定尚未展开。
