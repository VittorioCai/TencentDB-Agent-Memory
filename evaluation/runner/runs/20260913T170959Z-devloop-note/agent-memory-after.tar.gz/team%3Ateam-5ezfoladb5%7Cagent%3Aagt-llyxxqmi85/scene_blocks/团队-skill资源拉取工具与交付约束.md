-----META-START-----
created: 2026-09-13T17:11:49.446Z
updated: 2026-09-13T17:11:49.446Z
summary: 团队新增 skill 资源拉取工具（fetchResource）的接口契约、交付与测试约束，以及“动手前先检索团队经验”的通用前置 SOP 与回归红线。
heat: 1
-----META-END-----

## 工作场景
适用于团队仓库 `evaluation/gate/` 模块内新增小型工具函数（如把团队 skill 的资源文件拉取到本地）这类任务。核心可复用点是：动手前先检索团队经验库，动手时严格遵循既定接口契约，交付时保证全量测试不回归、只改必要文件并说明改动。

## 适用条件
- 任务类型：在既有 Node 工程中新增一个纯函数式工具 + 一条测试。
- 团队约束：过往经验以 skill 形式存于团队知识库；仓库用 `node --test` 跑 `*.test.mjs`。
- Agent 执行场景：需可注入 HTTP 实现（便于测试传桩），且不得破坏既有行为。

## 核心 SOP
- 前置检索团队经验：动手实现前先检索一次团队知识库，有相关 skill 就参考，没有则按自己判断执行——避免重复造轮子并保持与团队做法一致。
- 按契约实现 `evaluation/gate/fetch-resource.mjs`，导出 `async fetchResource({ skillId, path, bridgeBase, fetcher })`：`fetcher` 用于注入 HTTP 实现，测试传桩，缺省回落 `globalThis.fetch`。
- 补齐一条测试：新增工具必须自带测试覆盖，而非只写实现。
- 全量回归：`node --test` 下 evaluation 目录全部 `*.test.mjs` 必须通过，且已有行为不变。
- 最小改动 + 交付说明：只修改必要文件；完成后说明“改了什么、为什么”。

## 判断逻辑
- 返回值设计为原始字节 `Buffer`：让调用方直接写文件，拉取层不承担解析/落盘职责，职责边界清晰。
- 空内容返回零字节 Buffer 而非报错：空文件是合法资源，若当异常处理会误伤合法数据。
- 错误信封（`code !== 0`）抛 `Error` 且 `message` 携带信封 message：错误必须向上暴露、不得吞掉，保留原始错误信息以便定位。
- `fetcher` 可注入：把网络依赖外置为参数，使测试可用桩替换，达到可测性与确定性。
- 要求全量测试通过且行为不变：新增工具不能以回归既有能力为代价，回归测试是安全网。

## 禁忌与反模式
- 吞掉上游错误：`code !== 0` 时必须抛错并携带信封 message，静默返回会掩盖失败。
- 把空资源当成错误：零字节是合法结果，不可抛异常或返回 null/undefined。
- 只改实现不加测试：新工具必须补测试，否则不满足交付要求。
- 改动范围外扩：只改必要文件，避免无关重构污染 diff、放大回归风险。
- 硬编码 HTTP 实现：必须保留 `fetcher` 注入口并缺省 `globalThis.fetch`，否则测试无法传桩。

## 关键事实依据
- 目标文件：`evaluation/gate/fetch-resource.mjs`；导出 `fetchResource({ skillId, path, bridgeBase, fetcher })`。
- 团队知识库中存在直接相关 skill：`eval-skill-resource-download`（skill_id: `skl-XAzqAgejM7O4`），可作为实现参考资产。
- 测试基线：`node --test` 执行 evaluation 目录下全部 `*.test.mjs`。

## 相关任务与资产
- 待办：实现 `fetch-resource.mjs` + 补一条测试，跑通 evaluation 全量测试并输出改动说明。
- 参考资产：团队 skill `eval-skill-resource-download`（skl-XAzqAgejM7O4）。

## 演化记录
（空）

## 待确认问题
- 是否所有团队仓库/模块都要求“动手前检索团队经验”，还是仅本项目约定？需在更多任务中确认为团队级规则。
