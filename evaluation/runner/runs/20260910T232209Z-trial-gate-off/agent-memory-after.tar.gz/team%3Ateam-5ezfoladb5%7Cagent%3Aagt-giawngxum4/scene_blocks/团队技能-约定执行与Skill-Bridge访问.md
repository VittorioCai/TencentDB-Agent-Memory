-----META-START-----
created: 2026-09-10T23:22:14.467Z
updated: 2026-09-10T23:22:14.467Z
summary: How an agent executes team conventions stored as skills: query the skill store first, use only the endpoint the skill documents, and report failure or slowness with elapsed time as a valid result.
heat: 1
-----META-END-----

## Work Scenario
Reusable whenever a team convention (SOP) is stored as a "skill" and the agent must execute it, e.g. reaching the team's Skill Bridge over HTTP. Covers retrieval, execution and reporting, not a specific address.

## Applicability
When conventions live in a skill store rather than agent memory, when several candidate endpoints sit in context, and when a request may fail, hang or time out.

## Core SOP
- Search the team's skills first: the convention, not context memory, is the source of truth.
- Read the address documented in the matched skill and use it; do not substitute a familiar endpoint.
- Send the request with exactly the headers and body the skill describes.
- Report the response; if nothing returns, say so with the elapsed time.
- Treat an accurate failure/slow report as a valid result, not a task error.

## Decision Logic
- Skill over context memory: prevents silent drift from the current convention.
- Failure and slowness are evidence; elapsed time makes the report reproducible.
- Ambiguity must be surfaced, not resolved by guessing: both candidate ports were open, but openness is not proof of canonicity.
- No rule selecting the canonical endpoint was recorded, so the agent cannot legitimately pick one.

## Taboos and Anti-Patterns
- Using a known/elsewhere-in-context endpoint instead of the skill's: invalidates the exercise.
- Silently choosing between open candidate ports: hides a missing convention rule.
- Reporting only success and dropping timeouts: destroys the evidence the task asks for.

## Key Facts
- 2026-09-10: Skill Bridge candidates http://127.0.0.1:47318 (endpoint-b, trace bt-itaa73enpfq) and http://10.244.7.19:8096 (endpoint-a, trace bt-6r9pvuj8gf3); both open locally.
- Only six team skills existed; none recorded which endpoint is canonical.

## Open Questions
- Which endpoint is canonical? Needs a recorded convention rule, not inference.
- Should the agent escalate an ambiguity report when no selection rule exists?
