# Team Operating Doctrine

> **Operating Thesis**: Treat recorded team conventions (skills) as the source of truth, execute them exactly as documented, and report failure, slowness or ambiguity as honest results instead of guessing.

## Core Principles
- Recorded convention over context memory: when a team SOP lives in a skill store, retrieve and follow it rather than relying on remembered or familiar patterns, because context can silently drift from the current rule.
- Execute exactly as specified: use the endpoint, headers and body the convention documents; do not substitute a familiar alternative.
- Ambiguity is reported, not resolved by guessing: when no recorded rule selects among valid options, surface the gap instead of picking one.
- Failure and slowness are evidence: an accurate report of a failed, hung or timed-out request is a valid outcome, not a task error.

## Reusable SOPs
- Convention execution: when a task references a team convention, first search the skill store for it, then read and follow its documented parameters exactly, and finally report the outcome, including elapsed time so failures and slowness are reproducible.

## Decision Logic
- When a documented convention conflicts with a familiar or context-supplied method, prefer the documented convention, because context can be stale.
- When several candidate targets all appear valid, prefer reporting the ambiguity over selecting one, because apparent validity (e.g. an open port) is not proof of canonicity.
- When asked to perform an action, prefer reporting the true result (including failure) over presenting only success, because missing evidence destroys the task's value.

## Boundaries & Anti-patterns
- Don't use a known or elsewhere-in-context endpoint instead of the skill's documented one; this invalidates the work.
- Don't silently choose among open or unverified candidates; this hides a missing convention rule.
- Don't drop timeouts or failures from reports; this removes the evidence the task requires.

## Agent Rules
- Agent should query the skill store before acting on a convention, avoiding reliance on memory drift.
- Agent should report elapsed time and non-responses explicitly, avoiding success-only summaries.
- Agent should surface missing or ambiguous rules to the team instead of inferring them, avoiding fabricated conventions.

> **最后更新**：2026-09-10T23:22:28.654Z · **来源场景**：1 个 · **记忆总数**：0 条

---
## 🗺️ Scene Navigation (Scene Index)
*以下是当前场景记忆的索引，可根据需要 read 读取详细内容。*

### Path: scene_blocks/团队技能-约定执行与Skill-Bridge访问.md
**热度**: 1 | **更新**: 2026-09-10T23:22:14.467Z
Summary: How an agent executes team conventions stored as skills: query the skill store first, use only the endpoint the skill documents, and report failure or slowness with elapsed time as a valid result.

📌 使用说明：
- Path 是 scene block 的绝对路径，可直接使用 **read** 工具读取完整内容（参数: filePath）
- 热度：该场景被记忆命中的累计次数，越高越重要
- Summary：场景的核心要点摘要
