-----META-START-----
created: 2026-09-13T17:09:47.393Z
updated: 2026-09-13T17:09:47.393Z
summary: 沉淀团队工具开发方法：动手前先检索团队 skill 经验、资源下载类工具的接口契约（Buffer/空文件合法/错误信封抛出/fetcher 注入）与测试交付约束。
heat: 1
-----META-END-----

## 工作场景
适用于在团队仓库中新增工具/模块类任务的开发场景，典型如"把团队 skill 资源文件取到本地"这类带外部 HTTP 依赖的小工具。可复用点：开发前置检索、接口契约设计、交付验收口径。

## 适用条件
- 仓库所属团队把过往经验以 skill 形式沉淀在团队知识库中。
- 任务为新增独立工具文件，边界清晰，且要求保持既有行为不变。
- 存在外部依赖（如 HTTP）需要可注入以便隔离测试。

## 核心 SOP
- 先检索团队经验一次：有相关 skill 就参考执行，没有则按自身判断实现；避免重复踩坑并保持与团队沉淀一致。
- 先定接口契约再动手：入参、返回值形态、异常语义、可注入依赖都要明确。
- 实现时只改必要文件，保证已有行为不变。
- 为新增工具补一条测试，并运行 `node --test` 使 evaluation 下全部 `*.test.mjs` 通过。
- 完成后说明改了什么、为什么，便于评审与后续复用。

## 判断逻辑
- 团队沉淀优先于个人判断：仅当无相关经验时才自由发挥。
- 依赖注入 `fetcher` 缺省用 `globalThis.fetch`：测试可传桩隔离真实网络，兼顾生产默认行为。
- 以"资源原始字节"作为返回形态（Buffer）：让调用方直接落盘，工具不做额外解析或包装。

## 禁忌与反模式
- 不要把空资源当错误：空文件是合法文件，必须返回零字节 Buffer，不得抛异常或返回 null 等空值。
- 不要吞掉上游错误：收到错误信封（code !== 0）时必须抛出 Error，且 message 携带信封的 message。
- 不要改动无关文件或破坏既有测试。
- 不要跳过团队经验检索直接开工。

## 关键事实依据
- 相关团队 skill：eval-skill-resource-download（skl-XAzqAgejM7O4）、eval-bridge-endpoint-b（skl-oBaDO5CceKnr）。
- 目标工具：`evaluation/gate/fetch-resource.mjs`，导出异步函数 `fetchResource({ skillId, path, bridgeBase, fetcher })`。
- 契约：成功返回原始字节 Buffer；内容为空返回零字节 Buffer；错误信封 code !== 0 抛 Error 并透传 message。

## 相关任务与资产
- 待办：实现 `evaluation/gate/fetch-resource.mjs` 并补测试，确保 evaluation 下 `*.test.mjs` 全部通过。
- 交付口径：只改必要文件，改完运行相关测试确认通过，并说明改动与原因。
