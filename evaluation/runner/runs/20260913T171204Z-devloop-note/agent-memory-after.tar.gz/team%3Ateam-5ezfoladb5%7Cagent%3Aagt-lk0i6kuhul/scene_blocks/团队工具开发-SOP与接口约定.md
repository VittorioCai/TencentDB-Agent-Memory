-----META-START-----
created: 2026-09-13T17:13:11.115Z
updated: 2026-09-13T17:13:11.115Z
summary: 团队在本仓库新增工具类模块（如 evaluation/gate 下 skill 资源抓取工具）的可复用工作方法：先查团队 skill 经验，最小化改动、补测试、回归对比，并遵循信封/错误/注入的接口约定。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库新增或修改工具类模块的端到端开发，典型对象是 `evaluation/gate/` 下把团队 skill 资源文件取到本地的抓取工具（如 `fetch-resource.mjs`）。此类任务既涉及"怎么写"，也涉及"团队怎么做改动"，可复用于任何需要交付小而精的 Node 工具并附带测试的场景。

## 适用条件
- 团队把过往经验以 skill 形式保存在团队知识库中，成员被要求动手前先检索。
- 仓库遵循最小化改动与行为兼容约束，Node 环境用 `node --test` 跑 `*.test.mjs`。
- 工具需被测（HTTP 实现可被桩替换），因此可测试性是设计前置条件而非事后补充。

## 核心 SOP
- 先检索团队经验：动手前查一次团队知识库中以 skill 形式沉淀的过往经验，有相关就参考，没有则按自身判断执行；避免重复造轮子并复用既有约定。
- 明确接口再落码：先固定导出签名与行为边界（返回值语义、错误语义、注入点），把可测试性作为接口的一部分。
- 只改必要文件：改动面保持最小，不触碰无关模块，确保已有行为不变。
- 补测试：为新工具补一条测试，覆盖正常、空值、错误、缺省注入四类情况。
- 回归验证：用 `node --test` 跑 evaluation 下全部 `*.test.mjs`，与改动前基线对比确认无回归。
- 最后说明：明确交代改了什么、为什么改，便于 review 与后续追溯。

## 判断逻辑
- 把返回值设计成原始字节 `Buffer`，调用方可直接写文件，避免工具层去做多余的编码转换。
- 空资源是合法文件，必须返回零字节 `Buffer` 而不是 `null`/缺失值，否则调用方无法区分"空文件"与"取不到"。
- 上游失败以信封表达（HTTP 200 但 `code !== 0`），此时信封 `message` 是唯一可用诊断信息，因此必须原样带入抛出的 `Error`，不能吞掉。
- `fetcher` 作为可注入参数（缺省回退 `globalThis.fetch`），是为了让测试可以传桩、隔离网络，保证可测与可回归。

## 禁忌与反模式
- 不要把空资源当缺失值返回或抛错：空文件合法，应返回零字节 `Buffer`。
- 不要吞掉上游错误信封的 `message`：丢失诊断信息会让失败难以定位。
- 不要硬编码 `fetch` 而不可注入：导致测试无法传桩、必须打真实网络。
- 不要顺手改无关文件或改变已有行为：违反最小化改动，增加回归风险。
- 不要跳过回归跑测与改动说明：无法证明"已有行为不变"。

## 关键事实依据
- evaluation 测试基线（实现 `fetch-resource.mjs` 前）：637 通过、0 失败、2 跳过，运行方式 `node --test evaluation/**/*.test.mjs`，作为改动后回归对比基准。
- 团队 skill 资源通过 bridge 的 `POST /skill/files/read` 读取，返回与其它 v3 路由一致的 `{code, message, data}` 信封；`data.content` 为字符串，按 `data.encoding`（base64 或 utf-8）决定解码方式；失败时 HTTP 仍为 200 但信封 `code` 非 0。
- 交付物：`evaluation/gate/fetch-resource.mjs`（导出 `fetchResource({ skillId, path, bridgeBase, fetcher })`）与 `evaluation/gate/fetch-resource.test.mjs`（覆盖信封解码、空资源、非零 code 抛错、缺省 fetcher）。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`、`evaluation/gate/fetch-resource.test.mjs`。
- bridge 路由 `POST /skill/files/read`。

## 演化记录
（空）

## 待确认问题
- 信封 `data.encoding` 除 base64/utf-8 外是否还有其它取值需要支持？
