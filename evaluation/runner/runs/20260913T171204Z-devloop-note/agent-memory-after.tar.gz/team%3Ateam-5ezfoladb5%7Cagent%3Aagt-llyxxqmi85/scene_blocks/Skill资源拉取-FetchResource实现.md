-----META-START-----
created: 2026-09-13T17:13:31.903Z
updated: 2026-09-13T17:13:31.903Z
summary: evaluation/gate 下新增 fetchResource 工具的 SOP：先检索团队 skill 经验，按 bridge files/read 信封契约实现原始字节拉取，补测试并做全量回归，明确空文件与错误信封两条判断原则。
heat: 1
-----META-END-----

## 工作场景
适用于在 Node.js(ESM) 仓库的 `evaluation/gate/` 等网关目录下，为团队 skill bridge 编写"资源拉取/下载"类工具的任务。核心产物是把远端 skill 资源文件取回为可落盘字节的工具函数（此类任务为 `fetch-resource.mjs`），方法论同样可复用到其他 bridge 封装、文件下载或信封解码类工具开发。

## 适用条件
- 仓库属于一个把过往经验沉淀为 skill 的团队，团队知识库可检索。
- 工具需被下游直接消费（返回 Buffer 供调用方写文件），因此接口契约与错误语义必须明确。
- 交付受"最小改动 + 既有测试行为不变"约束，且要求写明改动原因。

## 核心 SOP
- 先检索团队经验：动手实现前先查一次团队知识库 skill，有相关 skill 就参考，没有则按自身判断执行。原因：本仓库团队将踩坑经验固化为 skill，是决定性的参考依据。
- 确认任务边界：实现前先确认是否存在隐藏任务说明，避免按错误前提开工。
- 对齐上游契约：确认 bridge 接口返回形态再写代码——`files/read` 始终返回 `{code, message, data}` JSON 信封（即使请求下载），字节在 `data.content`，编码由 `data.encoding` 标识（utf-8 / base64）。
- 实现导出接口 `fetchResource({ skillId, path, bridgeBase, fetcher })`：成功返回资源原始字节 Buffer；空资源返回零字节 Buffer；错误信封抛 Error；`fetcher` 用于注入 HTTP 实现，缺省 `globalThis.fetch`。
- 补测试：为新增工具至少补一条测试，覆盖正常、空文件、错误信封、编码还原、缺省 fetcher 等分支。
- 全量回归：改前先记录基线，改后用 `node --test` 跑 `evaluation` 下全部 `*.test.mjs`，确保全通过且既有行为不变。
- 收尾交付：只改必要文件，最后说明"改了什么、为什么"。

## 判断逻辑
- 契约优先于实现：先固定返回 Buffer、空文件合法、错误透传三条边界，再写解码逻辑，可避免下游为异常分支写额外适配。
- 空文件与错误必须区分：`data.content === ""` 是合法空文件，应返回零字节 Buffer；只有 `content` 缺失或非字符串才算错误。用 falsy 判断会把空文件误判为无内容（bridge 自身 `files/download` 分支即用 `!parsed.data?.content`，是已知反例），因此判断必须用类型/严格比较。
- 错误不得吞掉：信封 `code !== 0` 时抛 Error 并原样在 message 中携带信封 message，保证上游错误可诊断。
- 依赖可注入：`fetcher` 参数让测试可传桩、生产走 `globalThis.fetch`，兼顾可测性与零配置。

## 禁忌与反模式
- 用 `!data.content` 之类 falsy 判断内容存在性：会把合法空文件误判为无内容，改为严格比较 `=== ""` 与类型检查。
- 吞掉上游错误信封的 message：导致排障信息丢失，必须原样抛出。
- 空资源直接报错：空文件是合法文件，报错会让调用方无法区分"无文件"与"空文件"。
- 为通过测试而放宽契约或改动无关文件：违背最小改动与既有行为不变的约束。
- 跳过团队 skill 检索直接开工：本仓库经验已固化，跳过等于重复踩坑。

## 关键事实依据
- 参考 skill：`eval-skill-resource-download`（skill_id `skl-XAzqAgejM7O4`，tracker `bt-pu6nyfhmu2v`），记录了"空文件判断"与"错误信封 message 被吞掉"两个陷阱。
- 实现路径：通过 POST 调用 skill bridge 的 `files/read` 接口拉取并解码信封为原始字节。
- 改动前基线：`evaluation/gate` 测试 41 通过、2 跳过，作为前后对照基准。

## 相关任务与资产
- 交付物：`evaluation/gate/fetch-resource.mjs`（导出 `fetchResource({ skillId, path, bridgeBase, fetcher })`）。
- 测试资产：`evaluation/gate/fetch-resource.test.mjs`，6 条用例——utf-8 信封解码、base64 还原原始字节、空资源返回零字节 Buffer、错误信封抛出并原样携带 message、成功信封缺 `data.content` 时报错、未传 fetcher 时缺省使用 `globalThis.fetch`；该文件已运行通过。
- 待跟进：完整 `evaluation` 测试套件仍在运行确认中。

## 演化记录
- [2026-09-13]：确立 fetchResource 契约——空资源返回零字节 Buffer（而非报错），仅 `content` 缺失/非字符串才报错；错误信封必须抛出且原样带 message。

## 待确认问题
- 完整 `evaluation` 套件（`node --test` 下全部 `*.test.mjs`）最终是否全绿、既有行为是否完全不变，仍需以最新一次运行结果确认。
