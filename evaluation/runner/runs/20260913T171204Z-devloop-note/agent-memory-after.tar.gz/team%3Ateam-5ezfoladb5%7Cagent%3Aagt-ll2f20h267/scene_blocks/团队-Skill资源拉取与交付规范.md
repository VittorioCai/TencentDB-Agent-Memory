-----META-START-----
created: 2026-09-13T17:13:55.682Z
updated: 2026-09-13T17:13:55.682Z
summary: 沉淀"先检索团队skill再动手"的协作约定，以及实现 fetchResource 资源拉取工具的接口契约、补测与最小改动交付 SOP。
heat: 1
-----META-END-----

## 工作场景
适用于在仓库 `evaluation/gate/` 下新增工具模块（如把团队 skill 的资源文件取到本地的 `fetchResource`）的任务；也适用于团队通用的"动手改代码前先检索团队知识库 skill"协作约定。

## 适用条件
- 任务形态：新增小工具 + 补一条测试，要求不破坏现有测试与行为。
- 团队有以 skill 形式沉淀经验的知识库可供检索。
- 交付约束为"只改必要文件、跑通现有测试、交代改动与原因"。

## 核心 SOP
- 先检索团队 skill：动手实现前检索一次团队知识库，有相关经验就参考，没有则按自身判断推进（本次命中 `skl-XAzqAgejM7O4`）。
- 先定契约再写码：明确导出签名 `fetchResource({ skillId, path, bridgeBase, fetcher })` 后再实现。
- 为新工具补测试，覆盖契约关键分支。
- 只改必要文件，保证 `evaluation` 下所有 `*.test.mjs`（`node --test`）通过、已有行为不变。
- 改完运行相关测试确认通过，最后说明改了什么、为什么。

## 判断逻辑
- 返回原始字节 `Buffer`（非解码后字符串）→ 调用方可直接写文件，避免二次编码处理。
- 空内容返回零字节 `Buffer` → 空文件是合法文件，不应当作错误。
- 上游错误信封 `code !== 0` → 抛 `Error` 且 `message` 携带信封 `message`，让失败可见、可定位。
- `fetcher` 参数注入 HTTP 实现（缺省 `globalThis.fetch`）→ 便于测试传桩，解耦网络依赖。

## 禁忌与反模式
- 吞掉上游错误信封→会把失败当成功，必须抛错并透出原 message。
- 把空资源当异常→空文件合法，应返回零字节 Buffer。
- 顺手改动无关文件→违反"只改必要文件、行为不变"，扩大回归面。
- 跳过团队 skill 检索凭感觉实现→违背团队约定，可能重复踩坑。

## 关键事实依据
- 目标路径 `evaluation/gate/fetch-resource.mjs`；团队知识库命中 skill `skl-XAzqAgejM7O4`。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs` 及其测试文件；owner 未指定。

## 待确认问题
- `bridgeBase` 的具体取值与路由约定未在记忆中说明。
- 上游错误信封的完整结构与其它错误码处理方式待确认。
