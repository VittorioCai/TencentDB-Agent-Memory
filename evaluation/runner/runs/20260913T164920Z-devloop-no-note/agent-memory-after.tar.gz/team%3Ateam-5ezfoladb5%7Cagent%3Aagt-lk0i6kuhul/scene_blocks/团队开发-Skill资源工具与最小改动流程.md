-----META-START-----
created: 2026-09-13T16:51:14.311Z
updated: 2026-09-13T16:51:14.311Z
summary: 沉淀 evaluation/gate 工具开发的接口契约与团队通用流程：动手前检索团队 skill 经验、按对象参数设计可注入依赖、最小化改动、node --test 全通过并说明变更理由。
heat: 1
-----META-END-----

## 工作场景
适用于在本仓库 evaluation 工具链下新增脚本/小工具，以及团队 Agent 承接开发任务时应遵循的通用流程。核心是可复用的交付契约（接口形态 + 行为约定）与协作纪律，而非某一次任务流水。

## 适用条件
处于 evaluation 相关模块开发阶段，需要新增可测试模块；团队以 skill 形式把过往经验沉淀在知识库中，成员需先取用再动手。适用于 Node.js（ESM）环境，测试以 `node --test` 驱动。

## 核心 SOP
- 动手前先检索团队知识库中以 skill 形式保存的过往经验：有相关经验就参考，没有则按自身判断推进。
- 新工具暴露具名导出函数，依赖与配置通过对象解构传入（如 `fetchResource({ skillId, path, bridgeBase, fetcher })`）：便于测试注入桩实现。
- 为新增工具补一条测试：新行为必须可验证，避免只实现不覆盖。
- 只改必要文件，保持已有行为不变：降低回归风险，减少评审面。
- 用 `node --test` 跑 evaluation 下所有 `*.test.mjs`，确认全部通过。
- 结束时说明改了什么、为什么：让变更意图可追溯，便于评审与后续复用。

## 判断逻辑
- 复用优先：团队经验以 skill 沉淀，先检索可避免重复踩坑；检索不到才凭判断行事，兼顾效率与自主性。
- 依赖注入（`fetcher`）优于硬编码 HTTP：缺省 `globalThis.fetch` 保证生产可用，测试传桩实现可离线、可确定地验证。
- 成功返回原始字节 `Buffer` 而非解析后的文本：调用方直接写文件，保持字节保真，不替调用方做格式假设。
- 空资源返回零字节 `Buffer`：空文件是合法文件，不应被当作异常路径。
- 错误信封（`code !== 0`）抛 `Error` 且 `message` 携带信封 message：不吞错，故障可定位。

## 禁忌与反模式
- 吞掉上游错误信封的 message：导致故障静默，改用抛错并透传消息。
- 把空资源当错误：违反"空文件合法"约定，会让正常场景误报。
- 顺手重构或改动无关文件：违背最小化改动，扩大回归面。
- 跳过团队经验检索直接实现：错失既有 skill 结论，重复劳动。
- 只实现不补测试、或跑测试前就收工：无法证明行为正确，违反交付约定。

## 关键事实依据
- `evaluation/gate/fetch-resource.mjs` 导出 `fetchResource({ skillId, path, bridgeBase, fetcher })`，用于把团队 skill 的资源文件取到本地。
- 行为契约：成功返回原始字节 Buffer；空内容返回零字节 Buffer；`code !== 0` 抛 Error 并保留信封 message；`fetcher` 缺省 `globalThis.fetch`。
- 验收方式：`node --test` 跑 evaluation 下 `*.test.mjs`，现有测试全通过、行为不变。

## 相关任务与资产
- 待办：新增 `evaluation/gate/fetch-resource.mjs`（含配套测试）。
- 资产：evaluation 下 `*.test.mjs` 测试套件；团队知识库中的 skill 经验。

## 演化记录
- [2026-09-13]：确立"先检索团队 skill 经验 → 对象参数 + 依赖注入实现 → 补测试 → 最小改动 → node --test 全通 → 说明变更"为新增工具的标准流程与交付契约。

## 待确认问题
- `fetcher` 桩的具体接口形状（返回体结构、如何表达错误信封）尚未明确。
- `bridgeBase` 与 `skillId`/`path` 的 URL 拼装规则未记录，实现时需确认。
