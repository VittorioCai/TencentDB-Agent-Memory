-----META-START-----
created: 2026-09-13T16:49:30.747Z
updated: 2026-09-13T16:49:30.747Z
summary: 团队在仓库内开发与交付工具（如 skill 资源读取）的通用约定：先检索团队经验、建测试基线、只改必要文件、用 node --test 验证、结尾说明改动原因。
heat: 1
-----META-END-----

## 工作场景
适用于本团队在仓库内开发评测相关工具（如把团队 skill 资源读取到本地）的通用开发与交付流程，也可复用于任何"新增小工具 + 补测试 + 保证已有行为不变"的改动任务。

## 适用条件
团队把过往经验以 skill 形式保存在团队知识库；任务落在评测目录（evaluation/）；要求已有行为不变、改动可追溯、交付可解释。

## 核心 SOP
- 检索团队经验：动手前先查一次团队知识库中的 skill，有相关参考就借鉴，没有则按自身判断执行；原因：复用沉淀、避免重复踩坑。
- 建立测试基线：改代码前先 `node --test evaluation/` 确认当前测试状态；原因：之后才能判定"已有行为不变"。
- 最小改动：只改必要的文件，缩小影响面。
- 补测试：为新增工具补一条测试，覆盖其行为契约的关键分支。
- 验证：`node --test` 跑 evaluation 下全部 *.test.mjs，保证全通过。
- 交付说明：结尾说明改了什么、为什么。

## 判断逻辑
评测目录测试统一用 `node --test` 运行 *.test.mjs，因此以此为回归口径。空文件被视为合法文件，只有上游错误信封（code !== 0）才算错误，避免把"空"误判为"缺失或失败"。用 fetcher 参数注入 HTTP 实现，测试可传桩、不依赖真实网络。

## 禁忌与反模式
- 吞掉上游错误：错误信封必须抛出 Error 并在 message 中带上信封的 message。
- 假定资源一定是文本：须按 data.encoding（utf-8 / base64）解码还原字节。
- 拼接 base 与子路径时产生双斜杠或漏斜杠。
- 把空内容当成缺失或错误：应返回零字节 Buffer。

## 关键事实依据
`fetchResource({ skillId, path, bridgeBase, fetcher })` 契约：成功返回资源原始字节 Buffer（调用方可直接写文件）；内容为空或缺 content 字段返回零字节 Buffer；错误信封抛错；fetcher 缺省 `globalThis.fetch`。skill-bridge 读取协议：`POST <bridgeBase>/files/read`，体 `{ skill_id, path }`，头 `content-type: application/json`、`x-tdai-service-id: default`；响应为标准信封 `{ code, message, request_id, data }`。新增测试全过，evaluation 全量 637 pass / 0 fail / 2 skipped。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`（fetchResource 实现）
- `evaluation/gate/fetch-resource.test.mjs`（5 条用例：按 encoding 解码返回 Buffer、空资源返回零字节 Buffer、错误信封抛带 message 的 Error、POST /files/read 请求参数、缺省 globalThis.fetch）

## 演化记录
（待积累）

## 待确认问题
（待积累）
