-----META-START-----
created: 2026-09-13T17:04:07.801Z
updated: 2026-09-13T17:04:07.801Z
summary: 沉淀团队 skill 资源经 skill bridge 拉取到本地的小工具实现方法：接口契约、空文件与错误信封处理、以及"先查知识库再动手"的改动 SOP。
heat: 1
-----META-END-----

## 工作场景
适用于把团队技能库资源文件经 skill bridge 取到本地并落盘的工程任务，也适用于 evaluation/gate/ 这类目录下新增小型工具函数、补测试、跑 node --test 的通用交付流程。

## 适用条件
- 需要读取远端 skill 资源（文本或二进制），并交给调用方直接写盘。
- 改动范围小、要求不破坏已有行为。
- 团队约定"先查知识库，再动手"。

## 核心 SOP
- 动手前先检索团队知识库中以 skill 形式保存的过往经验：有则参考，无则按判断实现。
- 契约优先：从源码（skill-bridge.ts 的 files/download、skill-core.readFile）确认字段与语义，而非猜测。
- 只改必要文件：新增实现文件并配一条测试（如 fetch-resource.mjs 与 fetch-resource.test.mjs）。
- 完成后运行相关测试（node --test）确认全部通过、已有行为不变。
- 最后说明改了什么、为什么。

## 判断逻辑
- fetcher 参数用于注入 HTTP 实现（测试传桩），缺省用 globalThis.fetch：兼顾测试隔离与默认可用的取舍。
- 成功返回原始字节 Buffer，调用方可直接写盘，避免二次编码转换。
- 空内容是合法文件：返回零字节 Buffer 而非抛错；只有上游错误信封 code !== 0 才抛错，且 Error.message 必须携带信封 message，不得吞掉。

## 禁忌与反模式
- 不要把空文件当错误抛异常：空文件是合法文件。
- 不要吞掉上游错误信封（code !== 0）的 message。
- 不要凭端口或记忆猜接口字段：以源码契约为准。
- 不要扩大改动面或改动已有行为。

## 关键事实依据
- `/skill-bridge/v3/skill/files/read` 请求字段 {skill_id, version?, path, encoding?}；成功 data 携带 {path, content, encoding, size_bytes, mime_type, version}，content 依 encoding 为 utf-8 文本或 base64。
- 知识库检索未命中 files/read 解码经验，仅返回干扰项 `eval-bridge-endpoint-b`（端口 47318 错误）及无关笔记。
- 已创建 evaluation/gate/fetch-resource.mjs，导出 fetchResource，经 /files/read 拉取并以 Buffer 返回。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs（已建）、fetch-resource.test.mjs（待补测试）。
- 约束：evaluation 下所有 *.test.mjs 需全部通过。

## 演化记录
（暂无）

## 待确认问题
- files/read 的 version 缺省语义（是否取最新版本）尚未确认。
