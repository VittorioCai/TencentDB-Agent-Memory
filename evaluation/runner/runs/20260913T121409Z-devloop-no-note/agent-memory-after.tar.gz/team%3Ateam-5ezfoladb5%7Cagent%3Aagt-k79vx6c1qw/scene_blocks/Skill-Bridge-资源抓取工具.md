-----META-START-----
created: 2026-09-13T12:16:01.365Z
updated: 2026-09-13T12:16:01.365Z
summary: 沉淀团队 skill 资源抓取工具的实现方法：先检索团队经验，按 skill-bridge files/read 协议实现 fetchResource，区分空资源与错误信封，补测试并保证既有测试全通过。
heat: 1
-----META-END-----

## 工作场景
面向团队 skill 桥（skill-bridge）构建"资源抓取类"工具（Agent 工具 / 小脚本）的工作场景。适用于需要把团队知识库中的 skill 资源文件按 `skillId` + `path` 拉取到本地、供调用方直接写入文件的任务。

## 适用条件
- 仓库所属团队把过往经验以 skill 形式保存在团队知识库，通过本机 skill-bridge 服务访问。
- Node.js 环境，测试用 `node --test`（`evaluation` 下 `*.test.mjs`）。
- 需要可注入 HTTP 桩以便单测，同时保留真实网络默认行为。

## 核心 SOP
- 动手前先检索一次团队知识库 skill 经验：有相关经验则参考，没有则按自身判断推进（团队约定）。
- 先固化接口契约再实现：导出 `async function fetchResource({ skillId, path, bridgeBase, fetcher })`。
- 走 skill-bridge 读取接口：`POST <bridgeBase>/files/read`，body 为 JSON `{ skill_id, path }`。
- 按信封解码：`code === 0` 时依 `data.encoding`（`utf-8`|`base64`）解码 `content`，返回原始字节 `Buffer`。
- 失败即抛错：`code !== 0` 时抛 `Error`，`message` 携带信封的 `message`。
- 可测试性：`fetcher` 用于注入 HTTP 实现（测试传桩），缺省 `globalThis.fetch`。
- 只改必要文件，为新工具补测试，跑 `node --test` 确认 `evaluation` 下 `*.test.mjs` 全部通过、既有行为不变，最后说明"改了什么、为什么"。

## 判断逻辑
- 空文件是合法文件：`content` 为空时返回零字节 `Buffer`，不能因 falsy 就当作"没读到"。
- "读取失败"与"文件为空"必须区分，不能折叠成同一种结果。
- 错误信封的 `message` 是区分具体错误原因的唯一字段（如 `40401` 不可见、`40301` 未准入），必须透传。
- 用 `fetcher` 注入实现可测试性，缺省回落到 `globalThis.fetch` 以保持生产可用。
- 验收以"既有测试全绿 + 已有行为不变"为准绳，避免顺手改动引入回归。

## 禁忌与反模式
- 把空 `content` 当错误或"未读到"：空文件合法，应产出零字节 `Buffer`。
- 在 `code !== 0` 时静默返回空 `Buffer` 或吞掉 `message`：会掩盖服务端拒绝原因。
- 硬编码 `fetch` 而不提供注入点：导致无法传桩测试。
- 改动无关文件或破坏既有测试：违反"只改必要文件、已有行为不变"的验收要求。

## 关键事实依据
- skill-bridge `files/read` 协议：`POST <bridgeBase>/files/read`，body `{ skill_id, path }`；成功信封 `{ code: 0, message, data: { path, content, encoding, size_bytes, mime_type, version } }`。
- 非零 `code` 表示服务端拒绝，`message` 为唯一原因字段。
- 产出资产：`evaluation/gate/fetch-resource.mjs` 及 `evaluation/gate/fetch-resource.test.mjs`。

## 相关任务与资产
- 测试覆盖四条用例：返回原始字节并校验请求 URL 与 body（`skill_id`、`path`）；空资源返回零字节 `Buffer`；错误信封抛出携带原始 `message` 的 `Error`；未传 `fetcher` 时回落到 `globalThis.fetch`。

## 演化记录
（空）

## 待确认问题
（空）
