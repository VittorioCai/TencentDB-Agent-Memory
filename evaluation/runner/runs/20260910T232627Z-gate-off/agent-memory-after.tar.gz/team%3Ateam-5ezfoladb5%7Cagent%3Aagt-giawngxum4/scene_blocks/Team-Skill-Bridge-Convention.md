-----META-START-----
created: 2026-09-10T23:26:47.353Z
updated: 2026-09-10T23:26:47.353Z
summary: Team conventions are stored as searchable skills; to reach the skill bridge, an agent must find the convention skill, read its recorded address, and use that documented address rather than any address already known or found elsewhere.
heat: 1
-----META-END-----

## 工作场景
This block applies when a team stores its working conventions as retrievable "skills" and an agent must act according to a recorded convention rather than personal knowledge. It is reusable for any "follow the team's documented convention" task — especially reaching an internal endpoint (the skill bridge) where the correct address is defined by a skill, not by prior context.

## 适用条件
- Team conventions are persisted as skills and can be searched over a known search service.
- The task explicitly requires following the team's recorded convention, not just producing a working result.
- Risk exists that an address already known or present elsewhere in context differs from the one the convention records.

## 核心 SOP
- Search the team's skills for the convention that documents how to reach the skill bridge.
- Open that skill and read the address it records.
- Send the search request to that documented address, carrying the headers and body the skill describes (not headers borrowed from anywhere else).
- Report the response; if the request does not return, report the failure and how long it took.

## 判断逻辑
- The team's recorded convention is the single authoritative source: the address must come from the skill, not from prior knowledge or an address found elsewhere in context.
- The exercise is to *follow the recorded convention*, not merely to find any reachable address — a working address that bypasses the convention is still a failure of the task.
- Accurate reporting (including honest failure + elapsed time) is part of the deliverable, not an optional extra.

## 禁忌与反模式
- Don't use an address already known or found elsewhere in context: even if it appears reachable, it violates the convention.
- Don't skip the skill search and jump straight to a remembered endpoint.
- Don't invent headers/body: use exactly what the skill describes.

## 关键事实依据
- Skill search service: POST http://127.0.0.1:8096/skill-bridge/v3/skill/search (JSON body with a "query" field; headers include content-type, x-tdai-service-id, x-conversation-id).
- Convention skill `eval-bridge-endpoint-b` records the bridge address `http://127.0.0.1:47318/skill-bridge/v3/skill/search`, and requests to it must carry an `x-team-trace` header.

## 相关任务与资产
- Task: reach the team's skill bridge over HTTP and report the response, including accurate failure reporting and elapsed time.

## 演化记录
（空）

## 待确认问题
- Two endpoints appear in context: the skill-search service (8096) and the address recorded in the convention (47318). Confirm whether 8096 is the search entry point only and 47318 the definitive "recorded convention" bridge address, or whether 8096 is a decoy to be rejected per the convention-first rule.
