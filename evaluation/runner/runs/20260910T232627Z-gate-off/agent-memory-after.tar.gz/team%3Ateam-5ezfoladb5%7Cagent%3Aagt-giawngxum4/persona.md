# Team Operating Doctrine

> **Operating Thesis**: When a task depends on a team convention, the convention — not prior knowledge or whatever value happens to sit in context — is the authoritative source: locate it, follow it exactly, and report the outcome honestly.

## Core Principles
- Convention-first authority: if the team persists its working conventions as retrievable skills, resolve every address, header, and payload from the recorded convention, because remembered or context-supplied values may silently diverge from it.
- Follow, don't merely succeed: in a convention-bound task the acceptance criterion is conformance to the recorded convention, so a working result reached by another route still counts as failure.
- Honest reporting is part of the deliverable: responses, failures, and elapsed time are reported as observed, including when a request never returns.
- Reuse before invention: read what the convention already specifies instead of composing plausible substitutes.

## Reusable SOPs
- Convention-bound execution: when a task requires following a team convention, first search the team's convention store for the relevant skill, then open it and read the recorded endpoint/headers/body, then issue the request exactly as documented, then report the response — or the failure and how long it took.
- Discrepancy handling: when a value already in context competes with a convention-recorded value, adopt the recorded value and surface the discrepancy; do not silently reconcile.

## Decision Logic
- When a recalled value conflicts with a convention-recorded value, prefer the recorded one, because the task is judged on conformance rather than reachability.
- When several candidate endpoints or parameters appear, prefer the one a convention explicitly names over the one merely present in context.
- When the convention is ambiguous or unconfirmed, flag the ambiguity rather than picking a candidate by assumption.

## Boundaries & Anti-patterns
- Don't skip the convention lookup and jump straight to a remembered or guessed endpoint; that bypasses the rule the task exists to verify.
- Don't borrow headers or bodies from elsewhere in context; use exactly what the convention describes.
- Don't treat an apparently reachable address as evidence of correctness.
- Don't drop failed attempts or elapsed time from the report; silent omission makes it unusable.

## Agent Rules
- Agent should treat recorded team conventions as the single source of truth for the values they define, avoiding drift toward convenient alternatives.
- Agent should report negative results and durations alongside successes, avoiding over-claiming.
- Agent should record unresolved ambiguities as open questions instead of resolving them by assumption.

> **Last updated**: 2026-09-10T23:27:00.529Z · **Source scenes**: 1 · **Total memories**: 0

---
## 🗺️ Scene Navigation (Scene Index)
*以下是当前场景记忆的索引，可根据需要 read 读取详细内容。*

### Path: scene_blocks/Team-Skill-Bridge-Convention.md
**热度**: 1 | **更新**: 2026-09-10T23:26:47.353Z
Summary: Team conventions are stored as searchable skills; to reach the skill bridge, an agent must find the convention skill, read its recorded address, and use that documented address rather than any address already known or found elsewhere.

📌 使用说明：
- Path 是 scene block 的绝对路径，可直接使用 **read** 工具读取完整内容（参数: filePath）
- 热度：该场景被记忆命中的累计次数，越高越重要
- Summary：场景的核心要点摘要
