-----META-START-----
created: 2026-09-13T18:53:21.910Z
updated: 2026-09-13T18:53:21.910Z
summary: 团队在仓库内开发小工具时的通用方法：先检索团队经验 skill，再按接口契约实现、测试、最小改动交付，并保留错误信息不吞掉。
heat: 1
-----META-END-----

## 工作场景
适用于在该仓库所属团队中开发/改造代码类小工具的协作场景，尤其是需要访问团队知识库（skill）资源的工具，例如 evaluation/gate 下新增资源拉取工具。可复用于任何"检索团队经验 → 按契约实现 → 测试验收 → 交付说明"的开发链路。

## 适用条件
- 处理对象：仓库内的代码任务，改动集中在 evaluation 等工具目录。
- 前置资源：团队把过往经验以 skill 形式存放于知识库，可通过 skill-bridge 检索与读取。
- 交付约束：需保证已有行为不变、现有测试全绿，且只改必要文件。

## 核心 SOP
- 动手前先检索一次团队经验：有相关 skill 就参考后执行；没有则按自身判断实现。原因：避免重复踩坑，复用已验证方案。
- 按显式接口契约实现：函数签名、参数、返回值、错误行为以任务给定规格为准（见关键事实依据的 fetchResource 契约）。
- 最小改动：只修改必要文件，不顺手重构无关代码。
- 测试验收：用 `node --test` 跑 evaluation 下全部 `*.test.mjs`，确保现有测试通过且行为不变；为新增工具补一条测试。
- 注入式设计：外部依赖（如 HTTP）通过参数注入，测试传桩、缺省回退到 `globalThis.fetch`。
- 交付说明：最后说明改了什么、为什么改。

## 判断逻辑
- 团队经验优先于个人判断：先检索再动手，降低返工风险。
- 可测试性优先：依赖注入让逻辑可被桩替换，测试无需真实网络。
- "空文件是合法文件"：空资源返回零字节 Buffer 而非报错，避免把正常空内容误判为失败。
- 最小暴露原则：只改必要文件、保持既有行为，缩小回归面。
- 错误不可静默：上游错误信封（code !== 0）必须抛出并保留 message，便于定位问题。

## 禁忌与反模式
- 不检索团队经验直接动手：可能重复已有方案的坑。
- 吞掉上游错误：错误信封必须抛出，message 不得丢失。
- 把空资源当错误：空内容是合法的零字节 Buffer。
- 顺手改动无关文件或改变已有行为：违反最小改动与行为不变要求。
- 新增工具不补测试：验收要求新工具至少有一条测试。

## 关键事实依据
- fetchResource 契约：`export async function fetchResource({ skillId, path, bridgeBase, fetcher })`，位于 evaluation/gate/fetch-resource.mjs；成功返回资源原始字节 Buffer（可直接写文件），空内容返回零字节 Buffer，上游 code !== 0 时抛 Error 并带信封 message，fetcher 缺省用 globalThis.fetch。
- 相关经验 skill：skill_id `skl-oBaDO5CceKnr`（经 skill-bridge /skill/get 拉取），可作为实现参考。
- skill-bridge 接口：读取资源用 `POST /skill-bridge/v3/skill/files/read`，体 `{ skill_id, path, encoding }`（encoding 可 base64），带 `x-tdai-service-id`、`x-conversation-id` 请求头；元信息用 `POST /skill-bridge/v3/skill/get`（include_content、include_manifest）与 `POST /skill-bridge/v3/skill/search`（按 query）。

## 相关任务与资产
- 待实施：新增 evaluation/gate/fetch-resource.mjs 及其测试。
- 参考资产：团队经验 skill `skl-oBaDO5CceKnr`。

## 演化记录
（空）

## 待确认问题
- bridgeBase 缺省值 / 目标服务地址（当前仅给出 127.0.0.1:8096 示例路径）如何配置，尚未明确。
