-----META-START-----
created: 2026-09-13T18:54:04.081Z
updated: 2026-09-13T18:54:04.081Z
summary: 团队开发任务通用SOP：动手前检索团队skill经验库、只改必要文件、跑测试并说明改动；含fetchResource资源拉取工具的接口契约与files/download选择逻辑。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库（含 evaluation/gate 等模块）的开发任务，尤其是新增小工具或 helper 的实现。核心可复用点：把「先检索团队 skill 经验库 → 参考或自行判断 → 最小改动实现 → 跑测试验证 → 说明改动」作为标准开发闭环；并沉淀「把团队 skill 资源文件取到本地」这类远程资源拉取工具的接口与行为契约。

## 适用条件
- 团队把过往经验以 skill 形式存于知识库；仓库内开发任务动手前应先检索一次。
- 新增工具类改动，要求保持已有行为不变、只改必要文件。
- 测试以 node --test 运行 evaluation 下 *.test.mjs。
- 需要注入 HTTP 实现以便测试传桩（fetcher 参数）。

## 核心 SOP
- 动手前检索团队经验：先查知识库是否有相关 skill，有则参考，无则按自身判断执行，避免重复踩坑。
- 只改必要文件：改动面越小越能保证已有行为不变、便于 review。
- 实现后跑相关测试：node --test 跑 evaluation 下所有 *.test.mjs，确认现有测试全部通过。
- 收尾说明：讲清改了什么、为什么，让评审可追溯决策依据。

## 判断逻辑
- 资源拉取应走 skill-bridge 的 files/download 子路径（返回解码后的原始字节），不要用 files/read——后者把 payload 包进 JSON 信封，直接保存响应体会存成信封而非真实文件。这正是 fetchResource 需写成 helper 而非一行 fetch 的原因。
- 空资源是合法文件：files/download 对合法空资源返回 content 为空字符串的信封，应把空 content 解码为零字节 Buffer，只有 content 缺失或非字符串才视为错误。
- 错误不得吞掉：上游返回错误信封（code !== 0）应抛出 Error 并携带信封 message，保证调用方感知失败。
- 用 fetcher 参数注入 HTTP 实现，缺省 globalThis.fetch，兼顾生产默认与测试可替换性。

## 禁忌与反模式
- 不要用 files/read 拉取资源体并直接落盘：会把 JSON 信封存成文件。
- 不要把空 content 当错误：空文件合法，应返回零字节 Buffer。
- 不要静默吞掉上游错误信封：必须抛出并保留 message。
- 不要在未经检索时重复造轮子：团队已有相关 skill 应先复用。
- 不要顺手改动无关文件或改变已有接口行为。

## 关键事实依据
- 相关团队 skill：skill 资源下载经验（skl-XAzqAgejM7O4）、skill-bridge endpoint（skl-oBaDO5CceKnr）；笔记 eval-skill-resource-download（trace bt-pu6nyfhmu2v）。
- fetchResource 接口：export async function fetchResource({ skillId, path, bridgeBase, fetcher })；成功返回原始字节 Buffer（可直接写文件）；空资源返回零字节 Buffer；错误信封抛 Error 并携带 message。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs：已实现，走 files/download，处理错误信封与空资源。
- evaluation/gate/fetch-resource.test.mjs：覆盖原始字节返回、空资源零字节、错误信封抛错、base64 解码、fetcher 缺省为 globalThis.fetch。

## 演化记录
（暂无）

## 待确认问题
（暂无）
