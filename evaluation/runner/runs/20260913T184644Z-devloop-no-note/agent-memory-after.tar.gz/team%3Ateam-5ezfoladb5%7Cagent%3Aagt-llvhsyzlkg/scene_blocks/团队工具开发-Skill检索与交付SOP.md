-----META-START-----
created: 2026-09-13T17:09:47.393Z
updated: 2026-09-13T18:31:45.000Z
summary: 沉淀团队工具开发方法：动手前先检索团队 skill 经验、资源下载类工具的接口契约（Buffer/空文件合法/错误信封抛出/fetcher 注入/base64 还原）、bridge 取资源走 files/download 的正确姿势及已知缺陷应对与交付验收口径。
heat: 4
-----META-END-----

## 工作场景
适用于在团队仓库中新增工具/模块类任务的开发场景，典型如"把团队 skill 资源文件取到本地"这类带外部 HTTP 依赖的小工具。可复用点：开发前置检索、接口契约设计、字节语义约定、外部接口选型与缺陷规避、交付验收口径。

## 适用条件
- 仓库所属团队把过往经验以 skill 形式沉淀在团队知识库中。
- 任务为新增独立工具文件，边界清晰，且要求保持既有行为不变。
- 存在外部依赖（如 HTTP）需要可注入以便隔离测试。
- 资源内容可能是原始字节、空文件或 base64 编码文本。

## 核心 SOP
- 先检索团队经验一次：有相关 skill 就参考执行，没有则按自身判断实现；避免重复踩坑并保持与团队沉淀一致。
- 先定接口契约再动手：入参、返回值形态、异常语义、可注入依赖都要明确。
- 取资源走 skill-bridge 的 `files/download`（POST）：它直接返回资源原始字节，适配任意 mime type。
- 实现时只改必要文件，保证已有行为不变。
- 为新增工具补测试（覆盖成功/空资源/base64/错误信封四类场景），运行 `node --test` 使 evaluation 下全部 `*.test.mjs` 通过。
- 完成后说明改了什么、为什么，便于评审与后续复用。

## 判断逻辑
- 团队沉淀优先于个人判断：仅当无相关经验时才自由发挥。
- 依赖注入 `fetcher` 缺省用 `globalThis.fetch`：测试可传桩隔离真实网络，兼顾生产默认行为。
- 以"资源原始字节"作为返回形态（Buffer）：让调用方直接落盘，工具不做额外解析或包装；base64 内容须先解码还原为原始字节。
- 空内容仍是合法资源，用零字节 Buffer 表达"成功但为空"，与错误路径严格区分。
- 对上游已知缺陷做兼容：bridge 当前会把空资源误判为失败，返回 `data.content === ""` 的 JSON 信封。故信封中空但存在的 content 字符串应按正常资源解码为零字节 Buffer；只有 content 缺失或非字符串才视为错误。

## 禁忌与反模式
- 不要把空资源当错误：空文件是合法文件，必须返回零字节 Buffer，不得抛异常或返回 null 等空值。
- 不要吞掉上游错误：收到错误信封（code !== 0）时必须抛出 Error，且 message 携带信封的 message。
- 不要用 `files/read` + `curl -o` 保存资源：`-o` 是客户端 curl 参数，bridge 无法感知，会把 JSON 信封写进文件；应改用 `files/download` 取原始字节。
- 不要把 base64 文本当原始字节直接返回：需解码后再交付。
- 不要改动无关文件或破坏既有测试；不要跳过团队经验检索直接开工。

## 关键事实依据
- 相关团队 skill/笔记：eval-skill-resource-download（skl-XAzqAgejM7O4）、eval-bridge-endpoint-b（skl-oBaDO5CceKnr）。
- 目标工具：`evaluation/gate/fetch-resource.mjs`，导出异步函数 `fetchResource({ skillId, path, bridgeBase, fetcher })`。
- bridge `files/download` 两形态：成功 → 原始字节（不限 mime type）；拒绝/格式错误 → code !== 0 的 JSON 错误信封（bridge 原样透传 core 错误）。
- 测试 `evaluation/gate/fetch-resource.test.mjs`：POST 下载原始字节、空资源零字节 Buffer、base64 解码还原、错误信封抛 Error 带原 message。

## 相关任务与资产
- 已完成：`evaluation/gate/fetch-resource.mjs` 实现与对应测试文件。
- 交付口径：只改必要文件，改完运行 evaluation 下全部 `*.test.mjs` 确认通过，并说明改动与原因。

## 演化记录
- [2026-09-13]：补充 base64 内容需解码还原；确认取资源走 POST `files/download` 而非 `files/read`+`curl -o`；新增 bridge 空资源误判缺陷的兼容规则（空 content 字符串按零字节资源解码）；工具与测试由"待办"转为"已完成"。

## 待确认问题
- bridge 空资源误判缺陷是否会在上游修复；若修复，兼容分支是否保留待定。
