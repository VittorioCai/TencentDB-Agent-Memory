-----META-START-----
created: 2026-09-13T18:13:30.629Z
updated: 2026-09-13T18:28:45.602Z
summary: 沉淀本仓库内"先检索团队 skill 经验、按 bridge 契约实现取数工具、最小改动加全量回归验收"的可复用工程约定、契约细节与禁忌。
heat: 3
-----META-END-----

## 工作场景
适用于本仓库（evaluation / gate 工具链）的功能新增与修改任务，尤其适用于 Agent 或成员在动手前须先查团队经验、按既定接口契约实现、并按固定标准交付验收的场景。可复用于任何"新增取数/桥接类工具并补测试"的同类任务。

## 适用条件
任务会改动 evaluation 目录；团队经验已以 skill 形式存于知识库；skill 资源由 bridge 提供；改动需可回归验证且不得影响既有行为。

## 核心 SOP
- 先检索再动手：实现前检索一次团队知识库中的 skill 经验，有则参考，无则按自身判断实施。
- 先定契约再写实现：固定导出签名与返回语义后再落代码，如 `fetchResource({ skillId, path, bridgeBase, fetcher })`。
- 明确依赖注入：`fetcher` 注入 HTTP 实现（测试传桩），缺省 `globalThis.fetch`；`bridgeBase` 由调用方传入，不硬编码。
- 请求按调用方需求选编码：向 bridge 请求 `base64` 以取回原始字节，避免 `utf-8` 破坏非文本资源。
- 最小改动：只改必要文件，不做无关重构。
- 补齐测试：新工具至少一条测试，覆盖成功、空资源、错误信封三类路径。
- 交付前自验：`node --test` 跑 evaluation 下 `*.test.mjs`，确认全过且既有行为不变；收尾说明改了什么、为什么。

## 判断逻辑
- 取原始字节而非文本：向 bridge 请求 `base64` 编码，因为调用方需要原始字节落盘，`utf-8` 会破坏非文本内容。
- 空文件是合法文件：`data.content` 为空必须映射为零字节 Buffer，而非报错或视为缺失，否则调用方无法区分"空"与"失败"。
- 错误必须外抛：上游 `code !== 0` 时抛 Error 并原样携带信封 message，不吞错误，让调用方掌握失败原因。
- 回归优先于新增：将"既有测试全过 + 行为不变"作为硬底线，因为破坏面代价大于新功能缺失。

## 禁忌与反模式
- 不检索团队经验就直接实现：重复已沉淀的错误做法。
- 用空 Buffer 表达失败或吞掉错误：故障被静默掩盖，调用方无法区分空文件与失败。
- 把空资源当作缺失资源报错：混淆"合法零字节文件"与"读取失败"。
- 请求 utf-8 而非 base64：非文本资源被破坏。
- 硬编码 bridgeBase：丧失可配置性与可测性。
- 测试直打真实网络：应经 `fetcher` 传桩，否则不稳定、不可重复。
- 顺手做无关重构 / 跳过自验与改动说明：放大回归风险、无法追溯。

## 关键事实依据
- bridge 契约：`POST <bridgeBase>/files/read`，体 `{ skill_id, path, encoding }`，响应信封 `{ code, message, data }`；`data.content` 为文件字节，空资源表现为空字符串（合法零字节文件）；非零 code 表示上游拒绝（如 path 不在 manifest、资源不可见）。
- 返回语义：成功 → 原始字节 Buffer；资源为空 → 零字节 Buffer；上游错误 → 抛出携带信封 message 的 Error。
- 测试基线：新增前 evaluation 下为 637 pass / 0 fail；测试覆盖原始字节、空资源零字节、bridgeBase 末尾斜杠不重复、utf-8 资源按文本解码、错误信封抛出、fetcher 默认 `globalThis.fetch`。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`（实现）与 `evaluation/gate/fetch-resource.test.mjs`（测试）已交付；验证命令 `node --test`。

## 演化记录
- [2026-09-13]：待确认的 bridge 协议与 path 拼接规则已明确——bridge 走 `POST /files/read` 信封协议，bridgeBase 拼接需处理末尾斜杠避免重复。
- [2026-09-13]：明确空资源语义——`data.content` 为空字符串是合法零字节文件，须返回零字节 Buffer 而非报错。

## 待确认问题
（暂无）
