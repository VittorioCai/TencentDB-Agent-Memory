-----META-START-----
created: 2026-09-13T18:09:51.983Z
updated: 2026-09-13T18:09:51.983Z
summary: 沉淀 evaluation/gate/fetch-resource 工具的接口契约与实现要点：走 bridge 下载子路径、按字节读取一次、区分信封与原始字节，并处理空文件与错误边界。
heat: 1
-----META-END-----

## 工作场景
适用于在 evaluation 环境下新增"从 skill bridge 取回团队 skill 资源文件"的工具或调用逻辑。凡涉及把远端资源落到本地原始字节（脚本、二进制、空文件）的任务，都可复用本文件的接口契约与边界处理经验。

## 适用条件
- 调用 skill bridge 的资源下载能力，需要拿到可写盘的原始字节，而非 JSON 元数据。
- 需为工具写单测，且 HTTP 实现要可注入（测试传桩）。
- 上游可能返回信封（含 code）或直接返回原始下载字节，两种形态都要兼容。

## 核心 SOP
- 走下载专用子路径：原始字节的下载子路径是 `skill-bridge/v3/skill/files/download`，并导出常量 `DOWNLOAD_SUBPATH`，不要用 `files/read`。原因：bridge 按子路径分发，`files/read` 恒返回 JSON 信封。
- 响应只按字节读取一次，再统一判断形态，避免重复消费流。
- 分支处理：信封 `code !== 0` → 抛 `Error` 且 message 带上信封 message，不得吞掉；信封 `code === 0` → 解码 `data.content`（允许为空）；非信封 → 直接返回原始下载字节。
- 成功统一返回 `Buffer` 交给调用方写盘；导出签名 `fetchResource({ skillId, path, bridgeBase, fetcher })`。
- 注入式 HTTP：`fetcher` 用于注入实现（测试传桩），缺省用 `globalThis.fetch`，保证可测。

## 判断逻辑
- 为何要原始字节：`files/read` 的响应体直接存盘会得到 JSON 文件而非目标脚本，`curl -o` 也改不了，必须选对子路径。
- 为何空内容单独处理：空文件是合法文件，Core 的 `skillResourcePayloadSchema` 中 content 保持 `z.string()`（未加 `.min(1)`），不能当错误。
- 为何保留错误信封 message：便于调用方定位上游失败，避免静默失败。

## 禁忌与反模式
- 用 `files/read` 取原始字节／把其 JSON 信封直接写盘：会得到错误的文件内容。
- 吞掉 `code !== 0` 的错误：掩盖上游故障；应抛出并携带信封 message。
- 因内容为空而报错或回传信封：空文件合法，应为零字节 Buffer。
- 直接硬编码 `globalThis.fetch`：破坏可测性；应通过 `fetcher` 注入。

## 关键事实依据
- 团队知识库笔记 `eval-skill-resource-download`（skl-XAzqAgejM7O4）与 `eval-bridge-endpoint-b`（skl-oBaDO5CceKnr）被检索并作为实现参考。
- proxy 的 download 分支仍以 `!parsed.data?.content` 判断，导致空文件会返回整个信封而非 0 字节；调用方需按 `code === 0` 的信封处理空内容。

## 相关任务与资产
- 交付资产：`evaluation/gate/fetch-resource.mjs`（导出 `fetchResource`、`DOWNLOAD_SUBPATH`），并补一条单测。
- 验收：`evaluation` 下 `*.test.mjs` 全部通过（`node --test`），已有行为不变。

## 演化记录
（空）

## 待确认问题
- 契约要求"资源内容为空时返回零字节 Buffer"，但 proxy download 分支对空文件会返回整个信封（`code === 0`、content 缺失/空）。需确认实现是解码空 content 得零字节，还是对 `code === 0` 空信封统一映射为零字节 Buffer。
