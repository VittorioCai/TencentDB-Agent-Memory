-----META-START-----
created: 2026-09-13T17:22:43.398Z
updated: 2026-09-13T18:29:47.801Z
summary: 团队在 evaluation/gate 下新增 Node 工具（如 fetchResource）的可复用方法：先检索团队经验，再固化行为规格，经 bridge 信封取资源、参数化配置并补测试，保持既有行为不变。
heat: 3
-----META-END-----

## 工作场景
适用于团队在仓库工具目录（如 evaluation/gate/）新增 Node.js 工具（.mjs）并为 skill 资源读取/桥接编写实现与测试的场景。沉淀可复用方法：检索团队经验 → 固化行为规格 → 探查接口契约 → 实现 → 补测试 → 验证不破坏现有行为。

## 适用条件
- 通过 skill bridge（HTTP 桥，v3）读取团队 skill 的资源文件（.mjs 工具）。
- 使用 `node --test` 运行 evaluation 下 `*.test.mjs`。
- 约束：任意二进制与空资源都要能正确往返；只改必要文件；现有测试与已有行为不得改变。
- 团队要求：本仓库所属团队把过往经验以 skill 形式保存在团队知识库中。

## 核心 SOP
1. 动手前先检索一次团队知识库中的 skill 经验：有相关经验则参考，没有则按自己的判断做；这是团队对本仓库的硬性前置要求（本次已参考 skill bridge skill `skl-oBaDO5CceKnr`）。
2. 先把行为规格写清楚再实现（返回值、空值、错误、可注入点），避免边写边猜。
3. 探查接口契约：用 `skill/get` 看候选 skill 的 manifest，用 `skill/files/read` 分别探测文件不存在（如 nope.md）与 skill 缺失（如 skl-000000）两种错误信封形状，再据此实现。
4. 通过 bridge `/files/read` 发 POST，body 含 `skill_id`、`path`、`encoding: base64`，解析标准信封 `{code, message, request_id, data?}`。
5. 成功时按 `data.encoding` 解码返回原始字节 Buffer，调用方可直接写入文件；签名 `fetchResource({ skillId, path, bridgeBase, fetcher })`。
6. 为新增工具补一条测试，覆盖规格中的各分支场景。
7. 收尾验证：`node --test` 下现有测试全部通过、已有行为不变，只改必要文件，并说明改了什么、为什么。

## 判断逻辑
- 请求 `encoding: base64`：utf-8 读取会静默损坏二进制资源，base64 让任意二进制原样往返。
- 空资源返回零字节 Buffer 而非报错：空文件是合法文件，报错会把合法空文件误判为缺失。
- 错误信封必须抛错：`code !== 0` 时抛 Error 且 message 携带信封自身 message，不吞掉上游信息。
- `fetcher` 参数注入 HTTP 实现，测试传桩；缺省 `globalThis.fetch`，实现与真实 IO 解耦。
- `bridgeBase` 参数化 bridge 地址：团队 skill 指向的 bridge 端口与本地部署不同，硬编码端口会取不到资源，应由调用方决定。

## 禁忌与反模式
- 用 utf-8 读取二进制资源：会静默损坏内容，必须走 base64。
- 把空资源当缺失处理：误报错误，应返回零长度 Buffer。
- 吞掉上游错误信封的 message：丢失排障信息，必须透传。
- 硬编码 bridge 端口/地址：跨环境会失效，应经 `bridgeBase` 传入。
- 未检索团队经验就直接动手：违背团队约定。
- 顺手改动无关文件或改动既有行为：扩大影响面，只改必要文件。

## 关键事实依据
- 资产 `evaluation/gate/fetch-resource.mjs`：导出 `fetchResource`，向 bridge `/files/read` POST（含 skill_id、path、encoding: base64），成功按 data.encoding 解码返回 Buffer，`code !== 0` 抛携带上游 message 的 Error。
- 测试 `evaluation/gate/fetch-resource.test.mjs` 覆盖：原始字节返回且请求 base64、空资源返回零字节 Buffer、utf-8 应答按 utf-8 解码、错误信封抛错携带上游 message、fetcher 缺省使用 `globalThis.fetch`。
- 参考 skill：团队知识库中的 skill bridge skill（id `skl-oBaDO5CceKnr`）。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs、evaluation/gate/fetch-resource.test.mjs。

## 演化记录
- [2026-09-13]：明确 bridge 地址必须经 `bridgeBase` 参数传入、不得硬编码端口，原因：团队 skill 指向的 bridge 端口与本地部署不同。

## 待确认问题
- 资源确实不存在时 bridge 返回何种 code/message，工具是否需区分"缺失"与"空"（正通过 `skill/files/read` 探测错误信封形状）。
