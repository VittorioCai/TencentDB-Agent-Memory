-----META-START-----
created: 2026-09-13T17:23:30.517Z
updated: 2026-09-13T18:23:41.890Z
summary: 团队 skill 资源拉取工具的实现契约、空文件与错误信封陷阱，以及"动手前先检索团队 skill 经验"的协作约定与交付验证要求。
heat: 2
-----META-END-----

## 工作场景
适用于本仓库 evaluation 链路中新增/修改工具函数的任务，尤其是与 skill bridge 交互、需要把团队 skill 资源取回本地的场景。核心可复用资产是"团队经验检索约定 + 接口契约先于实现 + 基线对照验证"这套做法。

## 适用条件
仓库内评审门（evaluation/gate/）新增工具、涉及上游 bridge 接口对接、需要保证既有测试行为不变的改动。团队已有把经验沉淀为 skill 的惯例，因此任何动手前都适用。

## 核心 SOP
- 先检索一次团队知识库：团队约定动手前先检索 skill 经验，有相关 skill 就参考，没有则按自身判断实现；本次相关 skill 为 `eval-skill-resource-download`（skill_id: skl-XAzqAgejM7O4，tracker bt-pu6nyfhmu2v）。
- 先确认任务边界再动手：实现前确认任务是否附带隐藏说明；本次确认无隐藏说明，团队 skill 经验即为决定性参考依据，据此定稿实现路径与信封处理逻辑。修改信封处理逻辑前应先查阅相关 skill。
- 先锁定接口契约再编码：`evaluation/gate/fetch-resource.mjs` 导出 `fetchResource({ skillId, path, bridgeBase, fetcher })`，经 POST 调 bridge 的 files/read 读取资源，再把信封解码为原始字节。
- 契约逐条对齐：成功返回原始字节 Buffer（调用方可直接写盘）；空内容返回零字节 Buffer；`code !== 0` 抛 Error 且 message 原样带上信封 message；`fetcher` 用于注入 HTTP 桩，缺省 `globalThis.fetch`。
- 先跑基线再改动：改动前记录 evaluation/gate 测试基线（41 通过 / 2 跳过），作为改动前后对照。
- 补测试 + 全量回归：为新增工具补测试（本次 `fetch-resource.test.mjs` 6 条用例），并 `node --test` 跑 evaluation 下全部 `*.test.mjs` 确认通过且已有行为不变。
- 只改必要文件，最后说明改了什么、为什么。

## 判断逻辑
改动价值以"可验证的行为契约"衡量：契约条款（空文件、错误信封、依赖注入）对应的是失败模式，不是风格偏好，因此测试要逐条覆盖而不是笼统跑通。团队经验检索被设为前置动作，因为本仓库的坑位（空文件误判、错误 message 被吞）已被前人以 skill 形式固化，复检成本远低于重踩；当任务未附带隐藏说明时，skill 经验即为决定性依据而非可选参考。既有测试行为不变优先于新增功能便利性，避免为省事改动共享代码路径。

## 禁忌与反模式
- 不要用 `!data?.content` 判空：bridge 自身 files/download 分支就因此把空文件误判为"无内容"并回退返回整个信封，新工具必须避开。
- 不要把空资源（`data.content === ""`）当错误：空文件是合法文件，只有 content 缺失或非字符串才算错。
- 不要吞掉上游错误信封的 message：`code !== 0` 必须抛 Error 并原样携带。
- 不要顺手改无关文件或重构共享逻辑：会破坏既有行为。
- 不要只跑新测试就宣称完成：必须全量 `*.test.mjs` 回归。

## 关键事实依据
bridge files/read 始终返回 `{code, message, data}` JSON 信封（即使请求下载），字节在 `data.content`，编码由 `data.encoding` 标识（utf-8 / base64）。基线 41 通过 / 2 跳过；6 条新用例覆盖 utf-8 解码、base64 还原、空资源零字节、错误信封透传、成功信封缺 content 报错、缺省 fetcher。

## 相关任务与资产
`evaluation/gate/fetch-resource.mjs`（新增）、`evaluation/gate/fetch-resource.test.mjs`（6 用例，已通过）、skill `eval-skill-resource-download`。

## 待确认问题
完整 evaluation 测试套件（含既有 `*.test.mjs`）是否已全部跑通、达到与基线一致的通过/跳过数。
