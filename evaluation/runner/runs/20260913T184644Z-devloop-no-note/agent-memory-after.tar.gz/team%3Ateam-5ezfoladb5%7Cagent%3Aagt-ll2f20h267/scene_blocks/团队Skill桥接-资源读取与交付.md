-----META-START-----
created: 2026-09-13T17:29:05.988Z
updated: 2026-09-13T17:35:51.349Z
summary: 团队经验 skill 的检索约定、skill 桥接 resources 读取路径（files/download vs files/read）取舍、空资源与错误信封处理原则，以及新增 gate 工具补测试交付规范。
heat: 2
-----META-END-----

## 工作场景
适用于在团队知识库驱动的仓库中开发与维护 skill 桥接（bridge）相关代码的场景：Agent 需要先检索团队经验再动手、需要从 bridge 读取/落盘 skill 资源、需要为新工具（如 evaluation/gate 下的模块）补写测试并交付。方法可复用到任何"经验以 skill 形式沉淀 + 工具需访问资源并保证测试覆盖"的工程任务。

## 适用条件
- 仓库所属团队把过往经验以 skill 形式保存在团队知识库，且提供 bridge 读取接口。
- 任务涉及资源下载、字节级落盘、错误信封解析等易被误解的接口语义。
- Agent 需在无人指导时自行决定实现路径，但基线是"先查团队经验"。

## 核心 SOP
- 任务前置检索&#58; 执行任务前先检索一次团队经验 skill；有相关经验就参考，没有才自行判断——避免重复踩坑，也避免无依据地照搬。
- 落盘用 download&#58; 需要把文件写入本地时必须走 `files/download`；`files/read` 始终返回 JSON 信封，不能用于取原始字节。
- 空资源按合法处理&#58; 资源内容为空仍是合法文件；`files/download` 的成功判断用 `!parsed.data?.content`，空字符串为 falsy，空资源会返回完整 JSON 信封，此时应解码 `data.content`（零长度解码为零字节），不可当成错误。
- 错误只在真错时抛&#58; 仅 `code` 非零，或 payload 缺失/类型错误，才算错误；抛出时原样携带信封 `message`，不吞掉。
- 新工具补测试并回归&#58; 为新增模块补测试后，在 `evaluation` 目录下运行 `node --test`，确保现有测试全部通过、已有行为不变。
- 最小改动交付&#58; 只改必要文件，最后说明改动内容与原因。

## 判断逻辑
两条读取路径不可互换，是接口设计语义决定的：`files/read` 返回统一 JSON 信封、`files/download` 返回资源原始字节。曾有人以为可用 `curl -o` 保存文件，但 `-o` 是客户端标志、服务端看不到，因此不能改变返回形态——判断"能否落盘"要看服务端接口语义，而非客户端命令选项。空资源之所以不能当错误，是因为 falsy 判断把"空"与"缺失"混同；正确口径是把零字节内容解码为合法结果，只有 code/payload 层面异常才是错误。测试与回归是新增工具的可信度来源：先证明原始字节、base64、空资源、错误信封、畸形信封、fetcher 缺省等分支都成立。

## 禁忌与反模式
- 用 `files/read` 取字节或依赖 `curl -o` 落盘&#58; 前者返回信封、后者选项服务端不可见，都会失败；改用 `files/download`。
- 把空资源当作错误抛出&#58; 会误报合法文件；应解码 `data.content`。
- 吞掉或改写信封 `message`&#58; 丢失上游错误语义；应原样抛出。
- 只加功能不补测试、或改完不跑全量 `node --test`&#58; 无法保证已有行为不变。
- 顺手重构无关文件&#58; 扩大改动面，违反最小改动交付要求。

## 关键事实依据
- 结论来自团队经验 skill `eval-skill-resource-download`（token `bt-pu6nyfhmu2v`）；该 skill 已在团队知识库中按 `skill_id: skl-XAzqAgejM7O4` 检索并作为实现参考。
- 新增工具 `evaluation/gate/fetch-resource.mjs`：导出 `fetchResource({ skillId, path, bridgeBase, fetcher })`；成功返回原始字节 Buffer（可直接写文件），空资源返回零字节 Buffer，上游错误信封（code !== 0）抛出携带信封 message 的 Error；`fetcher` 用于注入 HTTP 实现，缺省 `globalThis.fetch`；调用路径 `${bridgeBase}/files/download`，请求体 `{ skill_id, path }`。
- 测试文件 `evaluation/gate/fetch-resource.bt-pu6nyfhmu2v.test.mjs` 覆盖：原始字节原样返回、空资源信封解码为零字节、base64 信封解码、错误信封抛信封 message、code 为 0 但缺失或非字符串 content 视为畸形、fetcher 缺省用 `globalThis.fetch`。

## 相关任务与资产
- 任务&#58; 为 `evaluation/gate/fetch-resource.mjs` 补测试，在 `evaluation` 下跑 `node --test` 验证全绿。
- 资产&#58; `eval-skill-resource-download`（团队经验 skill）、`evaluation/gate/fetch-resource.mjs`、同名 `.test.mjs`。

## 演化记录
（无）

## 待确认问题
- 空资源返回零字节与"文件确实为空"如何在上层区分，是否需要额外元数据标志。
- `bridgeBase` 与 `skillId` 的取值约定（多环境/多知识库）尚未记录。
