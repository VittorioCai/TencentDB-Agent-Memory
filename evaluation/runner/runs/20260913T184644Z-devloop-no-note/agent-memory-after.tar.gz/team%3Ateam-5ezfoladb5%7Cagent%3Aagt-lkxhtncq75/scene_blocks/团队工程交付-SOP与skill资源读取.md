-----META-START-----
created: 2026-09-13T18:01:13.415Z
updated: 2026-09-13T18:01:13.415Z
summary: 本仓库团队工程交付SOP：先检索skill经验、改前跑基线、只改必要文件、补测试后跑全量node --test并说明改动；附skill-bridge资源读取协议与fetchResource行为契约。
heat: 1
-----META-END-----

## 工作场景
适用于本仓库（含 evaluation 评测链路）的代码交付任务，尤其是新增工具/模块且要求"已有行为不变"的改动；也适用于需要把团队知识库 skill 的资源文件取到本地的场景。

## 适用条件
- 团队过往经验以 skill 形式存于团队知识库，仓库任务由 Agent 执行。
- 任务要求新增或修改代码，并保持现有行为不变。
- 评测相关测试以 `node --test` 运行 evaluation 目录下的 `*.test.mjs`。

## 核心 SOP
- 检索经验优先：动手前先检索一次团队经验，有相关 skill 就借鉴，没有则按自身判断执行——避免重复踩坑。
- 改前先建基线：先跑 `node --test evaluation/` 确认当前测试状态（本次基线为 637 pass、0 fail、2 skipped），作为"行为不变"的对照。
- 最小改动：只改必要文件；新增工具时为其补一条针对新行为的测试，不顺手改无关文件。
- 改后全量验证：运行相关测试及 evaluation 下全部 `*.test.mjs` 确认通过，保证已有行为不变。
- 收尾说明：明确交付"改了什么、为什么"，让评审可核对意图。

## 判断逻辑
- 经验检索先于实现：团队知识库是群体复用资产，先查再写能减少返工。
- 以测试结果定义"行为不变"：用改动前后的 pass/fail/skipped 对照，量化而非口头声明。
- 工具契约先定、测试后随：行为边界（返回值、错误、注入点）是设计的核心，因此新增必须附带测试锁定契约。

## 禁忌与反模式
- 跳过经验检索直接实现：可能重复团队已沉淀的方案。
- 改动前后不跑测试或只跑部分测试：无法证明"已有行为不变"。
- 吞掉上游错误：上游错误信封 `code !== 0` 必须抛出 Error 并带上信封 message。
- 把空内容当缺失/错误：空资源是合法文件，应返回零字节 Buffer。
- 假定资源一定是文本：需按 `data.encoding`（utf-8 或 base64）解码还原字节。
- 拼接 base 与子路径时产生双斜杠或漏斜杠。

## 关键事实依据
- fetchResource 契约：成功返回资源原始字节 Buffer（调用方可直接写文件）；内容为空或信封缺 content 返回零字节 Buffer；`code !== 0` 抛 Error 并在 message 带信封 message；`fetcher` 注入 HTTP 实现（测试传桩），缺省 `globalThis.fetch`。
- skill-bridge 资源读取协议：`POST <bridgeBase>/files/read`，体 `{ skill_id, path }`，头含 `content-type: application/json` 与 `x-tdai-service-id: default`；响应信封 `{ code, message, request_id, data }`，`data.content` 为内容字符串，按 `data.encoding` 解码。

## 相关任务与资产
- 资产：evaluation/gate/fetch-resource.mjs（fetchResource 实现）、evaluation/gate/fetch-resource.test.mjs（5 条用例：按 encoding 解码返回 Buffer、空资源零字节 Buffer、错误信封抛带 message 的 Error、请求参数校验、缺省 globalThis.fetch）。
- 结果：新增测试全部通过，全量 evaluation 保持 637 pass、0 fail、2 skipped。

## 演化记录
（无）

## 待确认问题
- "改前跑基线"是否已成为团队强制环节，还是仅本次任务要求，待确认后决定是否升级为通用交付规则。
