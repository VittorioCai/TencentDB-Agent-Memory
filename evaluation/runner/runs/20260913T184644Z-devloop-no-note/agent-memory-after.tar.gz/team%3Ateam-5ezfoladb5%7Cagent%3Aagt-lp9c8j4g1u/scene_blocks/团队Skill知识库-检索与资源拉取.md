-----META-START-----
created: 2026-09-13T18:44:30.497Z
updated: 2026-09-13T18:44:30.497Z
summary: 团队以 skill 形式沉淀经验，动手前须经 skill-bridge v3 检索；并沉淀 fetchResource 资源拉取工具的接口约定与交付验收口径。
heat: 1
-----META-END-----

## 工作场景
适用于「团队用 skill 沉淀经验」的知识库工作场景，覆盖两件可复用的事：一是任务开工前的经验检索，二是通过 skill-bridge 把团队 skill 的资源文件拉取到本地的工具开发与验收。适合本仓库所属团队及后续同类工具（bridge / skill 资源）任务复用。

## 适用条件
- 本仓库所属团队的既定工作约定：动手实现前先检索团队知识库。
- 需要在 `evaluation/gate/` 下新增或维护工具时。
- 依赖 skill-bridge v3 HTTP 接口（例如本地 `http://127.0.0.1:8096`）。

## 核心 SOP
- 先检索再动手：团队经验以 skill 形式存于知识库，开工前检索一次；有相关经验则参考，没有则按自身判断执行。
- 检索走 skill-bridge v3：POST `http://127.0.0.1:8096/skill-bridge/v3/skill/search`，请求头带 `x-tdai-service-id` 与 `x-conversation-id`，body 的 `query` 为检索词。
- 拉取资源用 `fetchResource({ skillId, path, bridgeBase, fetcher })`，导出为 `evaluation/gate/fetch-resource.mjs`。
- 交付前自检：补一条测试 → 跑 `node --test` 让 evaluation 下全部 `*.test.mjs` 通过 → 确认已有行为不变 → 只改必要文件 → 汇报「改了什么、为什么」。

## 判断逻辑
- 先检索后动手：避免重复造轮子，也能对齐团队既有实现；无匹配才自行决策，保留效率。
- 返回原始字节 `Buffer` 而非字符串：调用方可直接写入文件，避免编码/二进制损坏。
- 用 `fetcher` 注入 HTTP 实现：测试传桩即可隔离网络，缺省 `globalThis.fetch` 保持生产可用。
- 错误必须冒泡：抛 `Error` 并携带上游信封 `message`，便于定位而非静默失败。

## 禁忌与反模式
- 不要吞错误：上游错误信封 `code !== 0` 必须抛出 `Error` 且 `message` 带上信封的 `message`。
- 不要把空内容当失败：资源为空返回零字节 `Buffer`，空文件是合法文件。
- 不要硬编码 HTTP 调用：必须经 `fetcher` 注入，缺省才用 `globalThis.fetch`。
- 不要跳过经验检索直接开工。
- 不要破坏现有测试或改动非必要文件：验收以 evaluation 下现有 `*.test.mjs` 全绿、行为不变为准。

## 关键事实依据
- 参考 skill：`eval-skill-resource-download`（`skl-XAzqAgejM7O4`），`fetch-resource.mjs` 实现参考其内容。
- 相关 skill：`eval-bridge-endpoint-b`（`skl-oBaDO5CceKnr`），关于 bridge endpoint 约定。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`：新增工具，导出 `fetchResource`，需补一条测试；当前为待实现状态。

## 演化记录
（空）

## 待确认问题
- `fetchResource` 的导出/行为是否需与 `eval-skill-resource-download` 保持完全一致？

[PERSONA_UPDATE_REQUEST]
reason: 团队级工作约定「动手实现前先检索团队知识库中以 skill 形式保存的经验，有则参考、无则自行判断」已稳定形成，且「上游错误信封不得吞掉、错误需携带 message」等约束影响多个工具类场景，建议沉淀为 L3 团队操作记忆。
[/PERSONA_UPDATE_REQUEST]
