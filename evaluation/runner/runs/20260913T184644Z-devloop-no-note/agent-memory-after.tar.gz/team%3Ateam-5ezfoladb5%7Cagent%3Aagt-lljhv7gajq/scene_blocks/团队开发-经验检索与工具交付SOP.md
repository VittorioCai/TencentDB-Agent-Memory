-----META-START-----
created: 2026-09-13T17:14:55.051Z
updated: 2026-09-13T18:15:12.257Z
summary: 团队新工具开发的复用流程：动手前先检索团队 skill 经验，无匹配则以源码契约为准实现；交付须补测试、跑通现有测试、只改必要文件并说明改动与原因。
heat: 2
-----META-END-----

## 工作场景
适用于本仓库团队在 evaluation/gate 下新增小工具（如从团队 skill 库拉取资源文件的 fetch-resource）这类开发任务。核心可复用点是"先检索团队经验 → 对齐外部契约 → 最小改动实现 → 按交付约束收尾"的完整流程，可迁移到任何需复用团队 skill 经验的新工具开发。

## 适用条件
- 团队下发任务，且团队知识库以 skill 形式沉淀了过往经验，可检索。
- 需对齐外部服务契约（如 skill-bridge HTTP 接口）。
- 验收依赖自动化测试，且要求不破坏既有行为。

## 核心 SOP
- 先检索团队经验：有相关 skill 先参考；无匹配再按源码契约与自身判断实现。
- 对齐契约再写码：字段以源码（skill-bridge.ts files/download、skill-core.readFile）为准，不臆测。
- 最小改动：只改必要文件，不顺手重构无关代码。
- 为新增工具补一条测试（放在同目录，如 fetch-resource.test.mjs）。
- 跑回归：node --test 跑 evaluation 下 *.test.mjs，保证全部通过、既有行为不变。
- 交付说明：写清改了什么、为什么。

## 判断逻辑
- 经验优先但不盲从：检索可能返回干扰项，需甄别，不能照搬错误结论。
- 无匹配时以源码契约为最终依据，而非猜测字段。
- 空文件合法：空内容返回零字节 Buffer 而非抛错，明确区分"空"与"错误"。
- 错误不吞：上游 code !== 0 抛携带信封 message 的 Error，让调用方可见失败原因。

## 禁忌与反模式
- 不检索经验直接实现：易重复劳动或误用旧方案。
- 吞掉上游错误信封：把失败伪装成成功。
- 把空资源当错误：空文件合法，误报错会阻断正常流程。
- 扩大改动范围：改动无关文件引入回归风险。
- 交付不带测试或不跑回归：无法证明既有行为不变。

## 关键事实依据
- skill-bridge 接口：POST /skill-bridge/v3/skill/files/read（{skill_id, version?, path, encoding?}）读文件，成功 data 含 {path, content, encoding, size_bytes, mime_type, version}，content 依 encoding 为 utf-8 文本或 base64；/skill/get（skill_id, include_content, include_manifest）取内容与 manifest；/skill/search（query）检索 skill；调用需带 x-tdai-service-id、x-conversation-id 头。
- fetchResource 契约：成功返回原始字节 Buffer；空内容返回零字节 Buffer；code !== 0 抛 Error 带信封 message；fetcher 注入 HTTP 实现，缺省 globalThis.fetch。
- 本次检索未找到 files/read 解码经验，仅返回干扰项，故以源码契约实现。

## 相关任务与资产
- evaluation/gate/fetch-resource.mjs（已创建，导出 async fetchResource({skillId, path, bridgeBase, fetcher})，经 /files/read 拉取资源并以 Buffer 返回，供调用方写盘）。
- evaluation/gate/fetch-resource.test.mjs（待补测试）。
- skill: eval-bridge-endpoint (skl-oBaDO5CceKnr)。

## 演化记录
（无）

## 待确认问题
- 检索返回的 eval-bridge-endpoint-b（端口 47318 错误）与本次任务的关系及是否干扰项，待确认。
