-----META-START-----
created: 2026-09-13T16:53:23.973Z
updated: 2026-09-13T18:15:28.783Z
summary: 团队在 evaluation/gate 下开发 Node 工具的可复用 SOP：先检索 skill 经验，只改必要文件，先定接口契约再编码，测试兜底并说明改动原因；含 skill 资源抓取工具的契约范式。
heat: 3
-----META-END-----

## 工作场景
适用于本仓库新增/修改工具类模块（典型如 `evaluation/gate/*.mjs`）的开发任务，以及团队"经验沉淀—复用—验收"的协作方式。核心可复用对象不是某个文件，而是一套流程：先查经验、再定契约、最小改动、测试兜底、事后说明。skill 资源本地化抓取（fetch-resource）是该方法的一个范式实例。

## 适用条件
- 任务类型：新增工具、导出可复用函数、改动共享模块行为。
- 团队约束：经验以 skill 存于团队知识库；验收以 `node --test evaluation/**/*.test.mjs` 为准。
- 上游存在缺陷需在调用侧规避（如 bridge 空内容误判）。

## 核心 SOP
- 动手前先检索一次团队 skill 经验：有则参考、无则按自身判断实现，避免重复踩坑。
- 先固定接口契约再写实现：明确入参、返回值类型、错误语义。
- 通过参数注入外部依赖（如 HTTP `fetcher`，缺省 `globalThis.fetch`），让测试可传桩、脱离真实网络。
- 为新增工具补一条测试，覆盖成功路径与关键边界。
- 只改必要文件，不顺手重构。
- 改完用 `node --test` 跑 evaluation 下 `*.test.mjs`，确认全绿且已有行为不变。
- 最后说明改了什么、为什么，便于评审。

## 判断逻辑
- **契约优先**：`fetchResource({ skillId, path, bridgeBase, fetcher })` 成功返回资源原始字节 `Buffer`（调用方可直接写文件）；空内容返回零字节 Buffer；上游错误信封（`code !== 0`）必须抛 `Error` 且 message 带上信封 message，不得吞掉。
- **编码还原**：上游 `data.content` 是字符串，按 `data.encoding`（base64 或 utf-8）解码后还原为原始字节；注意 bridgeBase 尾斜杠拼接。
- **空文件合法**：`content` 为空或缺失都返回零字节 Buffer，既不报错也不回退成整个 data 信封。
- **适配而非改上游**：`skill-bridge.ts:820` 把空内容误判为错误；本工具在调用侧归一化，容忍空文件正常返回。选择"适配"因改动面更小、边界更可控。

## 禁忌与反模式
- 吞掉上游错误或转成空字节：调用方无法感知失败；应抛带 message 的 Error。
- 把空内容当错误或回退整个 data 信封：违反空文件合法性契约。
- 改动无关文件：破坏"只改必要文件、已有行为不变"的验收前提。
- 只跑新增测试或跳过团队经验检索：前者漏回归，后者可能重复踩坑。

## 关键事实依据
- bridge `files/read` 信封：`{ code, message, data: { path, content, encoding, size_bytes, mime_type, version } }`；`code !== 0` 表示失败，message 携带原因（如 `SKILL_NOT_FOUND`）。
- 已知缺陷：`skill-bridge.ts:820` 将空内容误判为错误。

## 相关任务与资产
- `evaluation/gate/fetch-resource.mjs`（导出 `fetchResource`）。
- `evaluation/gate/fetch-resource.test.mjs`：覆盖原始字节返回、utf-8/base64 解码与 bridgeBase 尾斜杠、空资源零字节、缺失 content 仍零字节、错误信封抛出、纯信封桩 fetcher。

## 演化记录
- [2026-09-13]：将"团队Skill资源抓取-工具契约与验收SOP"并入本文件，二者同属 evaluation/gate 工具开发方法体系，合并以增加深度、去除重叠。

## 待确认问题
- `skill-bridge.ts:820` 的空内容误判由 bridge 侧修复，还是长期由调用工具兜底？影响 fetchResource 适配逻辑能否简化。
